//+------------------------------------------------------------------+
//| XMS_Risk.mqh - XAU MultiSession EA v2.90 USD
//| shared helpers (time/DST, magic, global variables), filters (spread median,
//| news, holidays, vol shock, MTF), per-position risk book, equity-curve
//| multiplier, lot sizing, open risk, account guard (DD throttle / halt, daily
//| loss stop), sleeves, order-error halt, no-SL emergency, module breaker.
//| Legacy code moved verbatim from v2.60 prototype (see CHANGES.md).
//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
//| เวลาและ DST                                                       |
//+------------------------------------------------------------------+
datetime NthSunday(int year, int mon, int n)   // n>0 = อาทิตย์ที่ n, n=0 = อาทิตย์สุดท้าย
{
   MqlDateTime d;
   if(n > 0)
   {
      datetime first = StringToTime(StringFormat("%04d.%02d.01", year, mon));
      TimeToStruct(first, d);
      return first + ((7 - d.day_of_week) % 7 + 7 * (n - 1)) * 86400;
   }
   int ny = year, nm = mon + 1;
   if(nm > 12) { nm = 1; ny++; }
   datetime last = StringToTime(StringFormat("%04d.%02d.01", ny, nm)) - 86400;
   TimeToStruct(last, d);
   return last - d.day_of_week * 86400;
}
bool IsUSDST(datetime t)
{
   MqlDateTime d; TimeToStruct(t, d);
   return t >= NthSunday(d.year, 3, 2) && t < NthSunday(d.year, 11, 1);
}
bool IsEUDST(datetime t)
{
   MqlDateTime d; TimeToStruct(t, d);
   return t >= NthSunday(d.year, 3, 0) && t < NthSunday(d.year, 10, 0);
}
int ServerOffsetHours(datetime t)
{
   int off = InpServerGMTWinter;
   if(InpServerDST == DST_US && IsUSDST(t)) off++;
   if(InpServerDST == DST_EU && IsEUDST(t)) off++;
   return off;
}

//+------------------------------------------------------------------+
//| ตัวช่วย                                                           |
//+------------------------------------------------------------------+
double Val(int handle, int buffer, int shift)
{
   double b[1];
   if(CopyBuffer(handle, buffer, shift, 1, b) != 1) return EMPTY_VALUE;
   return b[0];
}
long   ModMagic(int mod)      { return InpMagicBase + 1 + mod; }
bool   IsOurMagic(long m)     { return m >= InpMagicBase + 1 && m <= InpMagicBase + MODS; }
double Spread()               { return SymbolInfoDouble(_Symbol, SYMBOL_ASK) - SymbolInfoDouble(_Symbol, SYMBOL_BID); }
double GVGet(string k, double def) { return GlobalVariableCheck(gPfx + k) ? GlobalVariableGet(gPfx + k) : def; }
void   GVSet(string k, double v)   { GlobalVariableSet(gPfx + k, v); }

//--- risk ที่เปิดอยู่รวม (% equity) นับเฉพาะไม้ที่ SL ยังอยู่ฝั่งขาดทุน
double OpenRiskPct()
{
   double tv = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double ts = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
   double eq = AccountInfoDouble(ACCOUNT_EQUITY);
   if(ts <= 0 || eq <= 0) return 0;
   double sum = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong t = PositionGetTicket(i);
      if(t == 0) continue;
      if(PositionGetString(POSITION_SYMBOL) != _Symbol || !IsOurMagic(PositionGetInteger(POSITION_MAGIC))) continue;
      double op = PositionGetDouble(POSITION_PRICE_OPEN), sl = PositionGetDouble(POSITION_SL);
      if(sl <= 0) continue;
      double dist = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY) ? op - sl : sl - op;
      if(dist > 0) sum += dist / ts * tv * PositionGetDouble(POSITION_VOLUME);
   }
   return 100.0 * sum / eq;
}

//+------------------------------------------------------------------+
//| v2: median spread, ข่าว, วันหยุด                                   |
//+------------------------------------------------------------------+
void PushSpread()
{
   gSpr[gSprI] = Spread(); gSprI = (gSprI + 1) % 200; if(gSprN < 200) gSprN++;
}
double MedianSpread()
{
   if(gSprN < 20) return 0;
   double a[]; ArrayResize(a, gSprN);
   for(int i = 0; i < gSprN; i++) a[i] = gSpr[i];
   ArraySort(a);
   return a[gSprN / 2];
}
void AddNews(datetime t, bool fomc)
{
   int n = ArraySize(gNews); ArrayResize(gNews, n + 1); ArrayResize(gIsFOMC, n + 1);
   gNews[n] = t; gIsFOMC[n] = fomc;
}
// เวลา ET → UTC (ใช้ DST สหรัฐ)
datetime ETtoUTC(string ymd, int hh, int mm)
{
   datetime d = StringToTime(ymd) + hh * 3600 + mm * 60;
   return d + (IsUSDST(d) ? 4 : 5) * 3600;
}
void LoadNews()
{
   ArrayResize(gNews, 0); ArrayResize(gIsFOMC, 0);
   // FOMC statement 14:00 ET (วันที่สองของการประชุม)
   string fomc[] = {"2025.01.29","2025.03.19","2025.05.07","2025.06.18","2025.07.30","2025.09.17","2025.10.29","2025.12.10",
                    "2026.01.28","2026.03.18","2026.04.29","2026.06.17","2026.07.29","2026.09.16","2026.10.28","2026.12.09"};
   for(int i = 0; i < ArraySize(fomc); i++) AddNews(ETtoUTC(fomc[i], 14, 0), true);
   // NFP 08:30 ET (ตารางจริงช่วงทดสอบ; รวมวันที่เลื่อนจาก shutdown ปลายปี 2025 — ใช้ CSV ทับได้)
   string nfp[] = {"2025.11.20","2025.12.16","2026.01.09","2026.02.06","2026.03.06","2026.04.03","2026.05.08","2026.06.05",
                   "2026.07.02","2026.08.07","2026.09.04","2026.10.02","2026.11.06","2026.12.04"};
   for(int i = 0; i < ArraySize(nfp); i++) AddNews(ETtoUTC(nfp[i], 8, 30), false);
   int f = FileOpen(InpNewsFile, FILE_READ | FILE_TXT | FILE_ANSI | FILE_COMMON | FILE_SHARE_READ);
   if(f != INVALID_HANDLE)
   {
      int k = 0;
      while(!FileIsEnding(f))
      {
         string ln = FileReadString(f); StringTrimLeft(ln); StringTrimRight(ln);
         if(StringLen(ln) < 10 || StringGetCharacter(ln, 0) == '#') continue;
         datetime t = StringToTime(StringSubstr(ln, 0, 16));
         if(t > 0) { AddNews(t, StringFind(ln, "FOMC") >= 0); k++; }
      }
      FileClose(f);
      Print("XAU_MultiSession: โหลดข่าวจาก ", InpNewsFile, " ", k, " รายการ");
   }
}
bool NewsBlocked(datetime utc)
{
   if(!InpNewsFilter) return false;
   for(int i = 0; i < ArraySize(gNews); i++)
      if(utc >= gNews[i] - InpNewsBefore * 60 && utc <= gNews[i] + InpNewsAfter * 60) return true;
   return false;
}
bool IsFOMCDay(datetime utc)
{
   long d = (long)utc / 86400;
   for(int i = 0; i < ArraySize(gNews); i++) if(gIsFOMC[i] && (long)gNews[i] / 86400 == d) return true;
   return false;
}
bool IsHoliday(datetime utc)
{
   if(!InpHolidayFilter) return false;
   MqlDateTime d; TimeToStruct(utc, d);
   if(d.mon == 12 && d.day >= 24) return true;          // คริสต์มาส ถึง สิ้นปี
   if(d.mon == 1 && d.day <= 2) return true;            // ปีใหม่
   if(d.mon == 7 && d.day == 4) return true;            // Independence Day
   if(d.mon == 11 && d.day_of_week == 4 && d.day >= 22 && d.day <= 28) return true;   // Thanksgiving
   if(d.mon == 11 && d.day_of_week == 5 && d.day >= 23 && d.day <= 29) return true;   // วันศุกร์หลัง Thanksgiving
   if((d.mon == 1 || d.mon == 2) && d.day_of_week == 1 && d.day >= 15 && d.day <= 21) return true; // MLK / Presidents
   if(d.mon == 5 && d.day_of_week == 1 && d.day >= 25) return true;                    // Memorial Day
   if(d.mon == 9 && d.day_of_week == 1 && d.day <= 7) return true;                     // Labor Day
   return false;
}

//+------------------------------------------------------------------+
//| v2.50 helpers                                                     |
//+------------------------------------------------------------------+
double BaseRiskPct(int mod)
{
   double riskPct = (mod == MOD_LONDON || mod == MOD_NY) ? InpRiskMain : InpRiskMinor;
   if(mod == MOD_LONDON) riskPct = InpRiskLondon;
   if(mod == MOD_ASIA)  riskPct = InpRiskAsia;
   if(mod == MOD_ASIAB) riskPct = InpRiskAsiaB;
   if(mod == MOD_LONC)  riskPct = InpRiskLonC;
   if(mod == MOD_ASIAC) riskPct = InpRiskAsiaC;
   if(mod == MOD_OVLB)  riskPct = InpRiskOvlB;
   if(mod == MOD_LDNB)  riskPct = InpRiskLdnB;
   if(mod == MOD_SCALP) riskPct = InpRiskScalp;
   if(mod == MOD_ORBA)  riskPct = InpRiskORBA;
   if(mod == MOD_DMA)   riskPct = InpRiskDMA;
   if(mod == MOD_DML)   riskPct = InpRiskDML;
   return riskPct;
}
string ModName(int mod)
{
   string nm[MODS] = {"ASIA", "LONDON", "NY", "NY_PM", "ASIA_B", "LON_C", "ASIA_C", "OVL_B", "LDN_B", "SCALP", "ORB_A", "DM_A", "DM_L"};
   return (mod >= 0 && mod < MODS) ? nm[mod] : "?";
}

//--- per-position info (initial risk, partial-close flag)
int PosFind(ulong id)
{
   for(int i = ArraySize(gPos) - 1; i >= 0; i--) if(gPos[i].id == id) return i;
   return -1;
}
void PosRemove(int idx)
{
   int n = ArraySize(gPos);
   if(idx < 0 || idx >= n) return;
   gPos[idx] = gPos[n - 1];
   ArrayResize(gPos, n - 1);
}
int PosAdd(ulong id, double riskMoney, double slDist, bool partDone)   // note: may change the selected position
{
   if(ArraySize(gPos) >= 64)                                           // drop entries of closed positions
      for(int i = ArraySize(gPos) - 1; i >= 0; i--) if(!PositionSelectByTicket(gPos[i].id)) PosRemove(i);
   int n = ArraySize(gPos);
   ArrayResize(gPos, n + 1);
   gPos[n].id = id; gPos[n].riskMoney = riskMoney; gPos[n].slDist = slDist; gPos[n].partDone = partDone; gPos[n].partTries = 0;
   gPos[n].adds = 0; gPos[n].addTries = 0; gPos[n].addNext = 0; gPos[n].beNext = 0;
   return n;
}
//--- entry for an open position; rebuilt from the position + its history after an EA restart
int PosEnsure(ulong ticket)                                            // note: changes the selected position
{
   int idx = PosFind(ticket);
   if(idx >= 0) return idx;
   if(!PositionSelectByTicket(ticket)) return -1;
   double op = PositionGetDouble(POSITION_PRICE_OPEN), sl = PositionGetDouble(POSITION_SL), vol = PositionGetDouble(POSITION_VOLUME);
   int    dir = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY) ? 1 : -1;
   int    mod = (int)(PositionGetInteger(POSITION_MAGIC) - InpMagicBase - 1);
   long   pmg = PositionGetInteger(POSITION_MAGIC);
   datetime pt0 = (datetime)PositionGetInteger(POSITION_TIME);
   bool   addon = SelIsAddon(ticket);
   double inVol = 0;
   if(HistorySelectByPosition(ticket))
      for(int i = HistoryDealsTotal() - 1; i >= 0; i--)
      {
         ulong d = HistoryDealGetTicket(i);
         if(d != 0 && HistoryDealGetInteger(d, DEAL_ENTRY) == DEAL_ENTRY_IN) inVol += HistoryDealGetDouble(d, DEAL_VOLUME);
      }
   if(inVol <= 0) inVol = vol;
   double tv = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE), ts = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
   double dist = (sl > 0 && (op - sl) * dir > 0) ? (op - sl) * dir : 0.0;   // 0 = initial SL unknown (already moved)
   double rm = (dist > 0 && ts > 0 && tv > 0) ? dist / ts * tv * inVol : AccountInfoDouble(ACCOUNT_BALANCE) * BaseRiskPct(mod) / 100.0;
   int adds = 0;                                                       // v2.60: add-ons already opened for this parent
   if(InpPyrMode == 1 && !addon && HistorySelect(pt0, TimeCurrent() + 60))
      for(int i = HistoryDealsTotal() - 1; i >= 0; i--)
      {
         ulong d = HistoryDealGetTicket(i);
         if(d == 0 || HistoryDealGetString(d, DEAL_SYMBOL) != _Symbol || HistoryDealGetInteger(d, DEAL_MAGIC) != pmg) continue;
         if(HistoryDealGetInteger(d, DEAL_ENTRY) == DEAL_ENTRY_IN && StringFind(HistoryDealGetString(d, DEAL_COMMENT), PYR_SUFFIX) >= 0) adds++;
      }
   idx = PosAdd(ticket, rm, dist, addon || vol < inVol - 1e-8);
   if(idx >= 0) gPos[idx].adds = adds;
   return idx;
}

//--- equity-curve multiplier: balance high-water mark + running sum of closed R
void EqUpdate()
{
   if(InpEqRiskMode != 1) return;
   double bal = AccountInfoDouble(ACCOUNT_BALANCE);
   if(gEqPeak <= 0 || bal > gEqPeak) gEqPeak = bal;
   if(gEqPeak > 0 && (gEqPeak - bal) / gEqPeak * 100.0 > InpEqResetDDPct) gEqStreakR = 0;
}
//--- mode 2: one balance sample per fully closed position, oldest dropped beyond InpEqSMAN
void EqSmaAdd(double bal)
{
   if(InpEqSMAN < 1) return;
   int n = ArraySize(gEqBal);
   if(n >= InpEqSMAN)
   {
      int drop = n - InpEqSMAN + 1;
      for(int i = drop; i < n; i++) gEqBal[i - drop] = gEqBal[i];
      n -= drop;
   }
   ArrayResize(gEqBal, n + 1);
   gEqBal[n] = bal;
}
//--- mode 2: SMA of the last InpEqSMAN samples; 0 while fewer samples exist
double EqSma()
{
   int n = ArraySize(gEqBal);
   if(InpEqSMAN < 1 || n < InpEqSMAN) return 0.0;
   double sum = 0;
   for(int i = n - InpEqSMAN; i < n; i++) sum += gEqBal[i];
   return sum / InpEqSMAN;
}
double EqMult()
{
   if(InpEqRiskMode == 2)
   {
      double sma = EqSma();
      return (sma > 0 && AccountInfoDouble(ACCOUNT_BALANCE) > sma) ? InpEqSMAMult : 1.0;
   }
   if(InpEqRiskMode != 1 || gEqPeak <= 0) return 1.0;
   if(AccountInfoDouble(ACCOUNT_BALANCE) < gEqPeak * (1.0 - InpEqNearPeakPct / 100.0)) return 1.0;
   if(gEqStreakR >= InpEqStepR3) return InpEqMult3;
   if(gEqStreakR >= InpEqStepR2) return InpEqMult2;
   if(gEqStreakR >= InpEqStepR1) return InpEqMult1;
   return 1.0;
}

//--- volatility shock: evaluated once per D1 bar from bars completed before today's open.
//    Data not ready -> no filter, retry on the next call.
bool VolShock()
{
   if(InpVolShockMode <= 0) return false;
   datetime d0 = iTime(_Symbol, PERIOD_D1, 0);
   if(d0 == 0) return false;
   if(d0 == gVolDay) return gVolShock;
   bool shock = false; string why = "";
   if(InpVolShockMax > 0 || InpVolShockRangeATR > 0)
   {
      if(hVolSlow == INVALID_HANDLE) return false;
      double aS = Val(hVolSlow, 0, 1);
      if(aS == EMPTY_VALUE || aS <= 0) return false;
      if(InpVolShockMax > 0)
      {
         if(hVolFast == INVALID_HANDLE) return false;
         double aF = Val(hVolFast, 0, 1);
         if(aF == EMPTY_VALUE) return false;
         if(aF / aS > InpVolShockMax) { shock = true; why = StringFormat("D1 ATR%d/%d %.2f", InpVolShockATRFast, InpVolShockATRSlow, aF / aS); }
      }
      if(!shock && InpVolShockRangeATR > 0)
      {
         double hi = iHigh(_Symbol, PERIOD_D1, 1), lo = iLow(_Symbol, PERIOD_D1, 1);
         if(hi <= 0 || lo <= 0) return false;
         if(hi - lo > InpVolShockRangeATR * aS) { shock = true; why = StringFormat("D1 range %.2f x ATR", (hi - lo) / aS); }
      }
   }
   if(!shock && InpVolShockH1ATR > 0)
   {
      if(hVolH1 == INVALID_HANDLE) return false;
      int s = iBarShift(_Symbol, PERIOD_H1, d0, false);
      if(s < 0) return false;
      int st = (iTime(_Symbol, PERIOD_H1, s) >= d0) ? s + 1 : s;        // first H1 bar before today's D1 open
      MqlRates h[]; double a[];
      if(CopyRates(_Symbol, PERIOD_H1, st, 24, h) != 24 || CopyBuffer(hVolH1, 0, st, 24, a) != 24) return false;
      for(int i = 0; i < 24; i++)
         if(a[i] > 0 && a[i] != EMPTY_VALUE && h[i].high - h[i].low > InpVolShockH1ATR * a[i])
         { shock = true; why = StringFormat("H1 range %.2f x ATR", (h[i].high - h[i].low) / a[i]); break; }
   }
   gVolDay = d0; gVolShock = shock; gVolWhy = why;
   return shock;
}

//--- MTF: 1 = last closed bar above a rising EMA, -1 = below a falling EMA, 0 = neither, 2 = no data
int MTFSide(ENUM_TIMEFRAMES tf, int handle)
{
   if(handle == INVALID_HANDLE) return 2;
   double c = iClose(_Symbol, tf, 1), e1 = Val(handle, 0, 1), e4 = Val(handle, 0, 4);
   if(c <= 0 || e1 == EMPTY_VALUE || e4 == EMPTY_VALUE) return 2;
   if(c > e1 && e1 > e4) return 1;
   if(c < e1 && e1 < e4) return -1;
   return 0;
}
int MTFAligned(int dir)       // 1 = H4 and H1 both agree with dir, 0 = not, -1 = no data (no filter)
{
   int a = MTFSide(PERIOD_H4, hMTF4), b = MTFSide(PERIOD_H1, hMTF1);
   if(a == 2 || b == 2) return -1;
   return (a == dir && b == dir) ? 1 : 0;
}

//+------------------------------------------------------------------+
//| Guard ระดับบัญชี: DD และ daily loss                                |
//+------------------------------------------------------------------+
void UpdateGuards()
{
   double eq = AccountInfoDouble(ACCOUNT_EQUITY);
   double peak = GVGet("peak", eq);
   if(eq > peak || !GlobalVariableCheck(gPfx + "peak")) { peak = MathMax(eq, peak); GVSet("peak", peak); }
   double dd = peak > 0 ? (peak - eq) / peak * 100.0 : 0;
   gMaxDD = MathMax(gMaxDD, dd);
   gScale = dd >= InpDDQuarter ? 0.25 : (dd >= InpDDHalf ? 0.5 : 1.0);
   if(!gHalted && dd >= InpDDHalt)
   {
      gHalted = true; GVSet("halted", 1);
      ClosePositions(-1, false);
      Print("XAU_MultiSession: DD ถึงเพดาน หยุด EA — ตั้ง InpResetHalt=true เพื่อเริ่มใหม่");
   }
   if(gDayStartEq > 0 && !gDayStop && (gDayStartEq - eq) / gDayStartEq * 100.0 >= InpDailyLossPct)
   {
      gDayStop = true;
      ClosePositions(-1, false);
      Print("XAU_MultiSession: ถึง daily loss หยุดจนถึงวันถัดไป");
   }
}

//+------------------------------------------------------------------+
//| v2.60 lot sizing. Body moved verbatim from OpenTrade (v2.50):      |
//| lots = equity x risk% / (SL distance x value per point), rounded   |
//| DOWN to the volume step, capped by InpMaxLot / SYMBOL_VOLUME_MAX.  |
//|  riskPct    : target risk % after ALL multipliers                  |
//|  lotScale   : gScale x regMult x xMult (used by FIXED / AUTO only) |
//|  extraScale : sleeve x module breaker, always <= 1 (1 = neutral)   |
//| PRE-EXISTING capped rule kept unchanged for regression (G1):       |
//|  InpMinLotMaxRisk > 0 and lots < min lot -> min lot is used ONLY   |
//|  if its real risk <= InpMinLotMaxRisk % of equity and the open     |
//|  risk cap still holds. Set InpMinLotMaxRisk = 0 to always skip     |
//|  (strict "never round up"). No other path can raise a lot.         |
//| Returns false (trade skipped) when the lot is below the minimum.   |
//+------------------------------------------------------------------+
//--- v2.70: min-lot risk cap (%) of a module's group. NEW = ORB_A / DM_A / DM_L (same split as SleeveOf), LEGACY = the rest.
//    A negative group input returns InpMinLotMaxRisk itself (v2.60 behaviour); 0 = never round up to the min lot.
double MinLotCap(int mod)
{
   double g = (mod >= MOD_ORBA) ? InpMinLotMaxRiskNew : InpMinLotMaxRiskLegacy;
   return g < 0 ? InpMinLotMaxRisk : g;
}

bool RiskLots(double slDist, double riskPct, double lotScale, double extraScale, double minLotCap, string tag, double &lots, double &tv, double &ts)
{
   tv = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   ts = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
   if(tv <= 0 || ts <= 0) return false;
   lots = AccountInfoDouble(ACCOUNT_EQUITY) * riskPct / 100.0 / (slDist / ts * tv);
   double step = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
   lots = MathFloor(lots / step) * step;
   lots = MathMin(lots, MathMin(InpMaxLot, SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX)));
   double vmin = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   if(lots < vmin && minLotCap > 0)                                      // v2.70: minLotCap = MinLotCap(mod) (= InpMinLotMaxRisk at defaults)
   {
      double realRisk = 100.0 * vmin * (slDist / ts * tv) / AccountInfoDouble(ACCOUNT_EQUITY);
      if(realRisk <= minLotCap && OpenRiskPct() + realRisk <= MathMax(InpMaxOpenRisk, minLotCap)) lots = vmin;
   }
   if(InpLotMode != LOT_RISK_PCT)
   {
      double bal = AccountInfoDouble(ACCOUNT_BALANCE), per01 = 0.01 * (slDist / ts * tv);   // $ risk ของ 0.01 lot
      lots = (InpLotMode == LOT_FIXED) ? InpFixedLot : 0.01 * MathMax(1.0, MathFloor(bal / MathMax(InpAutoPerBal, 1.0)));
      lots *= lotScale;                                                                    // ลดตาม DD เหมือนโหมด risk
      if(extraScale < 1.0) lots *= extraScale;                                             // v2.60 sleeve / breaker (only reduces)
      double capLots = (InpAutoMaxRisk > 0 && per01 > 0) ? 0.01 * MathFloor(AccountInfoDouble(ACCOUNT_EQUITY) * InpAutoMaxRisk / 100.0 / per01) : lots;
      lots = MathMin(lots, capLots);
      lots = MathFloor(lots / step) * step;
      lots = MathMin(lots, MathMin(InpMaxLot, SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX)));
   }
   if(lots < vmin) { gStatus = "ข้าม: lot ต่ำกว่าขั้นต่ำ (" + tag + ")"; return false; }
   lots = NormalizeDouble(lots, 2);
   return true;
}

//+------------------------------------------------------------------+
//| v2.90 strategy mode. CLASSIC = v2.80 (this code is never reached  |
//| in CLASSIC: RecentActive() is a pure false).                       |
//+------------------------------------------------------------------+
bool RecentActive()
{
   if(InpStrategyMode == MODE_RECENT) return true;
   if(InpStrategyMode == MODE_AUTO)   return gAutoHi;
   return false;
}
string ModeString()
{
   if(InpStrategyMode == MODE_RECENT) return "RECENT";
   if(InpStrategyMode == MODE_AUTO)   return gAutoInit ? (gAutoHi ? "AUTO(HI)" : "AUTO(LO)") : "AUTO(LO)";
   return "CLASSIC";
}
void AutoReset() { gAutoHi = false; gAutoInit = false; gAutoBar = 0; gAutoATR = 0; }
//--- AUTO latch. Source = Wilder ATR(24) of CLOSED H1 bars from the regime engine (RegimeUpdate runs in every mode and
//    only publishes a value once the H1 bar is closed). Evaluated once per new closed H1 bar; hysteresis between Lo and Hi.
void AutoRegimeUpdate()
{
   if(!RegOK() || gRgTime == gAutoBar) return;
   gAutoBar = gRgTime;
   double a = RegATR24();
   if(a <= 0) return;
   gAutoATR = a;
   if(!gAutoInit)            { gAutoHi = (a >= InpAutoATRHi); gAutoInit = true; }
   else if(a >= InpAutoATRHi) gAutoHi = true;
   else if(a <  InpAutoATRLo) gAutoHi = false;
}
//--- recent-regime min-lot cap (%) of the module's group; negative input -> the classic cap
double RcMinLotCap(int mod)
{
   double g = (mod >= MOD_ORBA) ? InpRcMinLotCapNew : InpRcMinLotCapLegacy;
   return g < 0 ? MinLotCap(mod) : g;
}
//--- RECENT sizing. Same RiskLots() with the recent cap; if that skips because the min lot's real risk with the original
//    SL exceeds the cap, the SL may be moved CLOSER to entry (never further) so 0.01 lot risks <= cap. sl / slDist in-out.
bool RiskLotsRecent(int mod, int dir, string tag, double entry, double spread, double stopLv, double tp, double minRR,
                    double riskPct, double lotScale, double extraScale,
                    double &sl, double &slDist, double &lots, double &tv, double &ts)
{
   double cap = RcMinLotCap(mod);
   if(InpRcCapThrottle)                                                  // v2.90: the min-lot round-up obeys the DD throttles (only reduces)
   {
      double thr = MathMin(1.0, gScale) * MathMin(1.0, extraScale);
      cap *= thr;
   }
   double slOrig = slDist;
   if(RiskLots(slDist, riskPct, lotScale, extraScale, cap, tag, lots, tv, ts)) return true;
   if(InpRcClampFrac <= 0 || InpLotMode != LOT_RISK_PCT || cap <= 0) return false;
   if(mod < 0 || mod > 30 || ((InpRcClampMask >> mod) & 1) == 0) return false;
   if(mod == MOD_NY && tag != "NY_PULLBACK") return false;
   if(tv <= 0 || ts <= 0) return false;
   double eq = AccountInfoDouble(ACCOUNT_EQUITY), step = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP), vmin = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   if(eq <= 0 || step <= 0 || vmin <= 0) return false;
   double nat = MathFloor(eq * riskPct / 100.0 / (slOrig / ts * tv) / step) * step;
   if(nat >= vmin) return false;                                         // skipped for another reason (max lot / open risk)
   if(100.0 * vmin * (slOrig / ts * tv) / eq <= cap) return false;       // min lot already within the cap: not a distance problem
   double a5 = Val(hATR, 0, 1);                                          // M5 ATR(14), last closed bar
   if(a5 == EMPTY_VALUE || a5 <= 0) return false;
   double D = cap / 100.0 * eq / (vmin * tv / ts);
   D = MathFloor(D / ts + 1e-9) * ts;                                    // round DOWN to the tick size
   double maxPct = (mod == MOD_PM) ? InpSpreadPctPM : InpSpreadPct;
   for(int k = 0; k < 3; k++, D -= ts)
   {
      if(D <= 0 || D >= slOrig) return false;                            // never further than the original
      double nsl = NormalizeDouble(entry - dir * D, _Digits);
      double nd  = (entry - nsl) * dir;
      if(nd <= 0 || nd >= slOrig) return false;
      if(nd < InpRcClampFrac * slOrig || nd < InpRcClampMinATR * a5 || nd < stopLv) return false;
      if(spread > nd * maxPct / 100.0) { gStatus = "ข้าม: spread กว้างเกิน (" + tag + ")"; return false; }
      if(tp > 0)
      {
         double tpDist = (tp - entry) * dir;
         if(tpDist < nd * minRR || tpDist < stopLv) { gStatus = "ข้าม: RR ต่ำ (" + tag + ")"; return false; }
      }
      if(RiskLots(nd, riskPct, lotScale, extraScale, cap, tag, lots, tv, ts))
      {
         XLog(StringFormat("RECENT clamp %s: SL dist %.2f -> %.2f (cap %.2f%%, lot %.2f)", tag, slOrig, nd, cap, lots));
         sl = nsl; slDist = nd;
         return true;
      }
   }
   return false;
}

//+------------------------------------------------------------------+
//| v2.60 sleeves (InpSleeveMode = 1). LEGACY = modules 0..9,          |
//| NEW = modules 10..12. Each sleeve has its own P/L curve            |
//| (realised deals by magic since gSlvT0 + floating) and              |
//|   DD% = (P/L peak - P/L now) / account equity at that peak x 100.  |
//| scale = 0.25 if DD >= InpSleeveDDQuarter, 0.5 if >= InpSleeveDDHalf|
//| else 1. It multiplies the account throttle gScale (both <= 1), so  |
//| the product never exceeds 1. The account hard halt (InpDDHalt) is  |
//| shared and unchanged. Mode 0: nothing here runs, scales stay 1.    |
//+------------------------------------------------------------------+
int    SleeveOf(int mod)   { return mod >= MOD_ORBA ? 1 : 0; }
string SleeveName(int s)   { return s == 0 ? "LEGACY" : "NEW"; }

void SleeveInit()
{
   for(int s = 0; s < 2; s++) { gSlvScale[s] = 1.0; gSlvClosed[s] = 0; gSlvPeak[s] = 0; gSlvPeakEq[s] = 0; gSlvDD[s] = 0; }
   gSlvT0 = 0;
   if(InpSleeveMode != 1) return;
   double eq = AccountInfoDouble(ACCOUNT_EQUITY);
   if(InpResetHalt)                                                      // manual reset restarts the sleeve curves too
   {
      GlobalVariableDel(gPfx + "slv_t0");
      for(int s = 0; s < 2; s++) { GlobalVariableDel(gPfx + "slvpk" + IntegerToString(s)); GlobalVariableDel(gPfx + "slvpe" + IntegerToString(s)); }
   }
   gSlvT0 = (datetime)(long)GVGet("slv_t0", 0);
   if(gSlvT0 == 0)
   {
      gSlvT0 = TimeCurrent() > 0 ? TimeCurrent() : TimeTradeServer();
      GVSet("slv_t0", (double)gSlvT0);
   }
   if(HistorySelect(gSlvT0, TimeCurrent() + 60))                         // realised P/L since the sleeve start (survives restarts)
      for(int i = 0; i < HistoryDealsTotal(); i++)
      {
         ulong d = HistoryDealGetTicket(i);
         if(d == 0 || HistoryDealGetString(d, DEAL_SYMBOL) != _Symbol) continue;
         long mg = HistoryDealGetInteger(d, DEAL_MAGIC);
         if(!IsOurMagic(mg)) continue;
         gSlvClosed[SleeveOf((int)(mg - InpMagicBase - 1))] += HistoryDealGetDouble(d, DEAL_PROFIT) + HistoryDealGetDouble(d, DEAL_SWAP)
                                                              + HistoryDealGetDouble(d, DEAL_COMMISSION);
      }
   for(int s = 0; s < 2; s++)
   {
      gSlvPeak[s]   = GVGet("slvpk" + IntegerToString(s), 0.0);
      gSlvPeakEq[s] = GVGet("slvpe" + IntegerToString(s), eq);
      GVSet("slvpk" + IntegerToString(s), gSlvPeak[s]); GVSet("slvpe" + IntegerToString(s), gSlvPeakEq[s]);
   }
}

void SleeveUpdate()                                                      // every tick, mode 1 only. Note: changes the selected position
{
   double fl[2] = {0.0, 0.0};
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong t = PositionGetTicket(i);
      if(t == 0 || PositionGetString(POSITION_SYMBOL) != _Symbol) continue;
      long mg = PositionGetInteger(POSITION_MAGIC);
      if(!IsOurMagic(mg)) continue;
      fl[SleeveOf((int)(mg - InpMagicBase - 1))] += PositionGetDouble(POSITION_PROFIT) + PositionGetDouble(POSITION_SWAP);
   }
   double eq = AccountInfoDouble(ACCOUNT_EQUITY);
   for(int s = 0; s < 2; s++)
   {
      double pl = gSlvClosed[s] + fl[s];
      if(pl > gSlvPeak[s] || gSlvPeakEq[s] <= 0)
      {
         gSlvPeak[s] = MathMax(pl, gSlvPeak[s]); gSlvPeakEq[s] = eq;
         GVSet("slvpk" + IntegerToString(s), gSlvPeak[s]); GVSet("slvpe" + IntegerToString(s), gSlvPeakEq[s]);
      }
      double dd = gSlvPeakEq[s] > 0 ? MathMax(0.0, (gSlvPeak[s] - pl) / gSlvPeakEq[s] * 100.0) : 0.0;
      double sc = dd >= InpSleeveDDQuarter ? 0.25 : (dd >= InpSleeveDDHalf ? 0.5 : 1.0);
      if(sc != gSlvScale[s]) XLog(StringFormat("sleeve %s: DD %.1f%% -> risk scale %.2f", SleeveName(s), dd, sc));
      gSlvDD[s] = dd; gSlvScale[s] = sc;
   }
}

//+------------------------------------------------------------------+
//| v2.60 per-module circuit breaker (InpModBreaker) for ORB_A / DM_A  |
//| / DM_L. R of a deal = net profit / initial risk money of its       |
//| position. DD in R = peak of the cumulative R - cumulative R.       |
//|   DD > limit        -> module risk x0.5                            |
//|   DD > 1.5 x limit  -> module disabled (x0) until the curves are   |
//|                        cleared with InpModBreakerReset             |
//| The scale is 1, 0.5 or 0: it can only reduce risk.                 |
//+------------------------------------------------------------------+
double BreakerLimit(int k) { return k == 0 ? InpModBreakerR_ORBA : (k == 1 ? InpModBreakerR_DMA : InpModBreakerR_DML); }

void BreakerEval(int k)
{
   double lim = BreakerLimit(k), dd = gBrkPeak[k] - gBrkCum[k];
   double sc = (lim > 0 && dd > 1.5 * lim) ? 0.0 : ((lim > 0 && dd > lim) ? 0.5 : 1.0);
   if(sc != gBrkScale[k])
      XLog(StringFormat("module breaker %s: DD %.1fR (limit %.1fR) -> %s", ModName(MOD_ORBA + k), dd, lim,
           sc <= 0 ? "module DISABLED - review, then InpModBreakerReset" : (sc < 1 ? "risk x0.5" : "risk x1")));
   gBrkScale[k] = sc;
}

void BreakerInit()
{
   for(int k = 0; k < 3; k++)
   {
      gBrkCum[k] = 0; gBrkPeak[k] = 0; gBrkScale[k] = 1.0;
      if(!InpModBreaker) continue;
      string kc = "brkc" + IntegerToString(k), kp = "brkp" + IntegerToString(k);
      if(InpModBreakerReset) { GlobalVariableDel(gPfx + kc); GlobalVariableDel(gPfx + kp); }
      gBrkCum[k] = GVGet(kc, 0.0); gBrkPeak[k] = MathMax(GVGet(kp, 0.0), gBrkCum[k]);
      BreakerEval(k);
   }
}

//--- deal stream (OnTradeTransaction, DEAL_ADD of our magics): sleeve realised P/L and breaker R. Reads gPos only.
void RiskOnDeal(int mod, ulong pid, long entry, double net)
{
   if(mod < 0 || mod >= MODS) return;
   if(InpSleeveMode == 1) gSlvClosed[SleeveOf(mod)] += net;
   if(InpModBreaker && mod >= MOD_ORBA && net != 0 && (entry == DEAL_ENTRY_IN || entry == DEAL_ENTRY_OUT))
   {
      int    k  = mod - MOD_ORBA, pi = PosFind(pid);
      double rm = (pi >= 0) ? gPos[pi].riskMoney : AccountInfoDouble(ACCOUNT_BALANCE) * BaseRiskPct(mod) / 100.0;
      if(rm <= 0) return;
      gBrkCum[k] += net / rm;
      if(gBrkCum[k] > gBrkPeak[k]) gBrkPeak[k] = gBrkCum[k];
      GVSet("brkc" + IntegerToString(k), gBrkCum[k]); GVSet("brkp" + IntegerToString(k), gBrkPeak[k]);
      BreakerEval(k);
   }
}

//--- sleeve scale x breaker scale for a module, always within [0, 1]; exactly 1.0 when both features are off
double RiskExtraScale(int mod)
{
   double s = 1.0;
   if(InpSleeveMode == 1) s *= gSlvScale[SleeveOf(mod)];
   if(InpModBreaker && mod >= MOD_ORBA && mod < MODS) s *= gBrkScale[mod - MOD_ORBA];
   return MathMin(1.0, MathMax(0.0, s));
}

//+------------------------------------------------------------------+
//| v2.60 order-error halt: InpMaxConsecOrderErr consecutive failed    |
//| order sends -> no new entries (and add-ons) until the next UTC day |
//+------------------------------------------------------------------+
void OrderErrNote(bool ok, string tag)
{
   if(ok) { gOrdErr = 0; return; }
   gOrdErr++;
   if(InpMaxConsecOrderErr > 0 && gOrdErr >= InpMaxConsecOrderErr && !gOrdErrStop)
   {
      gOrdErrStop = true;
      XLog(StringFormat("%d consecutive order errors (last: %s, retcode %d) - no new entries until the next day",
           gOrdErr, tag, (int)trade.ResultRetcode()));
   }
}
bool OrderErrBlocked() { return InpMaxConsecOrderErr > 0 && gOrdErrStop; }

//+------------------------------------------------------------------+
//| v2.60 after every market order: the position must carry a broker   |
//| side SL. If it does not, it is closed at once. Returns true when   |
//| the emergency close was triggered. Changes the selected position.  |
//+------------------------------------------------------------------+
bool EmergencyNoSL(ulong pid, long mg, string tag)
{
   bool sel = gNetting ? PositionSelect(_Symbol) : (pid != 0 && PositionSelectByTicket(pid));
   if(!sel) return false;                                                // not filled yet / already gone
   if(PositionGetString(POSITION_SYMBOL) != _Symbol || PositionGetInteger(POSITION_MAGIC) != mg) return false;
   if(PositionGetDouble(POSITION_SL) > 0) return false;
   ulong t = (ulong)PositionGetInteger(POSITION_TICKET);
   trade.SetExpertMagicNumber(mg);
   bool closed = trade.PositionClose(t);
   XLog(StringFormat("EMERGENCY: no SL on %s position #%I64u - %s", tag, t,
        closed ? "closed" : "CLOSE FAILED retcode " + IntegerToString((int)trade.ResultRetcode())));
   gStatus = "EMERGENCY: no SL (" + tag + ")";
   if(gTgOn) TgSend(StringFormat("XMS %s EMERGENCY: no SL on %s - position %s", _Symbol, tag, closed ? "closed" : "CLOSE FAILED"));
   return true;
}

void RiskInit()
{
   gOrdErr = 0; gOrdErrStop = false;
   SleeveInit();
   BreakerInit();
}
void RiskNewDay() { gOrdErr = 0; gOrdErrStop = false; }

//--- extra lines for the chart Comment (used only when the dashboard is off)
string RiskComment()
{
   string s = "\nMode: " + ModeString() + (InpStrategyMode == MODE_AUTO ? StringFormat(" | H1 ATR24 %.2f", gAutoATR) : "") + "\nregime " + RegString() + (RegOK() ? StringFormat(" | ADX %.1f | ATR14 %.2f | ATR24 pct %.0f", RegADX(), RegATR14(), RegATR24Pct()) : "");
   if(InpSleeveMode == 1) s += StringFormat("\nsleeve LEGACY x%.2f (DD %.1f%%) | NEW x%.2f (DD %.1f%%)", gSlvScale[0], gSlvDD[0], gSlvScale[1], gSlvDD[1]);
   if(InpModBreaker) s += StringFormat("\nbreaker ORB_A x%.2f | DM_A x%.2f | DM_L x%.2f", gBrkScale[0], gBrkScale[1], gBrkScale[2]);
   if(InpNYPBDirFilter > 0) s += "\ndir filter: " + DirString();        // v2.70
   if(InpMinLotMaxRiskNew >= 0 || InpMinLotMaxRiskLegacy >= 0)
      s += StringFormat("\nmin-lot cap LEGACY %.2f%% | NEW %.2f%%", MinLotCap(MOD_ASIA), MinLotCap(MOD_ORBA));
   if(OrderErrBlocked()) s += "\nORDER ERRORS: entries halted for today";
   if(gNetting) s += "\nNETTING: one position at a time";
   return s;
}
