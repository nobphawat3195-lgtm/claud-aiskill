//+------------------------------------------------------------------+
//|  XAU_MultiSession_EA v2.90 USD — EA ทองคำหลายเซสชัน (XAUUSD, M5)   |
//|  v2.90 USD: InpStrategyMode CLASSIC (= v2.80 bit-identical) /      |
//|   RECENT / AUTO (H1 Wilder ATR24 hysteresis). RECENT: min-lot cap  |
//|   inputs + SL clamp so 0.01 lot risks <= cap (NY_PB, ASIA_B)       |
//|  v2.80 USD (all new inputs default OFF = trade-for-trade v2.70):   |
//|   InpNYPBDirFilter=3 soft filter, InpLegacyFlatMin (later legacy    |
//|   flat), InpBEOnlyR_NY / _AsiaB / _LonA (break-even-only rule)      |
//|  v2.70 USD (Standard USD account, min lot 0.01): optional, all OFF |
//|   by default = v2.60: NY_PB / PM_CONT direction filter (07:00 UTC  |
//|   close vs day open, same source as DM_L), per-group min-lot caps  |
//|                                                                  |
//|  โมดูล (magic = base + n):                                        |
//|   1 Asia   00:30-06:00 UTC  BB range fade                         |
//|   2 London 07:00-10:30 UTC  Asian box breakout + sweep reversal   |
//|   3 NY     12:30-16:00 UTC  ORB + EMA pullback ตาม bias           |
//|   4 NY-PM  16:00-20:00 UTC  continuation หรือ VWAP fade ตามวัน     |
//|  เวลาด้านบนเป็นฤดูหนาว London เลื่อนตาม DST ยุโรป NY ตาม DST สหรัฐ    |
//|                                                                  |
//|  v2.60 modular build: XMS_Regime / XMS_Strategy_Legacy /           |
//|   XMS_Strategy_New / XMS_Entry / XMS_Exit / XMS_Risk / XMS_Log /    |
//|   XMS_Dashboard (.mqh). This file = inputs, globals, event handlers |
//|  v2.60: optional (all OFF by default = v2.50): pyramiding add-ons   |
//|   (tag "<TAG>+P", SL = parent entry), re-entry after an SL stop-out, |
//|   M15 ATR runner trail for parent positions                         |
//|  v2.50: optional (all OFF by default = v2.40): equity-curve risk     |
//|   multiplier, partial close at N x R, volatility shock filter,      |
//|   H4/H1 EMA confirmation, Telegram notifications, risk debug in CSV |
//|  v2.10 defaults = best backtest config (ASIA_A+ASIA_B+LON_A+NY_PB, 2%) |
//|  v2.00: median-spread guard, news/holiday filter (FOMC/NFP + CSV), |
//|   min-lot สำหรับบัญชีเล็ก, reset state ใน tester, OnTester criterion |
//|  ข้อจำกัดที่ยังเหลือ:                                              |
//|   - เข้าไม้ด้วย market order เมื่อแท่ง M5 ปิด ไม่ใช้ pending          |
//|   - ยังไม่มี news filter และตารางวันหยุด                           |
//|   - ต้องใช้บัญชี hedging (netting จะรวม position ข้ามโมดูล)         |
//|  แบบเต็ม: MQL5/Docs/XAU_MultiSession_EA_Design.md                 |
//+------------------------------------------------------------------+
#property copyright "XAU MultiSession EA"
#property version   "2.91"
#property description "XAU MultiSession EA v2.90 USD - Standard USD account (min lot 0.01, contract 100)"
#property strict


#include <Trade\Trade.mqh>

enum ENUM_DST_MODE { DST_NONE, DST_US, DST_EU };
enum ENUM_LOT_MODE { LOT_FIXED = 0, LOT_RISK_PCT = 1, LOT_AUTO = 2 };
enum ENUM_STRATEGY_MODE { MODE_CLASSIC = 0, MODE_RECENT = 1, MODE_AUTO = 2 };   // v2.90

#define MOD_ASIA   0
#define MOD_LONDON 1
#define MOD_NY     2
#define MOD_PM     3
#define MOD_ASIAB  4
#define MOD_LONC   5
#define MOD_ASIAC  6
#define MOD_OVLB   7
#define MOD_LDNB   8
#define MOD_SCALP  9
#define MOD_ORBA   10
#define MOD_DMA    11
#define MOD_DML    12
#define MODS       13

input group "=== ทั่วไป ==="
input long          InpMagicBase       = 880000;   // Magic base (โมดูล = base+1..4)
input int           InpServerGMTWinter = 0;        // GMT offset ของเซิร์ฟเวอร์ช่วงฤดูหนาว
input ENUM_DST_MODE InpServerDST       = DST_NONE;   // กฎ DST ของเซิร์ฟเวอร์
input bool          InpUseAsia         = true;     // เปิดโมดูล Asia
input bool          InpUseLondon       = true;     // เปิดโมดูล London
input bool          InpUseNY           = true;     // เปิดโมดูล NY
input bool          InpUsePM           = false;     // เปิดโมดูล NY-PM

input group "=== ความเสี่ยง ==="
input double InpRiskMain      = 2.0;    // Risk ต่อไม้ London / NY (% equity)
input double InpRiskMinor     = 0.75;   // Risk ต่อไม้ Asia / NY-PM (% equity)
input double InpMaxOpenRisk   = 8.0;    // Risk รวมที่เปิดอยู่สูงสุด (%)
input double InpDailyLossPct  = 6.0;    // Daily loss (%) แล้วหยุดทั้งวัน
input double InpDDHalf        = 25.0;   // DD จาก peak (%) ลด risk เหลือครึ่ง
input double InpDDQuarter     = 40.0;   // DD จาก peak (%) ลด risk เหลือหนึ่งในสี่
input double InpDDHalt        = 45.0;   // DD จาก peak (%) หยุด EA
input bool   InpResetHalt     = false;  // true = ล้างสถานะหยุดและตั้ง peak ใหม่ตอนเริ่ม
input double InpMaxLot        = 5.0;    // Lot สูงสุดต่อไม้
input double InpSpreadPct     = 15.0;   // Spread สูงสุด (% ของระยะ SL)
input double InpSpreadPctPM   = 12.0;   // Spread สูงสุดของ NY-PM (% ของระยะ SL)
input double InpMedSpreadMult = 2.0;    // Spread ไม่เกิน N เท่าของ median 200 tick ล่าสุด (0=ปิด)
input ENUM_LOT_MODE InpLotMode = LOT_RISK_PCT; // วิธีคิด lot: FIXED / RISK_PCT / AUTO (ตามทุน)
input double InpFixedLot      = 0.01;   // FIXED: lot ต่อไม้
input double InpAutoPerBal    = 500.0;  // AUTO: 0.01 lot ต่อทุนทุก ๆ $X (balance)
input double InpAutoMaxRisk   = 3.0;    // AUTO/FIXED: ลด lot ถ้า risk ต่อไม้เกิน % นี้ (ข้ามถ้า min lot ยังเกิน)
input int    InpMaxPositions  = 0;      // จำนวนไม้เปิดพร้อมกันสูงสุดทุกโมดูล (0 = ไม่จำกัด)
input double InpRiskLondon    = 2.0;    // Risk ต่อไม้ LON_A (%) (RISK_PCT)
input double InpMinLotMaxRisk = 2.0;    // บัญชีเล็ก: ถ้า lot คำนวณได้ < min lot ให้ใช้ min lot ถ้า risk จริง <= ค่านี้ (%) (0=ปิด)

input group "=== ข่าว / วันหยุด ==="
input bool   InpNewsFilter    = true;   // งดเปิดไม้ใหม่รอบข่าว USD (FOMC, NFP ในตัว + CSV)
input int    InpNewsBefore    = 30;     // นาทีก่อนข่าว
input int    InpNewsAfter     = 30;     // นาทีหลังข่าว
input bool   InpNewsCloseAll  = false;  // ปิดไม้ทั้งหมดก่อนข่าว
input bool   InpFOMCNoPM      = true;   // วัน FOMC ปิดโมดูล NY-PM ทั้งวัน
input string InpNewsFile      = "xau_news.csv"; // ไฟล์ข่าวเพิ่ม (Common\Files) บรรทัดละ "YYYY.MM.DD HH:MM" เวลา UTC
input bool   InpHolidayFilter = true;   // ไม่เทรด 24-26 ธ.ค., 31 ธ.ค.-2 ม.ค. และวันหยุดสหรัฐหลัก

input group "=== การจัดการไม้ ==="
input double InpPartialPct    = 40.0;   // % of volume closed by the partial close (InpPartialMode=1, and legacy InpBEAtR>0; v2.40 default was 50)
input double InpTrailATR      = 1.2;    // Trailing หลัง BE (×ATR M5)
input double InpBEAtR         = 0.0;    // ปิดบางส่วน + เลื่อน BE เมื่อกำไรถึง N×R (0 = ไม่ทำ, ถือถึง SL/TP/เวลา)
input bool   InpHandoffClose  = false;   // 16:00 ปิดไม้ London/NY ที่ยังไม่ถึง BE
input double InpTrailStepATR  = 0.1;    // ขยับ SL เมื่อดีขึ้นอย่างน้อย (×ATR) ลดการแก้ order ถี่
input int    InpTimeStopAsia  = 0;     // Time-stop Asia (แท่ง M5)
input int    InpTimeStopMain  = 0;      // Time-stop London / NY (แท่ง M5)
input int    InpTimeStopPM    = 10;     // Time-stop NY-PM (แท่ง M5)

input group "=== ตัวกรองเทรนด์ใหญ่ ==="
input int    InpHTFEMA        = 50;     // เข้าเฉพาะทิศเดียวกับ EMA ของ TF ใหญ่ (0 = ปิด)
input ENUM_TIMEFRAMES InpHTFTF = PERIOD_D1; // TF ของ EMA เทรนด์ใหญ่

input group "=== v2.40 Regime filter: D1 efficiency ratio (stretched trend) ==="
input int    InpRegimeMode     = 0;     // 0 = off, 1 = block new trades, 2 = scale risk when ER > max
input int    InpRegimeERDays   = 20;    // D1 efficiency-ratio lookback (days, ending yesterday)
input double InpRegimeERMax    = 0.30;  // Regime is "stretched" when ER > this
input double InpRegimeRiskMult = 0.5;   // Mode 2: risk multiplier while ER > max

input group "=== v2.50 Equity curve risk (anti-martingale) ==="
input int    InpEqRiskMode     = 0;     // 0 = off, 1 = step risk up on a winning streak near the balance peak, 2 = balance above its SMA
input double InpEqNearPeakPct  = 3.0;   // step-up only while balance >= peak x (1 - this %)
input double InpEqStepR1       = 2.0;   // streak R >= this -> InpEqMult1
input double InpEqStepR2       = 4.0;   // streak R >= this -> InpEqMult2
input double InpEqStepR3       = 6.0;   // streak R >= this -> InpEqMult3
input double InpEqMult1        = 1.5;   // risk multiplier, level 1
input double InpEqMult2        = 2.0;   // risk multiplier, level 2
input double InpEqMult3        = 3.0;   // risk multiplier, level 3
input double InpEqResetDDPct   = 8.0;   // balance DD from peak (%) above which streak R resets to 0
input int    InpEqSMAN         = 10;    // mode 2: SMA length, in closed positions (balance sampled after each full close)
input double InpEqSMAMult      = 2.0;   // mode 2: risk multiplier while balance > SMA of the last InpEqSMAN samples

input group "=== v2.50 Partial close at N x R (volume % = InpPartialPct) ==="
input int    InpPartialMode    = 0;     // 0 = off, 1 = close part of the position once at InpPartialR
input double InpPartialR       = 1.0;   // profit (x initial risk) that triggers the partial close
input bool   InpPartialBE      = false; // after the partial close move SL to entry + spread

input group "=== v2.50 Volatility shock filter ==="
input int    InpVolShockMode     = 0;   // 0 = off, 1 = block new trades for the day, 2 = scale risk
input double InpVolShockRiskMult = 0.5; // Mode 2: risk multiplier on a shock day
input int    InpVolShockATRFast  = 5;   // D1 ATR fast period
input int    InpVolShockATRSlow  = 50;  // D1 ATR slow period
input double InpVolShockMax      = 1.6; // shock if D1 ATR fast / slow > this (<= 0 = off)
input double InpVolShockRangeATR = 2.5; // shock if yesterday's D1 range > this x D1 ATR slow (<= 0 = off)
input double InpVolShockH1ATR    = 3.0; // shock if any of the last 24 H1 bars before today has range > this x H1 ATR(50) (<= 0 = off)

input group "=== v2.50 Multi-timeframe confirmation (H4 + H1 EMA) ==="
input int    InpMTFMode        = 0;     // 0 = off, 1 = filter (H4 and H1 must agree), 2 = risk weight
input int    InpMTFEMA         = 50;    // EMA period on H4 and H1
input double InpMTFAlignMult   = 1.5;   // Mode 2: risk multiplier when H4 and H1 agree
input double InpMTFMisMult     = 0.5;   // Mode 2: risk multiplier when they do not

input group "=== v2.91 Profile banner (text on the chart) ==="
input string InpProfileName    = "";    // profile shown on the chart, e.g. "STANDARD 300 USD" or "CENT 100 USD" (empty = no banner)

input group "=== v2.91 D1 trend risk tilt (ORB_A / DM_A / DM_L) + ASIA_B range-only ==="
input int    InpD1TiltMode     = 0;     // 0 = off (v2.90 behaviour), 1 = risk weight by regime D1 trend for ORB_A / DM_A / DM_L
input double InpD1TiltWith     = 1.5;   // Mode 1: risk multiplier when the trade is WITH the D1 trend
input double InpD1TiltAgainst  = 0.5;   // Mode 1: risk multiplier when the trade is AGAINST the D1 trend (D1 flat = 1.0)
input bool   InpAsiaBRangeOnly = false; // true = skip ASIA_B while the regime is TREND (H1 ADX >= 25)

input group "=== v2.50 Telegram ==="
input bool   InpTelegram       = false; // send notifications (never in tester / optimization)
input string InpTgToken        = "";    // bot token
input string InpTgChatId       = "";    // chat id
input bool   InpTgDaily        = true;  // daily summary at the daily flat time

input group "=== v2.60 New strategies (research-validated) ==="
input bool   InpUseORBA        = false; // ORB_A: Asia opening-range (00:00-01:00 UTC) breakout on M15, hold to flat
input double InpRiskORBA       = 0.75;  // ORB_A risk %
input double InpORBASLATR      = 2.0;   // ORB_A SL = signal close -/+ k x ATR(H1,14)
input int    InpORBAMaxTrades  = 2;     // ORB_A max trades per day
input bool   InpUseDMA         = false; // DM_A: 01:00 UTC day momentum vs previous day open, only H1 ADX < max
input double InpRiskDMA        = 0.75;  // DM_A risk %
input double InpDMASLATR       = 1.5;   // DM_A SL = k x ATR(H1,14)
input double InpDMAADXMax      = 25.0;  // DM_A: trade only when H1 ADX(14, Wilder) < this (RANGE regime)
input bool   InpUseDML         = false; // DM_L: 07:00 UTC day momentum vs today's open
input double InpRiskDML        = 0.25;  // DM_L risk %
input double InpDMLSLATR       = 1.5;   // DM_L SL = k x ATR(H1,14)
input int    InpNSFlatMin      = 1230;  // new strategies: fixed flat time, UTC minutes (1230 = 20:30, as researched); 0 = EA daily flat
input bool   InpNewNoHTF       = true;  // new strategies ignore the D1 EMA trend filter (as researched)
input int    InpNSATRMode      = 0;     // new strategies ATR / ADX source: 0 = Wilder from the regime engine (as researched), 1 = legacy iATR(H1,14) + iADXWilder (prototype)

input group "=== v2.60 Regime engine (closed H1 bars, Wilder) ==="
input bool   InpRegimeLog      = false; // write xms_regime.csv: one row per closed H1 bar (time UTC,adx,atr14,atr24,atr24pct,trend,hvol,brk)

input group "=== v2.60 Sleeve throttle ==="
input int    InpSleeveMode      = 0;    // 0 = shared account throttle only (as v2.50), 1 = two sleeves: LEGACY (modules 1-10) and NEW (ORB_A / DM_A / DM_L)
input double InpSleeveDDHalf    = 20.0; // mode 1: sleeve DD (%) -> sleeve risk x0.5
input double InpSleeveDDQuarter = 30.0; // mode 1: sleeve DD (%) -> sleeve risk x0.25

input group "=== v2.60 Risk safety ==="
input int    InpMaxConsecOrderErr = 5;     // consecutive order-send failures -> no new entries for the rest of the day (0 = off)
input bool   InpModBreaker        = false; // per-module circuit breaker for ORB_A / DM_A / DM_L (realised DD in R; only reduces risk)
input double InpModBreakerR_ORBA  = 26.5;  // ORB_A: DD in R above this -> risk x0.5, above 1.5x -> module disabled
input double InpModBreakerR_DMA   = 23.3;  // DM_A: DD in R above this -> risk x0.5, above 1.5x -> module disabled
input double InpModBreakerR_DML   = 37.3;  // DM_L: DD in R above this -> risk x0.5, above 1.5x -> module disabled
input bool   InpModBreakerReset   = false; // true = clear the stored breaker R curves at start (after a manual review)

input group "=== v2.60 Pyramiding ==="
input int    InpPyrMode        = 0;     // 0 = off, 1 = add to winning positions (add-on tag "<TAG>+P", SL = parent entry)
input double InpPyrTriggerR    = 1.0;   // add-on k triggers when the parent profit >= k x this x initial risk distance
input double InpPyrRiskPct     = 0.5;   // risk of each add-on (% of balance; x DD scale x equity multiplier)
input int    InpPyrMaxAdds     = 1;     // max add-ons per parent position
input bool   InpPyrMoveSL      = true;  // move the parent SL to entry + spread when an add-on is opened

input group "=== v2.60 Re-entry ==="
input int    InpReentryMode    = 0;     // 0 = off, 1 = extra entries after an SL stop-out
input int    InpReentryMax     = 1;     // extra entries per module per day (granted only after a stop-out)

input group "=== v2.60 Runner trail ==="
input int    InpTrailMode      = 0;     // 0 = off, 1 = ATR trail of parent positions after InpTrailStartR
input double InpTrailStartR    = 1.5;   // start trailing at this profit (x initial risk distance)
input double InpTrailATR15     = 1.5;   // trail distance (x M15 ATR(14)); named ...ATR15 because InpTrailATR is the legacy M5 trail

input group "=== v2.70 USD ==="
input int    InpNYPBDirFilter       = 0;    // 0 = off (v2.60), 1 = NY_PB only in the DM_L direction (sign of the M5 close at 07:00 UTC vs the 00:00 UTC day open), 2 = also require the same for NY_PM continuation (PM_CONT), 3 = SOFT (NY_PB only, PM_CONT not filtered): block a NY_PB trade only if its direction disagrees with BOTH the 07:00 UTC DM_L direction AND sign(close of the last CLOSED M5 bar - day open)
input double InpMinLotMaxRiskNew    = -1.0; // min-lot risk cap (%) used only for ORB_A / DM_A / DM_L; -1 = use InpMinLotMaxRisk (v2.60 behaviour)
input double InpMinLotMaxRiskLegacy = -1.0; // min-lot risk cap (%) used only for the legacy modules; -1 = use InpMinLotMaxRisk (v2.60 behaviour)

input group "=== v2.80 USD ==="
input int    InpLegacyFlatMin  = 0;    // UTC minutes; 0 = v2.70 (EA daily flat); >0 = legacy positions (all modules except ORB_A/DM_A/DM_L) are closed at this UTC time instead of the EA daily flat (1230 = 20:30). New entries / cut-offs unchanged. On Fridays: min(value, Friday flat)
input double InpBEOnlyR_NY     = 0.0;  // >0: NY_PB position: once open profit >= N x initial risk distance, SL -> entry +/- spread (only tightens; no partial close, no trailing; evaluated on ticks). 0 = off
input double InpBEOnlyR_AsiaB  = 0.0;  // same for ASIA_B (0 = off)
input double InpBEOnlyR_LonA   = 0.0;  // same for LON_A (0 = off)

input group "=== v2.90 USD - Strategy mode / Recent regime ==="
input ENUM_STRATEGY_MODE InpStrategyMode = MODE_CLASSIC; // CLASSIC = v2.80 exactly (คลาสสิก = เหมือน v2.80 ทุกประการ) | RECENT = always use the recent set below (ใช้ชุด recent เสมอ) | AUTO = switch by H1 Wilder ATR(24) with hysteresis (สลับอัตโนมัติตาม ATR H1)
input double InpAutoATRHi       = 12.0; // AUTO: H1 ATR(24) in $ >= this -> RECENT set on (ATR สูง -> เปิดชุด recent)
input double InpAutoATRLo       = 10.0; // AUTO: H1 ATR(24) in $ < this -> back to CLASSIC; between Lo and Hi keep the previous state (hysteresis)
input double InpRcMinLotCapLegacy = -1.0; // RECENT: min-lot risk cap (%) for legacy modules; -1 = same as classic MinLotCap (เพดาน risk ของ min lot, -1 = เท่า classic)
input double InpRcMinLotCapNew    = 5.5;  // RECENT: same for ORB_A / DM_A / DM_L; -1 = same as classic
input double InpRcClampFrac     = 0.0;  // RECENT: SL clamp, 0 = off. If min lot risk with the original SL > cap, use D' = cap% x equity / (minlot x tickvalue/ticksize) (rounded DOWN to tick) only when D' >= this x original SL distance (บีบ SL เข้าใกล้ราคา)
input double InpRcClampMinATR   = 1.0;  // RECENT clamp: also require D' >= this x ATR(M5,14) of the last closed bar
input int    InpRcClampMask     = 20;   // RECENT clamp: bitmask of modules (1<<MOD_*): NY=bit2 (NY_PULLBACK tag only), ASIA_B=bit4 -> (1<<2)|(1<<4) = 20
input bool   InpRcCapThrottle   = false; // RECENT: min-lot cap x account DD scale (gScale) x sleeve scale, so the 0.01-lot round-up also respects the DD throttles (ลด cap ตาม DD throttle)
input bool   InpRcNoPM          = true;  // RECENT: skip the NY-PM module (PM_CONT/PM_FADE) while the recent set is active (ปิด NY-PM ในโหมด recent)

input group "=== Asia ==="
input double InpAsiaMaxBoxADR = 0.35;   // กรอบเอเชียสูงสุด (×ADR)
input double InpAsiaADXMax    = 20.0;   // ADX(M15) สูงสุด
input double InpAsiaRSILow    = 30.0;   // RSI(7) ฝั่งล่าง (ฝั่งบน = 100 - ค่านี้)
input double InpAsiaSLATR     = 1.0;    // SL เลย extreme (×ATR)
input int    InpAsiaMaxTrades = 3;      // ไม้สูงสุดต่อวัน
input int    InpAsiaMaxLosses = 2;      // แพ้ติดกันแล้วหยุด

input group "=== v2.1 โมดูลใหม่ตามเทรนด์ D1 (ถือถึง SL หรือ flat 20:30) ==="
input int    InpAsiaMode      = 1;      // Asia: 0 = BB fade เดิม, 1 = EMA20 pullback ตามเทรนด์ (ASIA_A)
input int    InpAsiaAStart    = 60;     // ASIA_A เริ่ม (นาที UTC)
input int    InpAsiaAEnd      = 300;    // ASIA_A สิ้นสุด (นาที UTC)
input double InpRiskAsia      = 2.0;    // Risk ต่อไม้ Asia (%)
input bool   InpAsiaHold      = true;   // true = ไม่ปิดไม้ Asia ตอน 06:30 (ถือถึง flat)
input bool   InpUseAsiaB      = true;   // ASIA_B: M15 ปิดเหนือ high / ใต้ low ของวันก่อน (00:00-06:00)
input double InpRiskAsiaB     = 2.0;    // Risk ต่อไม้ ASIA_B (%)
input double InpAsiaBSLATR    = 1.0;    // ASIA_B SL เลยแท่ง M15 (×ATR M15)
input int    InpLonMode       = 1;      // London: 0 = เดิม (breakout/sweep), 1 = LDN_A box breakout บน M15 ตามเทรนด์
input bool   InpUseLonC       = false;   // LDN_C: EMA20 pullback 07:30-10:30 + VWAP ที่เริ่มนับตอน London เปิด
input double InpRiskLonC      = 1.0;    // Risk ต่อไม้ LDN_C (%)
input int    InpNewMaxTrades  = 2;      // ไม้สูงสุดต่อวันของ pullback ใหม่ (ASIA_A, LDN_C)
input int    InpNewMaxLosses  = 1;      // แพ้กี่ไม้แล้วหยุดโมดูลวันนั้น (โมดูลใหม่)

input group "=== London ==="
input double InpLonBoxMinADR  = 0.15;   // กรอบเอเชียขั้นต่ำ (×ADR)
input double InpLonBoxMaxADR  = 0.45;   // กรอบเอเชียสูงสุด (×ADR)
input bool   InpLonBreakout   = true;   // โหมด A: breakout
input bool   InpLonSweep      = true;   // โหมด B: sweep reversal
input double InpLonBreakATR   = 0.10;   // ระยะปิดนอกกรอบขั้นต่ำ (×ATR)
input double InpLonSweepATR   = 0.15;   // ระยะ sweep ขั้นต่ำ (×ATR)
input double InpLonSLATR      = 1.5;    // SL สูงสุดของ breakout (×ATR)
input int    InpLonMaxTrades  = 3;      // ไม้สูงสุดต่อวัน

input group "=== New York ==="
input bool   InpNYORB         = false;   // Setup 1: ORB 15 นาที
input bool   InpNYPullback    = true;   // Setup 2: pullback EMA20
input double InpNYADXMin      = 20.0;   // ADX(M15) ขั้นต่ำของ pullback
input double InpNYMaxSLATR    = 2.0;    // SL สูงสุด (×ATR)
input int    InpNYMaxTrades   = 4;      // ไม้สูงสุดต่อวัน
input int    InpNYMaxLosses   = 2;      // แพ้ติดกันแล้วหยุด

input group "=== NY-PM ==="
input double InpPMTrendADR    = 1.0;    // Trend day: range ของวันขั้นต่ำ (×ADR)
input double InpPMRangeADR    = 0.7;    // Range day: range ของวันสูงสุด (×ADR)
input double InpPMTrendADX    = 25.0;   // Trend day: ADX(M15) ขั้นต่ำ
input double InpPMRangeADX    = 20.0;   // Range day: ADX(M15) สูงสุด
input int    InpPMMinCrosses  = 3;      // Range day: จำนวนครั้งที่ราคาตัด VWAP ขั้นต่ำ
input int    InpPMMaxTrades   = 2;      // ไม้สูงสุดต่อวัน
input int    InpPMMaxLosses   = 1;      // แพ้ติดกันแล้วหยุด

input group "=== v2.31 พารามิเตอร์ setup (ค่าเริ่มต้น = v2.30) ==="
input double InpAsiaBufATR = 0.3;   // ASIA_A: SL เลย low/high 2 แท่ง (×ATR M5)
input double InpNYBufATR   = 0.3;   // NY_PB: SL เลย low/high 2 แท่ง (×ATR M5)
input double InpLonASLATR  = 1.0;   // LON_A: SL อย่างน้อย N×ATR M15 (ไม่งั้นใช้กลางกรอบ)
input int    InpLonAWindow = 210;   // LON_A: เข้าได้กี่นาทีหลัง London เปิด
input int    InpPBEMA      = 20;    // EMA (M5) ของ pullback ASIA_A / NY_PB
input double InpAsiaAMinBal = 0;     // ASIA_A เทรดเมื่อ balance >= ค่านี้เท่านั้น (บัญชีเล็ก, 0 = ปิด)

input group "=== v2.40 ASIA_B ==="
input int    InpAsiaBMaxTrades = 1;     // ASIA_B: max trades per day (2nd only after the 1st closed)

input group "=== v2.40 ASIA_C: 00:00-02:00 range breakout (M15 close, D1 trend) ==="
input bool   InpUseAsiaC      = false;  // enable ASIA_C
input double InpRiskAsiaC     = 1.0;    // ASIA_C risk per trade (%)
input double InpAsiaCMaxATRH1 = 1.5;    // ASIA_C: skip if range > N x ATR(H1,14)
input double InpAsiaCSLATR    = 0.5;    // ASIA_C: SL = range midpoint, at least N x ATR M15 from entry

input group "=== v2.40 OVL_B: 07:00-12:00 range breakout (M15 close 12:30-16:00, D1 trend) ==="
input bool   InpUseOvlB       = false;  // enable OVL_B
input double InpRiskOvlB      = 1.0;    // OVL_B risk per trade (%)
input double InpOvlBSLATR     = 1.0;    // OVL_B: SL beyond signal M15 bar (x ATR M15)

input group "=== v2.40 LDN_B: counter-trend sweep of the pre-London box, reclaim with D1 trend ==="
input bool   InpUseLdnB       = false;  // enable LDN_B
input double InpRiskLdnB      = 1.0;    // LDN_B risk per trade (%)
input double InpLdnBSLATR     = 0.3;    // LDN_B: SL beyond sweep extreme (x ATR M5)

input group "=== v2.40 SCALP: M5 EMA pullback scalp with fixed TP (D1 + M15 EMA50 + VWAP) ==="
input bool   InpUseScalp       = false; // enable SCALP
input double InpRiskScalp      = 1.0;   // SCALP risk per trade (%)
input int    InpScalpStart     = 750;   // SCALP start (minutes UTC; 420 = 07:00, 750 = 12:30)
input int    InpScalpEnd       = 960;   // SCALP end (minutes UTC; 960 = 16:00)
input double InpScalpSLATR     = 1.0;   // SCALP: SL beyond low/high of last 2 M5 bars (x ATR M5)
input double InpScalpTPR       = 1.5;   // SCALP: TP = N x risk
input int    InpScalpMaxTrades = 4;     // SCALP: max trades per day
input int    InpScalpMaxLosses = 2;     // SCALP: stop for the day after N consecutive losses

input group "=== Dashboard ==="
input bool             InpDashboard  = true;               // แสดงแดชบอร์ดบนกราฟ (ปิดเองตอน optimize / tester ไม่ใช่ visual)
input ENUM_BASE_CORNER InpDashCorner = CORNER_LEFT_UPPER;  // มุมของแดชบอร์ด
input double           InpDashScale  = 1.0;                // ขนาด (0.8 - 1.5)

input group "=== Log ==="
input bool   InpWriteLog      = false;   // บันทึก CSV ทุกไม้
input string InpLogFile       = "xau_multisession_trades.csv";
input bool   InpEquityLog     = false;  // บันทึก balance/equity ทุกแท่ง M5 (สำหรับกราฟ backtest)

//--- globals
CTrade   trade;
int      hATRH1 = INVALID_HANDLE;   // v2.40: ATR(H1,14) for ASIA_C
int      hATR15 = INVALID_HANDLE, hATR, hADX, hBB, hRSI, hEMA20, hEMA50, hHTF = INVALID_HANDLE;
datetime gLastBar = 0;
long     gDayKey  = -1;
string   gPfx;
double   gScale   = 1.0;          // ตัวคูณ risk ตาม DD
bool     gHalted  = false, gDayStop = false;
double   gDayStartEq = 0;
// หน้าต่างเวลา (นาทีของวัน UTC)
int      gLonS, gLonE, gNyS, gNyE, gOrbS, gPmS, gPmE, gFlat;
long     gOffSec = 0;             // server - UTC (วินาที)
// ข้อมูลของวัน (จากแท่ง M5 ที่ปิดแล้ว)
MqlRates gR[];
int      gN = 0;
double   gATR = 0, gATRAvg = 0, gADR = 0, gADX = 0;
// v2.90 AUTO regime latch (XMS_Risk.mqh)
bool     gAutoHi = false, gAutoInit = false;
datetime gAutoBar = 0;
double   gAutoATR = 0;
double   gDayHi, gDayLo, gAsiaHi, gAsiaLo, gOrbHi, gOrbLo, gPreHi, gPreLo, gP16;
bool     gHasAsia, gHasOrb, gHasPre;
double   gVWAP, gVWSD, gLVWAP = 0, gBoxHi = 0, gBoxLo = 0; bool gHasBox = false;
int      gCrosses;
// สถานะรายวัน
bool     gLonLong, gLonShort, gOrbDone, gHandoff;
int      gPmMode;                 // 0 ไม่เทรด, 1/-1 trend ขึ้น/ลง, 2 range, 9 ยังไม่จำแนก
string   gStatus = "";
datetime gRegDay = 0;              // D1 bar the cached regime ER belongs to
double   gRegER  = -1.0;           // D1 efficiency ratio up to yesterday (-1 = not available)
double   gLastLot = 0, gLastRisk = 0;
bool     gDashOn = false;
uint     gDashLastMs = 0;
string   gLastSig[MODS];
double   gMaxDD = 0;
string   gSessNow = "OFF";
// v2: spread buffer และข่าว
double   gSpr[200];
int      gSprN = 0, gSprI = 0;
datetime gNews[];                  // เวลาข่าว (UTC)
bool     gIsFOMC[];
int      gLastHBDay = -1;
// v2.50
struct XPosInfo
{
   ulong  id;          // position identifier (= position ticket on hedging accounts)
   double riskMoney;   // initial risk in account currency
   double slDist;      // initial SL distance (price)
   bool   partDone;    // partial close already handled
   int    partTries;
   int    adds;        // v2.60: add-ons opened for this (parent) position
   int    addTries;    // v2.60: failed add-on orders for the next add
   datetime addNext;   // v2.60: no new add-on order before this time (after a failed order)
   datetime beNext;    // v2.80: no new BE-only modify before this time (after a failed modify)
};
XPosInfo gPos[];
double   gEqPeak = 0, gEqStreakR = 0;        // balance high-water mark, running sum of closed R
double   gEqBal[];                            // mode 2: balance after each fully closed EA position (last InpEqSMAN kept)
int      hVolFast = INVALID_HANDLE, hVolSlow = INVALID_HANDLE, hVolH1 = INVALID_HANDLE;
datetime gVolDay = 0;                         // D1 bar the cached shock state belongs to
bool     gVolShock = false;
string   gVolWhy = "";
int      hMTF4 = INVALID_HANDLE, hMTF1 = INVALID_HANDLE;
bool     gTgOn = false, gTgWarned = false;
datetime gTgMuteUntil = 0;
long     gTgDay = -1;
// v2.60
#define  PYR_SUFFIX "+P"
ulong    gPyrIds[];                           // position ids of add-ons opened / seen by this instance
// v2.60 modular build: new state (all neutral when the new inputs are at their defaults)
int      hADXH1W = INVALID_HANDLE;            // iADXWilder(H1,14): only for InpNSATRMode = 1
int      gNSDay = -1;
bool     gOrbAUp = false, gOrbADn = false, gDMADone = false, gDMLDone = false;
bool     gNetting = false;                    // account is not retail hedging: one EA position at a time
// regime engine (XMS_Regime.mqh)
bool     gRgOK = false;                       // values below are valid
datetime gRgBar = 0;                          // open time of the forming H1 bar at the last successful update
datetime gRgTime = 0;                         // open time of the last closed H1 bar used
datetime gRgLogged = 0;                       // last H1 bar written to the regime CSV
double   gRgADX = 0, gRgPDI = 0, gRgMDI = 0, gRgATR14 = 0, gRgATR24 = 0, gRgVolPr = 0, gRgBbwPr = 0;
bool     gRgBrk = false;
int      gRgD1 = 0;                           // D1 trend: +1 close > EMA50, -1 below, 0 n/a (completed trading days)
// sleeves (XMS_Risk.mqh): 0 = LEGACY (modules 0..9), 1 = NEW (modules 10..12)
double   gSlvScale[2] = {1.0, 1.0};           // sleeve risk scale (<= 1)
double   gSlvClosed[2] = {0.0, 0.0};          // realised P/L since gSlvT0
double   gSlvPeak[2] = {0.0, 0.0};            // P/L high-water mark
double   gSlvPeakEq[2] = {0.0, 0.0};          // account equity when the peak was made
double   gSlvDD[2] = {0.0, 0.0};              // current sleeve DD %
datetime gSlvT0 = 0;
// order-error halt and module breaker (XMS_Risk.mqh)
int      gOrdErr = 0;                         // consecutive order-send failures
bool     gOrdErrStop = false;                 // no new entries for the rest of the day
double   gBrkCum[3] = {0.0, 0.0, 0.0};        // ORB_A / DM_A / DM_L: cumulative realised R
double   gBrkPeak[3] = {0.0, 0.0, 0.0};       // its high-water mark
double   gBrkScale[3] = {1.0, 1.0, 1.0};      // 1, 0.5 or 0 (disabled)
// v2.70 direction filter (XMS_Strategy_New.mqh); never written while InpNYPBDirFilter = 0
long     gDirDay = -1;                        // UTC day the values below belong to
bool     gDirOK  = false;                     // 07:00 UTC close and day open were both available
int      gDirVal = 0;                         // +1 close > open, -1 close < open, 0 = equal / not available
double   gDirC = 0, gDirO = 0;                // the 07:00 UTC close and the day open used

//--- modules (all inputs and globals above are visible to them)
#include "XMS_Dashboard.mqh"        // on-chart dashboard (objects only)
#include "XMS_Risk.mqh"             // shared helpers, filters, sizing, account guard, sleeves, breaker
#include "XMS_Regime.mqh"           // regime engine (closed H1 bars, Wilder) + legacy D1 ER filter
#include "XMS_Log.mqh"              // trade / equity / regime CSV, Telegram, dashboard feed
#include "XMS_Entry.mqh"            // OpenTrade, add-on open, pre-trade counters
#include "XMS_Exit.mqh"             // ClosePositions, daily flat, position management
#include "XMS_Strategy_Legacy.mqh"  // legacy v2.50 signal modules
#include "XMS_Strategy_New.mqh"     // ORB_A / DM_A / DM_L

//+------------------------------------------------------------------+
int OnInit()
{
   gPfx = "XMS_" + IntegerToString(InpMagicBase) + "_" + _Symbol + "_";
   if(InpDashboard && MQLInfoInteger(MQL_VISUAL_MODE)) TesterHideIndicators(true);   // visual tester: ซ่อน indicator ให้เห็นแดชบอร์ดเต็ม
   hATR   = iATR(_Symbol, PERIOD_M5, 14);
   hADX   = iADX(_Symbol, PERIOD_M15, 14);
   hBB    = iBands(_Symbol, PERIOD_M5, 20, 0, 2.0, PRICE_CLOSE);
   hRSI   = iRSI(_Symbol, PERIOD_M5, 7, PRICE_CLOSE);
   hEMA20 = iMA(_Symbol, PERIOD_M5, InpPBEMA, 0, MODE_EMA, PRICE_CLOSE);
   hEMA50 = iMA(_Symbol, PERIOD_M15, 50, 0, MODE_EMA, PRICE_CLOSE);
   hATR15 = iATR(_Symbol, PERIOD_M15, 14);
   hATRH1 = iATR(_Symbol, PERIOD_H1, 14);
   if(InpNSATRMode == 1) hADXH1W = iADXWilder(_Symbol, PERIOD_H1, 14);   // prototype ADX source; mode 0 uses XMS_Regime
   if(InpHTFEMA > 0) hHTF = iMA(_Symbol, InpHTFTF, InpHTFEMA, 0, MODE_EMA, PRICE_CLOSE);
   if(hATR == INVALID_HANDLE || hADX == INVALID_HANDLE || hBB == INVALID_HANDLE ||
      hRSI == INVALID_HANDLE || hEMA20 == INVALID_HANDLE || hEMA50 == INVALID_HANDLE)
   { Print("สร้าง indicator ไม่สำเร็จ"); return INIT_FAILED; }
   if(InpTrailMode == 1 && hATR15 == INVALID_HANDLE) { Print("XAU_MultiSession: cannot create the M15 ATR handle (runner trail)"); return INIT_FAILED; }

   //--- v2.50 optional features (handles only when the feature is on)
   if(InpVolShockMode > 0)
   {
      hVolFast = iATR(_Symbol, PERIOD_D1, MathMax(1, InpVolShockATRFast));
      hVolSlow = iATR(_Symbol, PERIOD_D1, MathMax(1, InpVolShockATRSlow));
      hVolH1   = iATR(_Symbol, PERIOD_H1, 50);
      if(hVolFast == INVALID_HANDLE || hVolSlow == INVALID_HANDLE || hVolH1 == INVALID_HANDLE)
      { Print("XAU_MultiSession: cannot create the volatility shock ATR handles"); return INIT_FAILED; }
   }
   if(InpMTFMode > 0)
   {
      hMTF4 = iMA(_Symbol, PERIOD_H4, MathMax(1, InpMTFEMA), 0, MODE_EMA, PRICE_CLOSE);
      hMTF1 = iMA(_Symbol, PERIOD_H1, MathMax(1, InpMTFEMA), 0, MODE_EMA, PRICE_CLOSE);
      if(hMTF4 == INVALID_HANDLE || hMTF1 == INVALID_HANDLE)
      { Print("XAU_MultiSession: cannot create the MTF EMA handles"); return INIT_FAILED; }
   }
   gVolDay = 0; gVolShock = false; gVolWhy = "";
   gEqPeak = AccountInfoDouble(ACCOUNT_BALANCE); gEqStreakR = 0; ArrayResize(gEqBal, 0);      // equity-curve state restarts with the EA
   gTgOn = InpTelegram && !MQLInfoInteger(MQL_TESTER) && !MQLInfoInteger(MQL_OPTIMIZATION) && InpTgToken != "" && InpTgChatId != "";
   gTgWarned = false; gTgMuteUntil = 0;
   if(gTgOn) Print("XAU_MultiSession: Telegram on - https://api.telegram.org must be added in Tools > Options > Expert Advisors > Allow WebRequest for listed URL");
   else if(InpTelegram && !MQLInfoInteger(MQL_TESTER) && !MQLInfoInteger(MQL_OPTIMIZATION))
      Print("XAU_MultiSession: Telegram is enabled but InpTgToken / InpTgChatId is empty - notifications are off");

   if((ENUM_ACCOUNT_MARGIN_MODE)AccountInfoInteger(ACCOUNT_MARGIN_MODE) != ACCOUNT_MARGIN_MODE_RETAIL_HEDGING)
      Print("คำเตือน: บัญชีไม่ใช่ hedging — position ข้ามโมดูลจะรวมกันและการจัดการไม้จะผิด");
   gNetting = ((ENUM_ACCOUNT_MARGIN_MODE)AccountInfoInteger(ACCOUNT_MARGIN_MODE) != ACCOUNT_MARGIN_MODE_RETAIL_HEDGING);
   if(gNetting) XLog("NETTING account: degraded mode - one EA position at a time on the symbol, pyramiding disabled");

   trade.SetTypeFillingBySymbol(_Symbol);
   trade.SetDeviationInPoints(30);
   if(InpResetHalt)
   {
      GlobalVariableDel(gPfx + "halted");
      GVSet("peak", AccountInfoDouble(ACCOUNT_EQUITY));
   }
   if(MQLInfoInteger(MQL_TESTER) || MQLInfoInteger(MQL_OPTIMIZATION)) GlobalVariablesDeleteAll(gPfx);   // tester: เริ่มสะอาดทุก pass
   gHalted = GVGet("halted", 0) > 0;
   RiskInit();                                                          // v2.60: sleeves, order-error halt, module breaker (after the tester wipe)
   RegimeReset();
   AutoReset();                                                         // v2.90
   XLog(StringFormat("v2.90 USD started, mode=%s", ModeString()));
   gNSDay = -1; gOrbAUp = false; gOrbADn = false; gDMADone = false; gDMLDone = false;
   gDirDay = -1; gDirOK = false; gDirVal = 0; gDirC = 0; gDirO = 0;      // v2.70
   LoadNews();
   for(int i = 0; i < MODS; i++) gLastSig[i] = "-";
   gDashOn = InpDashboard && !MQLInfoInteger(MQL_OPTIMIZATION) && (!MQLInfoInteger(MQL_TESTER) || MQLInfoInteger(MQL_VISUAL_MODE));
   if(gDashOn) gDashOn = DashInit(ChartID(), (int)InpDashCorner, InpDashScale);
   if(gTgOn) gTgDay = (long)GVGet("tgday", -1);
   ProfileBannerDraw();                                                 // v2.91
   return INIT_SUCCEEDED;
}

//+------------------------------------------------------------------+
//| v2.91 profile banner: two text labels in the corner opposite to   |
//| the dashboard. Display only. Warns when the profile name says     |
//| CENT but the account currency is not a cent currency (or the      |
//| other way round).                                                 |
//+------------------------------------------------------------------+
void ProfileBannerLine(string name, string text, ENUM_BASE_CORNER c, ENUM_ANCHOR_POINT a, int y, int fs, color col)
{
   if(ObjectFind(0, name) < 0) ObjectCreate(0, name, OBJ_LABEL, 0, 0, 0);
   ObjectSetInteger(0, name, OBJPROP_CORNER, c);
   ObjectSetInteger(0, name, OBJPROP_ANCHOR, a);
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE, 12);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, fs);
   ObjectSetInteger(0, name, OBJPROP_COLOR, col);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
   ObjectSetString(0, name, OBJPROP_FONT, "Arial Bold");
   ObjectSetString(0, name, OBJPROP_TEXT, text);
}
void ProfileBannerDraw()
{
   if(InpProfileName == "") return;
   string cur = AccountInfoString(ACCOUNT_CURRENCY);
   string up = InpProfileName, cu = cur;
   StringToUpper(up); StringToUpper(cu);
   bool wantCent = StringFind(up, "CENT") >= 0;
   bool isCent   = (cu == "USC" || StringFind(cu, "CENT") >= 0);
   bool bad      = (wantCent != isCent);
   Print("XAU_MultiSession profile: ", InpProfileName, " | account currency ", cur, " | balance ", DoubleToString(AccountInfoDouble(ACCOUNT_BALANCE), 2),
         bad ? " | WARNING: account type does not match this profile" : "");
   if(MQLInfoInteger(MQL_OPTIMIZATION) || (MQLInfoInteger(MQL_TESTER) && !MQLInfoInteger(MQL_VISUAL_MODE))) return;
   bool dashRight = (InpDashCorner == CORNER_RIGHT_UPPER || InpDashCorner == CORNER_RIGHT_LOWER);
   ENUM_BASE_CORNER  c = dashRight ? CORNER_LEFT_UPPER : CORNER_RIGHT_UPPER;
   ENUM_ANCHOR_POINT a = dashRight ? ANCHOR_LEFT_UPPER : ANCHOR_RIGHT_UPPER;
   ProfileBannerLine("XMSPROF_1", "PROFILE: " + InpProfileName, c, a, 22, 14, clrGold);
   ProfileBannerLine("XMSPROF_2", "Account currency: " + cur + (bad ? "   << WRONG ACCOUNT TYPE FOR THIS PROFILE >>" : (isCent ? "   (Cent account)" : "   (Standard account)")),
                     c, a, 48, 10, bad ? clrRed : clrSilver);
   ChartRedraw(0);
}

void OnDeinit(const int reason)
{
   if(gDashOn) DashDeinit();
   ObjectsDeleteAll(0, "XMSPROF_");                                     // v2.91 profile banner
   Comment("");
   if(hVolFast != INVALID_HANDLE) { IndicatorRelease(hVolFast); hVolFast = INVALID_HANDLE; }
   if(hVolSlow != INVALID_HANDLE) { IndicatorRelease(hVolSlow); hVolSlow = INVALID_HANDLE; }
   if(hVolH1   != INVALID_HANDLE) { IndicatorRelease(hVolH1);   hVolH1   = INVALID_HANDLE; }
   if(hMTF4    != INVALID_HANDLE) { IndicatorRelease(hMTF4);    hMTF4    = INVALID_HANDLE; }
   if(hMTF1    != INVALID_HANDLE) { IndicatorRelease(hMTF1);    hMTF1    = INVALID_HANDLE; }
   if(hADXH1W  != INVALID_HANDLE) { IndicatorRelease(hADXH1W);  hADXH1W  = INVALID_HANDLE; }
}

//+------------------------------------------------------------------+
void OnTick()
{
   datetime now = TimeCurrent();
   PushSpread();
   gOffSec = (long)ServerOffsetHours(now) * 3600;
   datetime utc = (datetime)((long)now - gOffSec);
   long day = (long)utc / 86400;
   int  mn  = (int)(((long)utc % 86400) / 60);
   int  eu  = IsEUDST(utc) ? 60 : 0, us = IsUSDST(utc) ? 60 : 0;
   gLonS = 420 - eu;  gLonE = gLonS + 210;
   gNyS  = 750 - us;  gNyE  = 960 - us;  gOrbS = 810 - us;
   gPmS  = 960 - us;  gPmE  = gPmS + 240;
   MqlDateTime du; TimeToStruct(utc, du);
   gFlat = (du.day_of_week == 5) ? gPmE : gPmE + 30;

   //--- วันใหม่ (UTC)
   if(day != gDayKey)
   {
      gDayKey = day;
      gLonLong = false; gLonShort = false; gOrbDone = false; gHandoff = false; gPmMode = 9; gDayStop = false;
      if((long)GVGet("day", -1) != day) { GVSet("day", (double)day); GVSet("dayeq", AccountInfoDouble(ACCOUNT_EQUITY)); }
      gDayStartEq = GVGet("dayeq", AccountInfoDouble(ACCOUNT_EQUITY));
      RiskNewDay();                                                     // v2.60: order-error halt is per day
   }

   UpdateGuards();
   if(InpSleeveMode == 1) SleeveUpdate();                               // v2.60: per-sleeve throttle (mode 0: not called, scales stay 1)
   EqUpdate();
   gSessNow = mn < 360 ? "ASIA" : (mn >= gLonS && mn < gLonE) ? "LONDON" : (mn >= gNyS && mn < gNyE) ? "NEW YORK" : (mn >= gPmS && mn < gPmE) ? "NY-PM" : "OFF";
   if(gDashOn && GetTickCount() - gDashLastMs >= 1000) { gDashLastMs = GetTickCount(); FillDash(utc, mn); }
   if(gHalted) { if(gDashOn) return; Comment("XAU MultiSession: หยุดเพราะ DD ถึงเพดาน"); return; }

   TimedCloses(mn, du.day_of_week);                                     // 06:30 Asia close, 16:00 handoff, daily flat (XMS_Exit)
   //--- v2.50: Telegram daily summary once per UTC day, after the daily flat has closed everything
   if(gTgOn && InpTgDaily && mn >= gFlat && gTgDay != day && du.day_of_week >= 1 && du.day_of_week <= 5 &&
      (CountOurPositions() == 0 || mn >= gFlat + 5))
   {
      gTgDay = day; GVSet("tgday", (double)day);
      TgDailySummary(utc);
   }

   ManageV260(utc, mn);                                                 // v2.60: add-on cleanup, pyramiding, runner trail
   ManageBEOnly();                                                      // v2.80: BE-only rule (returns at once when all three inputs are 0)
   ManagePositions();

   //--- สัญญาณใหม่เฉพาะเมื่อแท่ง M5 ปิด
   datetime bar = iTime(_Symbol, PERIOD_M5, 0);
   if(bar == gLastBar) return;
   gLastBar = bar;
   RegimeUpdate();                                                      // v2.60: recomputed only when a new H1 bar appeared
   if(InpStrategyMode == MODE_AUTO) AutoRegimeUpdate();                 // v2.90: latch after the regime update (closed H1 bar only)
   if(InpEquityLog) LogEquity(now);
   if(du.day_of_year != gLastHBDay && MQLInfoInteger(MQL_TESTER) && !MQLInfoInteger(MQL_OPTIMIZATION))
   { gLastHBDay = du.day_of_year; Print("HB ", TimeToString(utc, TIME_DATE), " eq=", DoubleToString(AccountInfoDouble(ACCOUNT_EQUITY), 2)); }
   if(gDayStop || mn >= gFlat || du.day_of_week == 0 || du.day_of_week == 6) return;
   if(IsHoliday(utc)) { gStatus = "วันหยุด"; return; }
   if(NewsBlocked(utc) || NewsBlocked(utc + InpNewsBefore * 60))
   {
      gStatus = "ข่าว: งดเปิดไม้";
      if(InpNewsCloseAll) ClosePositions(-1, false);
      return;
   }
   if(!LoadDay()) return;

   string sess = "OFF";
   if(mn < 360)
   {
      sess = "ASIA";
      if(InpUseAsia)
      {
         if(InpAsiaMode == 0) { if(mn >= 30) ModuleAsia(); }
         else if(mn >= InpAsiaAStart && mn < InpAsiaAEnd && AccountInfoDouble(ACCOUNT_BALANCE) >= InpAsiaAMinBal) PullbackModule(MOD_ASIA, "ASIA_A", 0);
      }
      if(InpUseAsiaB) ModuleAsiaB();
   }
   if(mn >= gLonS && mn < gLonE)
   {
      sess = "LONDON";
      if(InpUseLondon) { if(InpLonMode == 0) ModuleLondon(); else if(mn < gLonS + InpLonAWindow) ModuleLondonA(); }
      if(InpUseLonC && mn >= gLonS + 30) PullbackModule(MOD_LONC, "LON_C", gLVWAP);
   }
   else if(mn < 360) {}
   else if(mn >= gNyS && mn < gNyE)    { sess = "NY";     if(InpUseNY)     ModuleNY(mn); }
   else if(mn >= gPmS && mn < gPmE)    { sess = "NY-PM";  if(InpUsePM && !(InpRcNoPM && RecentActive()) && !(InpFOMCNoPM && IsFOMCDay(utc))) ModulePM(); }

   //--- v2.40 modules (independent of the session chain above; fixed UTC windows except London open)
   if(InpUseAsiaC && mn >= 120 && mn < 360)  ModuleAsiaC();
   if(InpUseOvlB  && mn >= 750 && mn < 960)  ModuleOvlB();
   if(InpUseLdnB  && mn >= gLonS && mn <= 630) ModuleLdnB();
   if(InpUseScalp && mn >= InpScalpStart && mn < InpScalpEnd) ModuleScalp();
   NewStrategies(utc, mn);                                              // v2.60 ORB_A / DM_A / DM_L

   double eq = AccountInfoDouble(ACCOUNT_EQUITY), peak = GVGet("peak", eq);
   string x50 = "";                                                     // v2.50 line only when a feature is on
   if(InpEqRiskMode == 1) x50 += StringFormat("\neq mult %.2f (streak %+.1fR, peak %.2f)", EqMult(), gEqStreakR, gEqPeak);
   if(InpEqRiskMode == 2) x50 += StringFormat("\neq mult %.2f (balance SMA%d %.2f, samples %d/%d)", EqMult(), InpEqSMAN, EqSma(), ArraySize(gEqBal), InpEqSMAN);
   if(InpVolShockMode > 0 && VolShock()) x50 += "\nvol shock: " + gVolWhy;
   if(!gDashOn) Comment(StringFormat("XAU MultiSession v2.90 USD\nUTC %s | เซสชัน: %s\nATR(M5) %.2f | ADR %.2f | ADX(M15) %.1f\n"
                        "กรอบเอเชีย %.2f (%.0f%% ADR) | VWAP %.2f\nDD %.1f%% | ตัวคูณ risk %.2f | risk ที่เปิด %.2f%%\n%s%s",
                        TimeToString(utc, TIME_DATE | TIME_MINUTES), sess, gATR, gADR, gADX,
                        gHasAsia ? gAsiaHi - gAsiaLo : 0.0, gHasAsia ? 100.0 * (gAsiaHi - gAsiaLo) / gADR : 0.0, gVWAP,
                        peak > 0 ? (peak - eq) / peak * 100.0 : 0.0, gScale, OpenRiskPct(), gStatus, x50) + RiskComment());
}

//+------------------------------------------------------------------+
void OnTradeTransaction(const MqlTradeTransaction &trans, const MqlTradeRequest &request, const MqlTradeResult &result)
{
   bool eqOn = (InpEqRiskMode == 1);
   bool newOn = (InpSleeveMode == 1 || InpModBreaker);                  // v2.60 consumers of the deal stream (both off by default)
   bool oldOn = !(!InpWriteLog && !eqOn && InpEqRiskMode != 2 && !gTgOn);
   if((!oldOn && !newOn) || trans.type != TRADE_TRANSACTION_DEAL_ADD) return;
   if(!HistoryDealSelect(trans.deal)) return;
   long mg = HistoryDealGetInteger(trans.deal, DEAL_MAGIC);
   if(!IsOurMagic(mg) || HistoryDealGetString(trans.deal, DEAL_SYMBOL) != _Symbol) return;
   long  entry = HistoryDealGetInteger(trans.deal, DEAL_ENTRY);
   int   mod   = (int)(mg - InpMagicBase - 1);
   ulong pid   = (ulong)HistoryDealGetInteger(trans.deal, DEAL_POSITION_ID);
   double net = HistoryDealGetDouble(trans.deal, DEAL_PROFIT) + HistoryDealGetDouble(trans.deal, DEAL_SWAP)
              + HistoryDealGetDouble(trans.deal, DEAL_COMMISSION);
   if(newOn) RiskOnDeal(mod, pid, entry, net);                          // v2.60: sleeve realised P/L, module breaker R (reads gPos only)
   if(!oldOn) return;
   //--- v2.50: streak R = sum of net result / initial risk (entry commission included)
   if(eqOn && (entry == DEAL_ENTRY_IN || entry == DEAL_ENTRY_OUT) && net != 0)
   {
      int    pi = PosFind(pid);
      double rm = (pi >= 0) ? gPos[pi].riskMoney : AccountInfoDouble(ACCOUNT_BALANCE) * BaseRiskPct(mod) / 100.0;
      if(rm > 0) gEqStreakR += net / rm;
      EqUpdate();
   }
   if(entry != DEAL_ENTRY_OUT) return;
   bool closed = !PositionSelectByTicket(pid);
   if(closed) PosRemove(PosFind(pid));
   if(closed && InpEqRiskMode == 2) EqSmaAdd(AccountInfoDouble(ACCOUNT_BALANCE));   // v2.50 mode 2: balance after the final closing deal
   if(gTgOn)
      TgSend(StringFormat("XMS %s CLOSE%s\n%s %s %.2f lots @ %s\nSL %s | TP %s\nP/L %+.2f | balance %.2f", _Symbol, closed ? "" : " (partial)",
             ModName(mod), HistoryDealGetInteger(trans.deal, DEAL_TYPE) == DEAL_TYPE_SELL ? "BUY" : "SELL",
             HistoryDealGetDouble(trans.deal, DEAL_VOLUME), DoubleToString(HistoryDealGetDouble(trans.deal, DEAL_PRICE), _Digits),
             DoubleToString(HistoryDealGetDouble(trans.deal, DEAL_SL), _Digits), DoubleToString(HistoryDealGetDouble(trans.deal, DEAL_TP), _Digits),
             net, AccountInfoDouble(ACCOUNT_BALANCE)));
   if(!InpWriteLog) return;
   LogLine(StringFormat("%s,CLOSE,%d,,%.2f,,%s,,,,%.2f,",
           TimeToString(TimeCurrent(), TIME_DATE | TIME_SECONDS), (int)(mg - InpMagicBase),
           HistoryDealGetDouble(trans.deal, DEAL_VOLUME),
           DoubleToString(HistoryDealGetDouble(trans.deal, DEAL_PRICE), _Digits), net));
}
//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
//| เกณฑ์ optimize: กำไรสุทธิ ถ้า equity DD <= InpOptMaxDD ไม่งั้นติดลบ |
//+------------------------------------------------------------------+
input group "=== Optimize ==="
input double InpOptMaxDD = 45.0;   // DD สูงสุดที่ยอมรับใน OnTester (%)
double OnTester()
{
   double dd = TesterStatistics(STAT_EQUITYDD_PERCENT);
   double np = TesterStatistics(STAT_PROFIT);
   double tr = TesterStatistics(STAT_TRADES);
   if(tr < 30) return -1000 - (30 - tr);
   if(dd > InpOptMaxDD) return -dd;
   return np;
}
