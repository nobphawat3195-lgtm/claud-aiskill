//+------------------------------------------------------------------+
//| XMS_Regime.mqh - XAU MultiSession EA v2.90 USD
//| Regime engine on CLOSED H1 bars (Wilder ATR/ADX, ATR24 percentile, BREAKOUT
//| flag, D1 trend) + the legacy v2.40 D1 efficiency-ratio filter (moved verbatim).
//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
//| Regime: D1 efficiency ratio = |C[1]-C[1+N]| / sum|C[i]-C[i+1]|,   |
//| i = 1..N (closed bars only). Cached per D1 bar. -1 = no filter.   |
//+------------------------------------------------------------------+
double RegimeER()
{
   if(InpRegimeMode <= 0 || InpRegimeERDays < 1) return -1.0;
   datetime d0 = iTime(_Symbol, PERIOD_D1, 0);
   if(d0 == 0) return -1.0;
   if(d0 == gRegDay) return gRegER;
   int n = InpRegimeERDays;
   double c[];
   ArraySetAsSeries(c, true);
   if(CopyClose(_Symbol, PERIOD_D1, 1, n + 1, c) != n + 1) return -1.0;   // history short / not ready: no filter, retry later
   double path = 0.0;
   for(int i = 0; i < n; i++) path += MathAbs(c[i] - c[i + 1]);
   gRegER  = path > 0.0 ? MathAbs(c[0] - c[n]) / path : -1.0;
   gRegDay = d0;
   return gRegER;
}

bool RegimeStretched()
{
   double er = RegimeER();
   return er >= 0.0 && er > InpRegimeERMax;
}

//+------------------------------------------------------------------+
//| v2.60 regime engine. Mirrors cc60s/s60.py build_regime():          |
//|  wilder(x,n)  = ewm(alpha=1/n, adjust=False), seeded with x[0]     |
//|  TR[0] = H-L (previous close = own close), ATR = wilder(TR)        |
//|  ADX: +DM/-DM as s60.adx, +DI = 100*wilder(+DM)/ATR14,             |
//|       DX = 100*|+DI - -DI| / max(+DI + -DI, 1e-12), ADX=wilder(DX) |
//|  pct_rank(x,100) = share of the PREVIOUS 100 values <= current     |
//|  HIGH_VOL = pct_rank(ATR24,100) >= 0.5 ; TREND = ADX14 >= 25       |
//|  BREAKOUT event = comp & expd, flag held for 6 H1 bars:            |
//|    comp = min(pct_rank(BB width,100) of the 6 bars before) <= 0.20 |
//|    expd = TR >= 1.5*ATR14[-1] and close outside the 20-bar Donchian|
//|           channel of the bars before                               |
//|  BB width = 4*std(close,20,ddof=0)/sma(close,20)                   |
//| Input = CopyRates from shift 1 (closed H1 bars only): a value is   |
//| usable from the open of the next H1 bar and never repaints.        |
//| REG_BARS of history make the Wilder seed negligible                |
//| ((23/24)^450 < 1e-8 for the bars that are actually used).          |
//+------------------------------------------------------------------+
#define REG_BARS     600      // closed H1 bars loaded per update
#define REG_MINBARS  150      // fewer bars -> regime not available
#define REG_PCTN     100      // pct_rank window
#define REG_FIRSTROW 125      // first index with every column defined (the NaN warm-up in pandas): 100 + 19 + 6

void RegimeReset()
{
   gRgOK = false; gRgBar = 0; gRgTime = 0; gRgLogged = 0;
   gRgADX = 0; gRgPDI = 0; gRgMDI = 0; gRgATR14 = 0; gRgATR24 = 0; gRgVolPr = 0; gRgBbwPr = 0; gRgBrk = false; gRgD1 = 0;
}

//--- D1 trend as in s60.build_daily: sign(close - EMA50(close)) of the last COMPLETED trading day.
//    Sunday D1 bars are skipped (research merges them into Monday, whose close is the Monday close).
int RegimeD1Dir()
{
   MqlRates d[];
   int n = CopyRates(_Symbol, PERIOD_D1, 1, 400, d);
   if(n < 60) return 0;
   double e = 0, c = 0; int k = 0;
   for(int i = 0; i < n; i++)
   {
      MqlDateTime t; TimeToStruct(d[i].time, t);
      if(t.day_of_week == 0) continue;
      c = d[i].close;
      e = (k == 0) ? c : e + (c - e) * 2.0 / 51.0;                       // ewm(span=50, adjust=False)
      k++;
   }
   if(k < 60) return 0;
   return c > e ? 1 : (c < e ? -1 : 0);
}

//--- call on every new M5 bar; does the work only when a new H1 bar has appeared
void RegimeUpdate()
{
   datetime b0 = iTime(_Symbol, PERIOD_H1, 0);
   if(b0 == 0 || b0 == gRgBar) return;
   MqlRates r[];
   int n = CopyRates(_Symbol, PERIOD_H1, 1, REG_BARS, r);                // index 0 = oldest, n-1 = last closed bar
   if(n < REG_MINBARS || r[n - 1].time >= b0) { gRgOK = false; return; } // history not ready: retry on the next M5 bar

   double tr[], a14[], a24[], adx[], bbw[];
   int    bpr[], vpr[];                                                  // pct ranks as counts out of REG_PCTN (-1 = undefined)
   bool   ev[];
   ArrayResize(tr, n); ArrayResize(a14, n); ArrayResize(a24, n); ArrayResize(adx, n); ArrayResize(bbw, n);
   ArrayResize(bpr, n); ArrayResize(vpr, n); ArrayResize(ev, n);
   double sp = 0, sm = 0, sdx = 0, pdi = 0, mdi = 0;
   for(int i = 0; i < n; i++)
   {
      double h = r[i].high, l = r[i].low, c = r[i].close;
      double pc = (i > 0) ? r[i - 1].close : c;
      tr[i] = MathMax(h - l, MathMax(MathAbs(h - pc), MathAbs(l - pc)));
      double up = (i > 0) ? h - r[i - 1].high : 0.0, dn = (i > 0) ? r[i - 1].low - l : 0.0;
      double pdm = (up > dn && up > 0) ? up : 0.0, mdm = (dn > up && dn > 0) ? dn : 0.0;
      if(i == 0) { a14[0] = tr[0]; a24[0] = tr[0]; sp = pdm; sm = mdm; }
      else
      {
         a14[i] = a14[i - 1] + (tr[i] - a14[i - 1]) / 14.0;
         a24[i] = a24[i - 1] + (tr[i] - a24[i - 1]) / 24.0;
         sp += (pdm - sp) / 14.0; sm += (mdm - sm) / 14.0;
      }
      pdi = a14[i] > 0 ? 100.0 * sp / a14[i] : 0.0;
      mdi = a14[i] > 0 ? 100.0 * sm / a14[i] : 0.0;
      double dx = 100.0 * MathAbs(pdi - mdi) / MathMax(pdi + mdi, 1e-12);
      sdx = (i == 0) ? dx : sdx + (dx - sdx) / 14.0;
      adx[i] = sdx;
      //--- Bollinger width (20, population std); -1 = undefined
      bbw[i] = -1.0;
      if(i >= 19)
      {
         double mean = 0, var = 0;
         for(int k = i - 19; k <= i; k++) mean += r[k].close;
         mean /= 20.0;
         for(int k = i - 19; k <= i; k++) var += (r[k].close - mean) * (r[k].close - mean);
         if(mean > 0) bbw[i] = 4.0 * MathSqrt(var / 20.0) / mean;
      }
   }
   //--- pct ranks and events: every bar when the regime CSV is on (missed rows are back-filled), otherwise only the
   //    bars the last row depends on (BREAKOUT looks 6 event bars back, each event 6 pct ranks back). Same values either way.
   int pFrom = InpRegimeLog ? 0 : MathMax(0, n - 12), eFrom = InpRegimeLog ? 0 : MathMax(0, n - 6);
   for(int i = 0; i < n; i++)
   {
      vpr[i] = -1; bpr[i] = -1;
      if(i < pFrom) continue;
      if(i >= REG_PCTN)
      {
         int cnt = 0;
         for(int k = i - REG_PCTN; k < i; k++) if(a24[k] <= a24[i]) cnt++;
         vpr[i] = cnt;
      }
      if(i >= REG_PCTN + 19 && bbw[i] >= 0)
      {
         int cnt = 0; bool okw = true;
         for(int k = i - REG_PCTN; k < i; k++) { if(bbw[k] < 0) { okw = false; break; } if(bbw[k] <= bbw[i]) cnt++; }
         if(okw) bpr[i] = cnt;
      }
   }
   for(int i = 0; i < n; i++)
   {
      ev[i] = false;
      if(i < REG_FIRSTROW || i < eFrom) continue;
      int mn6 = REG_PCTN + 1; bool okc = true;
      for(int k = i - 6; k < i; k++) { if(bpr[k] < 0) { okc = false; break; } mn6 = MathMin(mn6, bpr[k]); }
      if(!okc || mn6 * 5 > REG_PCTN) continue;                           // comp: min pct rank of the 6 bars before <= 0.20
      double dh = -DBL_MAX, dl = DBL_MAX;
      for(int k = i - 20; k < i; k++) { dh = MathMax(dh, r[k].high); dl = MathMin(dl, r[k].low); }
      ev[i] = (tr[i] >= 1.5 * a14[i - 1]) && (r[i].close > dh || r[i].close < dl);
   }
   int L = n - 1;
   bool brk = false;
   for(int k = MathMax(0, L - 5); k <= L; k++) if(ev[k]) brk = true;
   gRgADX = adx[L]; gRgPDI = pdi; gRgMDI = mdi; gRgATR14 = a14[L]; gRgATR24 = a24[L];
   gRgVolPr = vpr[L] >= 0 ? (double)vpr[L] / REG_PCTN : 0.0;
   gRgBbwPr = bpr[L] >= 0 ? (double)bpr[L] / REG_PCTN : 0.0;
   gRgBrk = brk; gRgTime = r[L].time; gRgD1 = RegimeD1Dir();
   gRgOK = true; gRgBar = b0;

   if(InpRegimeLog)
   {
      for(int i = MathMax(REG_FIRSTROW, (gRgLogged == 0) ? L : 0); i <= L; i++)
      {
         if(r[i].time <= gRgLogged) continue;                            // rows missed while halted / offline are written too
         bool bk = false;
         for(int k = i - 5; k <= i; k++) if(ev[k]) bk = true;
         datetime tu = (datetime)((long)r[i].time - (long)ServerOffsetHours(r[i].time) * 3600);
         LogRegimeRow(tu, adx[i], a14[i], a24[i], (double)vpr[i] / REG_PCTN, adx[i] >= 25.0, vpr[i] * 2 >= REG_PCTN, bk);
      }
      gRgLogged = r[L].time;
   }
}

//--- accessors (values of the last closed H1 bar; 0 / false while the regime is not available)
bool   RegOK()        { return gRgOK; }
double RegADX()       { return gRgOK ? gRgADX : 0.0; }
double RegATR14()     { return gRgOK ? gRgATR14 : 0.0; }
double RegATR24()     { return gRgOK ? gRgATR24 : 0.0; }
double RegATR24Pct()  { return gRgOK ? 100.0 * gRgVolPr : 0.0; }          // percentile 0..100
bool   RegTrend()     { return gRgOK && gRgADX >= 25.0; }                 // TREND (true) / RANGE (false)
bool   RegHighVol()   { return gRgOK && gRgVolPr >= 0.5; }
bool   RegBreakout()  { return gRgOK && gRgBrk; }
int    RegD1Dir()     { return gRgOK ? gRgD1 : 0; }
string RegD1Trend()   { int d = RegD1Dir(); return d > 0 ? "UP" : (d < 0 ? "DOWN" : "FLAT"); }
//--- one token without commas (goes into the trade CSV): TREND/HIGH_VOL[/BRK]/D1_UP
string RegString()
{
   if(!gRgOK) return "n/a";
   return (RegTrend() ? "TREND" : "RANGE") + "/" + (RegHighVol() ? "HIGH_VOL" : "LOW_VOL") + (gRgBrk ? "/BRK" : "") + "/D1_" + RegD1Trend();
}
