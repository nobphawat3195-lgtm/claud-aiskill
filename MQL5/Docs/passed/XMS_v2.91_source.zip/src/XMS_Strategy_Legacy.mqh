//+------------------------------------------------------------------+
//| XMS_Strategy_Legacy.mqh - XAU MultiSession EA v2.90 USD
//| Day context (LoadDay) and the legacy v2.50 signal modules, moved verbatim:
//| ASIA / ASIA_A / ASIA_B / ASIA_C / LONDON / LON_A / LON_C / LDN_B / OVL_B /
//| SCALP / NY / NY_PM.
//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
//| โหลดแท่ง M5 ของวัน (UTC) และคำนวณบริบท                             |
//+------------------------------------------------------------------+
bool LoadDay()
{
   datetime from = (datetime)(gDayKey * 86400 + gOffSec);
   int got = CopyRates(_Symbol, PERIOD_M5, from, TimeCurrent(), gR);
   if(got <= 0) return false;
   gN = got;
   if(gR[gN - 1].time == iTime(_Symbol, PERIOD_M5, 0)) gN--;     // ตัดแท่งที่ยังไม่ปิด
   if(gN < 3) return false;

   double a[];
   if(CopyBuffer(hATR, 0, 1, 20, a) != 20) return false;
   gATR = a[19]; gATRAvg = 0;
   for(int i = 0; i < 20; i++) gATRAvg += a[i];
   gATRAvg /= 20.0;
   gADX = Val(hADX, 0, 1);
   if(gATR <= 0 || gADX == EMPTY_VALUE) return false;

   MqlRates d[];
   if(CopyRates(_Symbol, PERIOD_D1, 1, 14, d) != 14) return false;
   gADR = 0;
   for(int i = 0; i < 14; i++) gADR += d[i].high - d[i].low;
   gADR /= 14.0;
   if(gADR <= 0) return false;

   gHasAsia = false; gHasOrb = false; gHasPre = false; gCrosses = 0;
   gDayHi = gR[0].high; gDayLo = gR[0].low;
   double cumPV = 0, cumV = 0, vw = 0; int prevS = 0;
   double lPV = 0, lV = 0; gHasBox = false; gLVWAP = 0;
   for(int i = 0; i < gN; i++)
   {
      int mn = (int)((((long)gR[i].time - gOffSec) % 86400) / 60);
      double h = gR[i].high, l = gR[i].low, c = gR[i].close;
      gDayHi = MathMax(gDayHi, h); gDayLo = MathMin(gDayLo, l);
      if(mn < 360)
      {
         if(!gHasAsia) { gAsiaHi = h; gAsiaLo = l; gHasAsia = true; }
         else { gAsiaHi = MathMax(gAsiaHi, h); gAsiaLo = MathMin(gAsiaLo, l); }
      }
      if(mn >= gOrbS && mn < gOrbS + 15)
      {
         if(!gHasOrb) { gOrbHi = h; gOrbLo = l; gHasOrb = true; }
         else { gOrbHi = MathMax(gOrbHi, h); gOrbLo = MathMin(gOrbLo, l); }
      }
      if(mn < gPmS)
      {
         if(!gHasPre) { gPreHi = h; gPreLo = l; gHasPre = true; }
         else { gPreHi = MathMax(gPreHi, h); gPreLo = MathMin(gPreLo, l); }
         gP16 = c;
      }
      double v = (double)MathMax(gR[i].tick_volume, 1);
      cumPV += (h + l + c) / 3.0 * v; cumV += v; vw = cumPV / cumV;
      if(mn < gLonS)
      {
         if(!gHasBox) { gBoxHi = h; gBoxLo = l; gHasBox = true; }
         else { gBoxHi = MathMax(gBoxHi, h); gBoxLo = MathMin(gBoxLo, l); }
      }
      else { lPV += (h + l + c) / 3.0 * v; lV += v; gLVWAP = lPV / lV; }
      if(mn >= gNyS && mn < gPmS)
      {
         int s = c > vw ? 1 : -1;
         if(prevS != 0 && s != prevS) gCrosses++;
         prevS = s;
      }
   }
   gVWAP = vw;
   double var = 0;
   for(int i = 0; i < gN; i++)
   {
      double v = (double)MathMax(gR[i].tick_volume, 1);
      double tpv = (gR[i].high + gR[i].low + gR[i].close) / 3.0;
      var += v * (tpv - gVWAP) * (tpv - gVWAP);
   }
   gVWSD = MathSqrt(var / cumV);
   return true;
}

//+------------------------------------------------------------------+
//| โมดูล                                                             |
//+------------------------------------------------------------------+
void ModuleAsia()
{
   if(!gHasAsia || HasOpen(MOD_ASIA)) return;
   if((gAsiaHi - gAsiaLo) > InpAsiaMaxBoxADR * gADR || gADX >= InpAsiaADXMax) return;
   int tr, cl; CountGate(MOD_ASIA, tr, cl);
   if(tr >= InpAsiaMaxTrades || cl >= InpAsiaMaxLosses) return;

   double up = Val(hBB, 1, 1), lo = Val(hBB, 2, 1), mid = Val(hBB, 0, 1);
   double r1 = Val(hRSI, 0, 1), r2 = Val(hRSI, 0, 2);
   if(up == EMPTY_VALUE || lo == EMPTY_VALUE || r1 == EMPTY_VALUE || r2 == EMPTY_VALUE) return;
   MqlRates b = gR[gN - 1];
   if(b.low < lo && b.close > lo && MathMin(r1, r2) < InpAsiaRSILow)
      OpenTrade(MOD_ASIA, 1, b.low - InpAsiaSLATR * gATR, mid, 0.8, "ASIA_FADE");
   else if(b.high > up && b.close < up && MathMax(r1, r2) > 100.0 - InpAsiaRSILow)
      OpenTrade(MOD_ASIA, -1, b.high + InpAsiaSLATR * gATR, mid, 0.8, "ASIA_FADE");
}

void ModuleLondon()
{
   if(!gHasAsia || HasOpen(MOD_LONDON)) return;
   double box = gAsiaHi - gAsiaLo;
   if(box < InpLonBoxMinADR * gADR || box > InpLonBoxMaxADR * gADR) return;
   int tr, cl; CountGate(MOD_LONDON, tr, cl);
   if(tr >= InpLonMaxTrades) return;

   MqlRates b = gR[gN - 1], p = gR[gN - 2];
   double mid = (gAsiaHi + gAsiaLo) / 2.0;
   double swHi = MathMax(b.high, MathMax(p.high, gR[gN - 3].high));
   double swLo = MathMin(b.low,  MathMin(p.low,  gR[gN - 3].low));

   //--- โหมด B: sweep reversal (ตรวจก่อน เพราะเป็นสัญญาณกลับด้านของ breakout ที่ล้มเหลว)
   if(InpLonSweep)
   {
      if(!gLonShort && swHi > gAsiaHi + InpLonSweepATR * gATR && b.close < gAsiaHi)
      { if(OpenTrade(MOD_LONDON, -1, swHi + 0.2 * gATR, gAsiaLo, 1.0, "LON_SWEEP")) gLonShort = true; return; }
      if(!gLonLong && swLo < gAsiaLo - InpLonSweepATR * gATR && b.close > gAsiaLo)
      { if(OpenTrade(MOD_LONDON, 1, swLo - 0.2 * gATR, gAsiaHi, 1.0, "LON_SWEEP")) gLonLong = true; return; }
   }
   //--- โหมด A: breakout
   if(InpLonBreakout && gATR > gATRAvg)
   {
      double buf = InpLonBreakATR * gATR;
      if(!gLonLong && b.close > gAsiaHi + buf && p.close <= gAsiaHi + buf)
      { if(OpenTrade(MOD_LONDON, 1, MathMax(mid, b.close - InpLonSLATR * gATR), 0, 0, "LON_BREAK")) gLonLong = true; return; }
      if(!gLonShort && b.close < gAsiaLo - buf && p.close >= gAsiaLo - buf)
      { if(OpenTrade(MOD_LONDON, -1, MathMin(mid, b.close + InpLonSLATR * gATR), 0, 0, "LON_BREAK")) gLonShort = true; return; }
   }
}

//--- v2.1: ตัวช่วยโมดูลใหม่
int D1Dir(double price)
{
   if(hHTF == INVALID_HANDLE) return 0;
   double h = Val(hHTF, 0, 1);
   if(h == EMPTY_VALUE) return 0;
   return price > h ? 1 : (price < h ? -1 : 0);
}
bool NewOK(int mod, int maxTr)
{
   if(HasOpen(mod)) return false;
   int tr, cl; CountGate(mod, tr, cl);
   return tr < maxTr && cl < InpNewMaxLosses;
}
bool M15JustClosed() { return (iTime(_Symbol, PERIOD_M5, 0) % 900) == 0; }
//--- ASIA_A / LDN_C: EMA20 pullback ตาม D1 + M15 EMA50 (+ VWAP ถ้าให้มา)
void PullbackModule(int mod, string tag, double vwapRef)
{
   if(!NewOK(mod, InpNewMaxTrades)) return;
   double e50 = Val(hEMA50, 0, 1), e20 = Val(hEMA20, 0, 1);
   if(e50 == EMPTY_VALUE || e20 == EMPTY_VALUE) return;
   MqlRates b = gR[gN - 1], p = gR[gN - 2];
   int d = D1Dir(b.close);
   if(d > 0 && b.close > e50 && (vwapRef <= 0 || b.close > vwapRef) && b.low <= e20 && b.close > e20)
      OpenTrade(mod, 1, MathMin(b.low, p.low) - InpAsiaBufATR * gATR, 0, 0, tag);
   else if(d < 0 && b.close < e50 && (vwapRef <= 0 || b.close < vwapRef) && b.high >= e20 && b.close < e20)
      OpenTrade(mod, -1, MathMax(b.high, p.high) + InpAsiaBufATR * gATR, 0, 0, tag);
}
//--- ASIA_B: M15 ปิดทะลุ high/low ของวันก่อน ตามเทรนด์ D1
void ModuleAsiaB()
{
   if(!M15JustClosed() || !NewOK(MOD_ASIAB, InpAsiaBMaxTrades)) return;
   double c = iClose(_Symbol, PERIOD_M15, 1), h = iHigh(_Symbol, PERIOD_M15, 1), l = iLow(_Symbol, PERIOD_M15, 1);
   double pdh = iHigh(_Symbol, PERIOD_D1, 1), pdl = iLow(_Symbol, PERIOD_D1, 1), a15 = Val(hATR15, 0, 1);
   if(c <= 0 || pdh <= 0 || a15 == EMPTY_VALUE) return;
   int d = D1Dir(c);
   if(d > 0 && c > pdh) OpenTrade(MOD_ASIAB, 1, l - InpAsiaBSLATR * a15, 0, 0, "ASIA_B");
   else if(d < 0 && c < pdl) OpenTrade(MOD_ASIAB, -1, h + InpAsiaBSLATR * a15, 0, 0, "ASIA_B");
}
//--- LDN_A: M15 ปิดทะลุกรอบ 00:00-London open ตามเทรนด์ D1, SL กลางกรอบ (อย่างน้อย 1 ATR M15)
void ModuleLondonA()
{
   if(!gHasBox || !M15JustClosed() || !NewOK(MOD_LONDON, 1)) return;
   double c = iClose(_Symbol, PERIOD_M15, 1), a15 = Val(hATR15, 0, 1);
   if(c <= 0 || a15 == EMPTY_VALUE) return;
   double mid = (gBoxHi + gBoxLo) / 2.0;
   int d = D1Dir(c);
   if(d > 0 && c > gBoxHi) OpenTrade(MOD_LONDON, 1, MathMin(mid, c - InpLonASLATR * a15), 0, 0, "LON_A");
   else if(d < 0 && c < gBoxLo) OpenTrade(MOD_LONDON, -1, MathMax(mid, c + InpLonASLATR * a15), 0, 0, "LON_A");
}

//--- v2.40 ASIA_C: first M15 close beyond the 00:00-02:00 range in the D1 direction (called 02:00-06:00)
void ModuleAsiaC()
{
   if(!M15JustClosed() || !NewOK(MOD_ASIAC, 1)) return;
   double hi = 0, lo = 0; int cnt = 0;
   for(int i = 0; i < gN; i++)
   {
      int bm = (int)((((long)gR[i].time - gOffSec) % 86400) / 60);
      if(bm >= 120) break;
      if(cnt == 0) { hi = gR[i].high; lo = gR[i].low; }
      else { hi = MathMax(hi, gR[i].high); lo = MathMin(lo, gR[i].low); }
      cnt++;
   }
   if(cnt == 0 || hATRH1 == INVALID_HANDLE) return;
   double aH1 = Val(hATRH1, 0, 1), a15 = Val(hATR15, 0, 1), c = iClose(_Symbol, PERIOD_M15, 1);
   if(aH1 == EMPTY_VALUE || a15 == EMPTY_VALUE || c <= 0) return;
   if(hi - lo > InpAsiaCMaxATRH1 * aH1) return;
   double mid = (hi + lo) / 2.0;
   int d = D1Dir(c);
   if(d > 0 && c > hi) OpenTrade(MOD_ASIAC, 1, MathMin(mid, c - InpAsiaCSLATR * a15), 0, 0, "ASIA_C");
   else if(d < 0 && c < lo) OpenTrade(MOD_ASIAC, -1, MathMax(mid, c + InpAsiaCSLATR * a15), 0, 0, "ASIA_C");
}
//--- v2.40 OVL_B: first M15 close beyond the 07:00-12:00 range in the D1 direction (called 12:30-16:00 UTC)
void ModuleOvlB()
{
   if(!M15JustClosed() || !NewOK(MOD_OVLB, 1)) return;
   double hi = 0, lo = 0; int cnt = 0;
   for(int i = 0; i < gN; i++)
   {
      int bm = (int)((((long)gR[i].time - gOffSec) % 86400) / 60);
      if(bm < 420) continue;
      if(bm >= 720) break;
      if(cnt == 0) { hi = gR[i].high; lo = gR[i].low; }
      else { hi = MathMax(hi, gR[i].high); lo = MathMin(lo, gR[i].low); }
      cnt++;
   }
   if(cnt == 0) return;
   double c = iClose(_Symbol, PERIOD_M15, 1), h = iHigh(_Symbol, PERIOD_M15, 1), l = iLow(_Symbol, PERIOD_M15, 1), a15 = Val(hATR15, 0, 1);
   if(c <= 0 || a15 == EMPTY_VALUE) return;
   int d = D1Dir(c);
   if(d > 0 && c > hi) OpenTrade(MOD_OVLB, 1, l - InpOvlBSLATR * a15, 0, 0, "OVL_B");
   else if(d < 0 && c < lo) OpenTrade(MOD_OVLB, -1, h + InpOvlBSLATR * a15, 0, 0, "OVL_B");
}
//--- v2.40 LDN_B: after London open price sweeps the pre-London box against the D1 trend,
//    then an M5 bar closes back inside the box -> enter with the trend (called London open-10:30 UTC)
void ModuleLdnB()
{
   if(!gHasBox || !NewOK(MOD_LDNB, 1)) return;
   double exLo = 0, exHi = 0; int cnt = 0;
   for(int i = 0; i < gN; i++)
   {
      int bm = (int)((((long)gR[i].time - gOffSec) % 86400) / 60);
      if(bm < gLonS) continue;
      if(cnt == 0) { exLo = gR[i].low; exHi = gR[i].high; }
      else { exLo = MathMin(exLo, gR[i].low); exHi = MathMax(exHi, gR[i].high); }
      cnt++;
   }
   if(cnt == 0) return;
   MqlRates b = gR[gN - 1], p = gR[gN - 2];
   int d = D1Dir(b.close);
   // reclaim bar: it (or the previous close) was outside the box and it closes back inside
   if(d > 0 && exLo < gBoxLo && b.close > gBoxLo && b.close < gBoxHi && (b.low < gBoxLo || p.close <= gBoxLo))
      OpenTrade(MOD_LDNB, 1, exLo - InpLdnBSLATR * gATR, 0, 0, "LDN_B");
   else if(d < 0 && exHi > gBoxHi && b.close < gBoxHi && b.close > gBoxLo && (b.high > gBoxHi || p.close >= gBoxHi))
      OpenTrade(MOD_LDNB, -1, exHi + InpLdnBSLATR * gATR, 0, 0, "LDN_B");
}
//--- v2.40 SCALP: M5 pullback to EMA20 that closes back with the trend (D1 + M15 EMA50 + day VWAP),
//    SL beyond the 2-bar swing, fixed TP = InpScalpTPR x risk, max 1 open position
void ModuleScalp()
{
   if(HasOpen(MOD_SCALP)) return;
   int tr, cl; CountGate(MOD_SCALP, tr, cl);
   if(tr >= InpScalpMaxTrades || cl >= InpScalpMaxLosses) return;
   double e50 = Val(hEMA50, 0, 1), e20 = Val(hEMA20, 0, 1);
   if(e50 == EMPTY_VALUE || e20 == EMPTY_VALUE) return;
   MqlRates b = gR[gN - 1], p = gR[gN - 2];
   int d = D1Dir(b.close);
   if(d > 0 && b.close > e50 && b.close > gVWAP && b.low <= e20 && b.close > e20 && b.close > b.open)
   {
      double sl = MathMin(b.low, p.low) - InpScalpSLATR * gATR;
      double en = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
      if(en > sl) OpenTrade(MOD_SCALP, 1, sl, en + InpScalpTPR * (en - sl), 0, "SCALP");
   }
   else if(d < 0 && b.close < e50 && b.close < gVWAP && b.high >= e20 && b.close < e20 && b.close < b.open)
   {
      double sl = MathMax(b.high, p.high) + InpScalpSLATR * gATR;
      double en = SymbolInfoDouble(_Symbol, SYMBOL_BID);
      if(sl > en) OpenTrade(MOD_SCALP, -1, sl, en - InpScalpTPR * (sl - en), 0, "SCALP");
   }
}

void ModuleNY(int mn)
{
   if(HasOpen(MOD_NY)) return;
   int tr, cl; CountGate(MOD_NY, tr, cl);
   if(tr >= InpNYMaxTrades || cl >= InpNYMaxLosses) return;
   double e50 = Val(hEMA50, 0, 1), e20 = Val(hEMA20, 0, 1);
   if(e50 == EMPTY_VALUE || e20 == EMPTY_VALUE) return;
   MqlRates b = gR[gN - 1], p = gR[gN - 2];
   int bias = 0;
   if(b.close > e50 && b.close > gVWAP) bias = 1;
   if(b.close < e50 && b.close < gVWAP) bias = -1;
   if(bias == 0) return;

   //--- Setup 1: ORB
   if(InpNYORB && !gOrbDone && gHasOrb && mn >= gOrbS + 15)
   {
      if(bias > 0 && b.close > gOrbHi && p.close <= gOrbHi)
      { if(OpenTrade(MOD_NY, 1, MathMax(gOrbLo, b.close - InpNYMaxSLATR * gATR), 0, 0, "NY_ORB")) gOrbDone = true; return; }
      if(bias < 0 && b.close < gOrbLo && p.close >= gOrbLo)
      { if(OpenTrade(MOD_NY, -1, MathMin(gOrbHi, b.close + InpNYMaxSLATR * gATR), 0, 0, "NY_ORB")) gOrbDone = true; return; }
   }
   //--- Setup 2: pullback ถึง EMA20 แล้วปิดกลับตามทาง
   if(InpNYPullback && gADX >= InpNYADXMin)
   {
      if(bias > 0 && b.low <= e20 && b.close > e20 && b.close > b.open)
      {
         double sl = MathMin(b.low, p.low) - InpNYBufATR * gATR;
         if(b.close - sl <= InpNYMaxSLATR * gATR)
         {
            if(InpNYPBDirFilter > 0 && !NYPBDirOK(1, b.close)) gStatus = "SKIP: NY_PB BUY vs 07:00 direction (" + DirString() + ")";   // v2.70
            else OpenTrade(MOD_NY, 1, sl, 0, 0, "NY_PULLBACK");
         }
      }
      else if(bias < 0 && b.high >= e20 && b.close < e20 && b.close < b.open)
      {
         double sl = MathMax(b.high, p.high) + InpNYBufATR * gATR;
         if(sl - b.close <= InpNYMaxSLATR * gATR)
         {
            if(InpNYPBDirFilter > 0 && !NYPBDirOK(-1, b.close)) gStatus = "SKIP: NY_PB SELL vs 07:00 direction (" + DirString() + ")";  // v2.70
            else OpenTrade(MOD_NY, -1, sl, 0, 0, "NY_PULLBACK");
         }
      }
   }
}

void ModulePM()
{
   //--- จำแนกประเภทวันครั้งเดียวเมื่อเข้าเซสชัน
   if(gPmMode == 9)
   {
      gPmMode = 0;
      if(gHasPre && gPreHi > gPreLo)
      {
         double rng = (gPreHi - gPreLo) / gADR;
         double pos = (gP16 - gPreLo) / (gPreHi - gPreLo);
         if(rng >= InpPMTrendADR && gADX >= InpPMTrendADX)
         {
            if(pos >= 0.75) gPmMode = 1;
            if(pos <= 0.25) gPmMode = -1;
         }
         else if(rng < InpPMRangeADR && gADX < InpPMRangeADX && gCrosses >= InpPMMinCrosses) gPmMode = 2;
      }
   }
   if(gPmMode == 0 || HasOpen(MOD_PM)) return;
   if(gDayStartEq > 0 && (gDayStartEq - AccountInfoDouble(ACCOUNT_EQUITY)) / gDayStartEq * 100.0 > InpDailyLossPct / 2.0) return;
   int tr, cl; CountGate(MOD_PM, tr, cl);
   if(tr >= InpPMMaxTrades || cl >= InpPMMaxLosses) return;

   MqlRates b = gR[gN - 1], p = gR[gN - 2];
   if(gPmMode == 1 || gPmMode == -1)          // โหมด A: continuation
   {
      double e20 = Val(hEMA20, 0, 1);
      if(e20 == EMPTY_VALUE) return;
      if(gPmMode == 1 && b.low <= e20 && b.close > e20 && b.close > b.open)
      {
         if(InpNYPBDirFilter == 2 && !DirAllows(1)) gStatus = "SKIP: PM_CONT BUY vs 07:00 direction (" + DirString() + ")";    // v2.70
         else OpenTrade(MOD_PM, 1, MathMin(MathMin(b.low, p.low) - 0.2 * gATR, b.close - 1.2 * gATR), gDayHi, 1.0, "PM_CONT");
      }
      else if(gPmMode == -1 && b.high >= e20 && b.close < e20 && b.close < b.open)
      {
         if(InpNYPBDirFilter == 2 && !DirAllows(-1)) gStatus = "SKIP: PM_CONT SELL vs 07:00 direction (" + DirString() + ")";  // v2.70
         else OpenTrade(MOD_PM, -1, MathMax(MathMax(b.high, p.high) + 0.2 * gATR, b.close + 1.2 * gATR), gDayLo, 1.0, "PM_CONT");
      }
   }
   else                                        // โหมด B: VWAP fade
   {
      double r1 = Val(hRSI, 0, 1), r2 = Val(hRSI, 0, 2);
      if(r1 == EMPTY_VALUE || r2 == EMPTY_VALUE || gVWSD <= 0) return;
      double up = gVWAP + 2.0 * gVWSD, lo = gVWAP - 2.0 * gVWSD;
      if(b.low < lo && b.close > lo && MathMin(r1, r2) < 30.0)
         OpenTrade(MOD_PM, 1, b.low - gATR, gVWAP, 0.8, "PM_FADE");
      else if(b.high > up && b.close < up && MathMax(r1, r2) > 70.0)
         OpenTrade(MOD_PM, -1, b.high + gATR, gVWAP, 0.8, "PM_FADE");
   }
}
