//+------------------------------------------------------------------+
//| XMS_Entry.mqh - XAU MultiSession EA v2.90 USD
//| Pre-trade counters, add-on (pyramiding) bookkeeping, OpenTrade, PyrOpenAdd:
//| spread checks, filters, order send.
//+------------------------------------------------------------------+

//--- v2.60: add-on positions (pyramiding) carry the module magic and a comment ending in "+P"
bool PyrIsAddonId(ulong id)
{
   for(int i = ArraySize(gPyrIds) - 1; i >= 0; i--) if(gPyrIds[i] == id) return true;
   return false;
}
void PyrRemember(ulong id)
{
   if(id == 0 || PyrIsAddonId(id)) return;
   int n = ArraySize(gPyrIds);
   if(n >= 256)                                                        // keep the newest half
   {
      for(int i = 128; i < n; i++) gPyrIds[i - 128] = gPyrIds[i];
      n -= 128;
   }
   ArrayResize(gPyrIds, n + 1);
   gPyrIds[n] = id;
}
bool SelIsAddon(ulong ticket)                                          // for the currently selected position
{
   return StringFind(PositionGetString(POSITION_COMMENT), PYR_SUFFIX) >= 0 || PyrIsAddonId(ticket);
}
bool HasParent(long mg)                                                // note: changes the selected position
{
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong t = PositionGetTicket(i);
      if(t == 0 || PositionGetString(POSITION_SYMBOL) != _Symbol || PositionGetInteger(POSITION_MAGIC) != mg) continue;
      if(!SelIsAddon(t)) return true;
   }
   return false;
}

int CountOurPositions()
{
   int n = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong t = PositionGetTicket(i);
      if(t != 0 && PositionGetString(POSITION_SYMBOL) == _Symbol && IsOurMagic(PositionGetInteger(POSITION_MAGIC))) n++;
   }
   return n;
}
bool HasOpen(int mod)
{
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong t = PositionGetTicket(i);
      if(t == 0) continue;
      if(PositionGetString(POSITION_SYMBOL) == _Symbol && PositionGetInteger(POSITION_MAGIC) == ModMagic(mod)) return true;
   }
   return false;
}

//--- นับไม้ของวันนี้และจำนวนแพ้ติดกันล่าสุดของโมดูล (รวมผลต่อ position)
//    v2.60: add-on positions are ignored; slOuts = closed positions of today that were stopped out by their SL
void CountTodayEx(int mod, int &trades, int &consecLoss, int &slOuts)
{
   trades = 0; consecLoss = 0; slOuts = 0;
   datetime from = (datetime)(gDayKey * 86400 + gOffSec);
   if(!HistorySelect(from, TimeCurrent() + 60)) return;
   ulong ids[]; double net[]; bool slx[];
   int n = 0, total = HistoryDealsTotal();
   for(int i = 0; i < total; i++)
   {
      ulong d = HistoryDealGetTicket(i);
      if(d == 0) continue;
      if(HistoryDealGetString(d, DEAL_SYMBOL) != _Symbol || HistoryDealGetInteger(d, DEAL_MAGIC) != ModMagic(mod)) continue;
      ulong pid = (ulong)HistoryDealGetInteger(d, DEAL_POSITION_ID);
      long  de  = HistoryDealGetInteger(d, DEAL_ENTRY);
      if(de == DEAL_ENTRY_IN && StringFind(HistoryDealGetString(d, DEAL_COMMENT), PYR_SUFFIX) >= 0) PyrRemember(pid);
      if(PyrIsAddonId(pid)) continue;                    // v2.60: add-ons do not count as module trades / losses
      int idx = -1;
      for(int k = 0; k < n; k++) if(ids[k] == pid) { idx = k; break; }
      if(idx < 0)
      {
         ArrayResize(ids, n + 1); ArrayResize(net, n + 1); ArrayResize(slx, n + 1);
         ids[n] = pid; net[n] = 0; slx[n] = false; idx = n; n++;
      }
      if(de == DEAL_ENTRY_IN) trades++;
      if(de == DEAL_ENTRY_OUT && HistoryDealGetInteger(d, DEAL_REASON) == DEAL_REASON_SL) slx[idx] = true;
      net[idx] += HistoryDealGetDouble(d, DEAL_PROFIT) + HistoryDealGetDouble(d, DEAL_SWAP) + HistoryDealGetDouble(d, DEAL_COMMISSION);
   }
   for(int k = n - 1; k >= 0; k--)
   {
      if(PositionSelectByTicket(ids[k])) continue;      // ยังเปิดอยู่
      if(net[k] < 0) consecLoss++; else break;
   }
   for(int k = 0; k < n; k++)
      if(slx[k] && !PositionSelectByTicket(ids[k])) slOuts++;
}
void CountToday(int mod, int &trades, int &consecLoss)      // raw counters (dashboard)
{
   int so; CountTodayEx(mod, trades, consecLoss, so);
}
//--- counters used by the module entry limits. v2.60 re-entry: each SL stop-out of today (up to InpReentryMax)
//    gives the module one more entry by lowering both counters; identical to CountToday when the feature is off
void CountGate(int mod, int &trades, int &consecLoss)
{
   int so; CountTodayEx(mod, trades, consecLoss, so);
   if(InpReentryMode != 1 || InpReentryMax <= 0 || so <= 0) return;
   int x = MathMin(so, InpReentryMax);
   trades = MathMax(0, trades - x); consecLoss = MathMax(0, consecLoss - x);
}

//+------------------------------------------------------------------+
//| เปิดไม้: ตรวจ spread, RR, lot, เพดาน risk รวม                      |
//+------------------------------------------------------------------+
bool OpenTrade(int mod, int dir, double sl, double tp, double minRR, string tag)
{
   //--- v2.60 guards (none can fire on a hedging account with the new inputs at their defaults and no order errors)
   if(gNetting && CountOurPositions() > 0) { gStatus = "SKIP: netting - one position at a time (" + tag + ")"; return false; }
   if(OrderErrBlocked()) { gStatus = "SKIP: order errors - entries halted today (" + tag + ")"; return false; }
   double xScale = RiskExtraScale(mod);                                  // sleeve x module breaker, <= 1 (exactly 1.0 when both are off)
   if(xScale <= 0) { gStatus = "SKIP: module breaker - disabled (" + tag + ")"; return false; }
   double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK), bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   double entry = dir > 0 ? ask : bid;
   double slDist = dir > 0 ? entry - sl : sl - entry;
   double spread = ask - bid;
   double stopLv = SymbolInfoInteger(_Symbol, SYMBOL_TRADE_STOPS_LEVEL) * _Point;
   if(slDist <= 0 || slDist < stopLv) return false;

   double maxPct = (mod == MOD_PM) ? InpSpreadPctPM : InpSpreadPct;
   if(spread > slDist * maxPct / 100.0) { gStatus = "ข้าม: spread กว้างเกิน (" + tag + ")"; return false; }
   double med = MedianSpread();
   if(InpMedSpreadMult > 0 && med > 0 && spread > InpMedSpreadMult * med) { gStatus = "ข้าม: spread > median (" + tag + ")"; return false; }

   if(tp > 0)
   {
      double tpDist = dir > 0 ? tp - entry : entry - tp;
      if(tpDist < slDist * minRR || tpDist < stopLv) { gStatus = "ข้าม: RR ต่ำ (" + tag + ")"; return false; }
   }

   if(hHTF != INVALID_HANDLE && !(InpNewNoHTF && mod >= MOD_ORBA))
   {
      double h = Val(hHTF, 0, 1);
      if(h == EMPTY_VALUE || (entry - h) * dir <= 0) { gStatus = "ข้าม: สวนเทรนด์ใหญ่ (" + tag + ")"; return false; }
   }
   double regMult = 1.0;                                                 // regime filter (ทุกโมดูล)
   if(RegimeStretched())
   {
      if(InpRegimeMode == 1) { gStatus = "ข้าม: regime ER " + DoubleToString(gRegER, 2) + " > " + DoubleToString(InpRegimeERMax, 2) + " (" + tag + ")"; return false; }
      if(InpRegimeMode == 2) regMult = InpRegimeRiskMult;
   }
   double volMult = 1.0;                                                 // v2.50 volatility shock (all modules)
   if(InpVolShockMode > 0 && VolShock())
   {
      if(InpVolShockMode == 1) { gStatus = "SKIP: vol shock - " + gVolWhy + " (" + tag + ")"; return false; }
      if(InpVolShockMode == 2) volMult = InpVolShockRiskMult;
   }
   double mtfMult = 1.0;                                                 // v2.50 H4 + H1 confirmation (all modules)
   if(InpMTFMode > 0)
   {
      int al = MTFAligned(dir);
      if(InpMTFMode == 1 && al == 0) { gStatus = "SKIP: H4/H1 not aligned (" + tag + ")"; return false; }
      if(InpMTFMode == 2 && al >= 0) mtfMult = (al == 1) ? InpMTFAlignMult : InpMTFMisMult;
   }
   double eqMult = EqMult();                                             // v2.50 equity-curve multiplier
   double d1Mult = 1.0;                                                  // v2.91 D1 trend tilt (new modules only) + ASIA_B range-only
   if(InpAsiaBRangeOnly && mod == MOD_ASIAB && RegOK() && RegTrend()) { gStatus = "SKIP: ASIA_B range-only (" + tag + ")"; return false; }
   if(InpD1TiltMode == 1 && mod >= MOD_ORBA && RegOK())
   {
      int d1 = RegD1Dir();
      if(d1 != 0) d1Mult = (d1 * dir > 0) ? InpD1TiltWith : InpD1TiltAgainst;
   }
   double xMult  = eqMult * mtfMult * volMult * d1Mult;                           // 1.0 when all v2.50 features are off
   if(InpMaxPositions > 0 && CountOurPositions() >= InpMaxPositions) { gStatus = "ข้าม: ไม้เปิดเต็ม (" + tag + ")"; return false; }
   double riskPct = BaseRiskPct(mod);
   riskPct *= gScale * regMult * xMult;
   if(xScale < 1.0) riskPct *= xScale;                                   // v2.60: only ever reduces
   if(OpenRiskPct() + riskPct > InpMaxOpenRisk) { gStatus = "ข้าม: risk รวมเต็ม (" + tag + ")"; return false; }

   double lots = 0, tv = 0, ts = 0;                                      // lot sizing: XMS_Risk.mqh (body moved verbatim)
   if(!RecentActive())                                                   // v2.90: CLASSIC (and AUTO-LO) = the v2.80 statement, unchanged
   {
      if(!RiskLots(slDist, riskPct, gScale * regMult * xMult, xScale, MinLotCap(mod), tag, lots, tv, ts)) return false;   // v2.70: per-group min-lot cap
   }
   else if(!RiskLotsRecent(mod, dir, tag, entry, spread, stopLv, tp, minRR, riskPct, gScale * regMult * xMult, xScale, sl, slDist, lots, tv, ts)) return false;   // v2.90: sl / slDist may be moved closer
   gLastLot = lots; gLastRisk = 100.0 * lots * (slDist / ts * tv) / AccountInfoDouble(ACCOUNT_EQUITY);

   sl = NormalizeDouble(sl, _Digits);
   tp = tp > 0 ? NormalizeDouble(tp, _Digits) : 0;
   trade.SetExpertMagicNumber(ModMagic(mod));
   bool ok = dir > 0 ? trade.Buy(lots, _Symbol, 0, sl, tp, tag) : trade.Sell(lots, _Symbol, 0, sl, tp, tag);
   if(!ok || (trade.ResultRetcode() != TRADE_RETCODE_DONE && trade.ResultRetcode() != TRADE_RETCODE_PLACED))
   {
      gStatus = "order ล้มเหลว " + IntegerToString((int)trade.ResultRetcode()) + " (" + tag + ")";
      OrderErrNote(false, tag);                                          // v2.60: consecutive order-error counter
      return false;
   }
   OrderErrNote(true, tag);
   if(InpStrategyMode != MODE_CLASSIC) XLog(StringFormat("OPEN %s mode=%s lots=%.2f sl_dist=%.2f", tag, ModeString(), lots, slDist));   // v2.90 (print only)
   gStatus = "เปิด " + tag;
   gLastSig[mod] = (dir > 0 ? "BUY " : "SELL ") + TimeToString(TimeCurrent(), TIME_MINUTES);
   double effRisk = (InpLotMode == LOT_RISK_PCT) ? riskPct : gLastRisk;   // target risk % after all multipliers
   LogLine(StringFormat("%s,OPEN,%d,%d,%.2f,%s,%s,%s,%s,%s,,%s,%.4f,%.2f,%.2f,%.2f,%s,%s",
           TimeToString(TimeCurrent(), TIME_DATE | TIME_SECONDS), mod + 1, dir, lots,
           DoubleToString(entry, _Digits), DoubleToString(trade.ResultPrice(), _Digits),
           DoubleToString(spread, _Digits), DoubleToString(sl, _Digits), DoubleToString(tp, _Digits), tag,
           effRisk, eqMult, mtfMult, volMult, RegString(), DoubleToString(slDist, _Digits)));   // v2.60: + regime, sl_dist
   //--- v2.50: remember the initial risk of the position (R of the close, partial close trigger)
   ulong pid = trade.ResultOrder(), deal = trade.ResultDeal();
   if(deal != 0 && HistoryDealSelect(deal)) pid = (ulong)HistoryDealGetInteger(deal, DEAL_POSITION_ID);
   if(pid != 0 && PosFind(pid) < 0) PosAdd(pid, lots * (slDist / ts * tv), slDist, false);
   EmergencyNoSL(pid, ModMagic(mod), tag);                               // v2.60: a filled position without SL is closed at once
   if(gTgOn)
      TgSend(StringFormat("XMS %s OPEN\n%s %s %.2f lots @ %s\nSL %s | TP %s\nrisk %.2f%%", _Symbol, tag, dir > 0 ? "BUY" : "SELL", lots,
             DoubleToString(trade.ResultPrice() > 0 ? trade.ResultPrice() : entry, _Digits), DoubleToString(sl, _Digits),
             tp > 0 ? DoubleToString(tp, _Digits) : "-", gLastRisk));
   return true;
}

//+------------------------------------------------------------------+
//| v2.60 pyramiding: add-on market order for a parent position        |
//| SL = parent entry, risk = InpPyrRiskPct % of balance x gScale x    |
//| equity multiplier. Note: changes the selected position.            |
//+------------------------------------------------------------------+
bool PyrOpenAdd(ulong pTicket, int mod, int dir, double pOpen, double pSL, double pTP, string pTag)
{
   string tag = pTag + PYR_SUFFIX;
   if(gNetting) { gStatus = "SKIP: netting - one position at a time (" + tag + ")"; return false; }   // v2.60: no add-ons on netting
   if(OrderErrBlocked()) { gStatus = "SKIP: order errors - entries halted today (" + tag + ")"; return false; }
   double xScale = RiskExtraScale(mod);                                  // v2.60 sleeve x module breaker, <= 1
   if(xScale <= 0) { gStatus = "SKIP: module breaker - disabled (" + tag + ")"; return false; }
   double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK), bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   double entry  = dir > 0 ? ask : bid;
   double dist   = (entry - pOpen) * dir;                                // add-on risk distance = price to parent entry
   double spread = ask - bid;
   double stopLv = SymbolInfoInteger(_Symbol, SYMBOL_TRADE_STOPS_LEVEL) * _Point;
   if(dist <= 0 || dist - spread <= stopLv) return false;
   if(spread > dist * InpSpreadPct / 100.0) { gStatus = "ข้าม: spread กว้างเกิน (" + tag + ")"; return false; }
   double med = MedianSpread();
   if(InpMedSpreadMult > 0 && med > 0 && spread > InpMedSpreadMult * med) { gStatus = "ข้าม: spread > median (" + tag + ")"; return false; }
   if(InpMaxPositions > 0 && CountOurPositions() >= InpMaxPositions) { gStatus = "ข้าม: ไม้เปิดเต็ม (" + tag + ")"; return false; }

   double tv = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE), ts = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
   double step = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP), vmin = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double eq = AccountInfoDouble(ACCOUNT_EQUITY);
   if(tv <= 0 || ts <= 0 || step <= 0 || eq <= 0) return false;
   double eqMult  = EqMult();
   double riskPct = InpPyrRiskPct * gScale * eqMult;                     // % of balance
   if(xScale < 1.0) riskPct *= xScale;                                   // v2.60: only ever reduces
   double perLot  = dist / ts * tv;                                      // money risk of 1.0 lot
   double lots = AccountInfoDouble(ACCOUNT_BALANCE) * riskPct / 100.0 / perLot;
   lots = MathFloor(lots / step) * step;
   lots = MathMin(lots, MathMin(InpMaxLot, SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX)));
   if(lots < vmin) { gStatus = "ข้าม: lot ต่ำกว่าขั้นต่ำ (" + tag + ")"; return false; }
   lots = NormalizeDouble(lots, 2);
   double realRisk = 100.0 * lots * perLot / eq;                         // % of equity, same unit as OpenRiskPct()
   double openRisk = OpenRiskPct();
   if(InpPyrMoveSL && (pOpen - pSL) * dir > 0 && PositionSelectByTicket(pTicket))      // the parent goes to break-even with this add
      openRisk -= 100.0 * ((pOpen - pSL) * dir / ts * tv * PositionGetDouble(POSITION_VOLUME)) / eq;
   if(openRisk + realRisk > InpMaxOpenRisk) { gStatus = "ข้าม: risk รวมเต็ม (" + tag + ")"; return false; }

   double sl = NormalizeDouble(pOpen, _Digits);
   double tp = (pTP > 0 && (pTP - entry) * dir > MathMax(stopLv, spread)) ? NormalizeDouble(pTP, _Digits) : 0.0;
   trade.SetExpertMagicNumber(ModMagic(mod));
   bool ok = dir > 0 ? trade.Buy(lots, _Symbol, 0, sl, tp, tag) : trade.Sell(lots, _Symbol, 0, sl, tp, tag);
   int  pi = PosFind(pTicket);
   if(!ok || (trade.ResultRetcode() != TRADE_RETCODE_DONE && trade.ResultRetcode() != TRADE_RETCODE_PLACED))
   {
      gStatus = "order ล้มเหลว " + IntegerToString((int)trade.ResultRetcode()) + " (" + tag + ")";
      if(pi >= 0) { gPos[pi].addTries++; gPos[pi].addNext = TimeCurrent() + 60; }
      OrderErrNote(false, tag);                                          // v2.60
      return false;
   }
   OrderErrNote(true, tag);
   if(pi >= 0) { gPos[pi].adds++; gPos[pi].addTries = 0; gPos[pi].addNext = 0; }
   gStatus = "เปิด " + tag;
   gLastLot = lots; gLastRisk = realRisk;
   LogLine(StringFormat("%s,OPEN,%d,%d,%.2f,%s,%s,%s,%s,%s,,%s,%.4f,%.2f,%.2f,%.2f,%s,%s",
           TimeToString(TimeCurrent(), TIME_DATE | TIME_SECONDS), mod + 1, dir, lots,
           DoubleToString(entry, _Digits), DoubleToString(trade.ResultPrice(), _Digits),
           DoubleToString(spread, _Digits), DoubleToString(sl, _Digits), DoubleToString(tp, _Digits), tag,
           riskPct, eqMult, 1.0, 1.0, RegString(), DoubleToString(dist, _Digits)));              // v2.60: + regime, sl_dist
   ulong pid = trade.ResultOrder(), deal = trade.ResultDeal();
   if(deal != 0 && HistoryDealSelect(deal)) pid = (ulong)HistoryDealGetInteger(deal, DEAL_POSITION_ID);
   if(pid != 0)
   {
      PyrRemember(pid);
      if(PosFind(pid) < 0) PosAdd(pid, lots * perLot, dist, true);       // may reorder gPos: callers must look the parent up again
   }
   EmergencyNoSL(pid, ModMagic(mod), tag);                               // v2.60
   if(gTgOn)
      TgSend(StringFormat("XMS %s ADD-ON\n%s %s %.2f lots @ %s\nSL %s | TP %s\nrisk %.2f%%", _Symbol, tag, dir > 0 ? "BUY" : "SELL", lots,
             DoubleToString(trade.ResultPrice() > 0 ? trade.ResultPrice() : entry, _Digits), DoubleToString(sl, _Digits),
             tp > 0 ? DoubleToString(tp, _Digits) : "-", realRisk));
   return true;
}
