//+------------------------------------------------------------------+
//| XMS_Exit.mqh - XAU MultiSession EA v2.90 USD
//| ClosePositions, time-based closes and daily flat (incl. InpNSFlatMin),
//| ManageV260 (add-on cleanup / pyramiding / runner trail), ManagePositions.
//+------------------------------------------------------------------+

void ClosePositions(int mod, bool onlyInitialSL)      // mod = -1 คือทุกโมดูล
{
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong t = PositionGetTicket(i);
      if(t == 0) continue;
      long mg = PositionGetInteger(POSITION_MAGIC);
      if(PositionGetString(POSITION_SYMBOL) != _Symbol || !IsOurMagic(mg)) continue;
      if(mod >= 0 && mg != ModMagic(mod)) continue;
      if(onlyInitialSL)
      {
         if(SelIsAddon(t)) continue;                     // v2.60: add-ons follow their parent
         double op = PositionGetDouble(POSITION_PRICE_OPEN), sl = PositionGetDouble(POSITION_SL);
         bool initial = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY) ? (sl < op) : (sl > op);
         if(!initial) continue;
      }
      trade.SetExpertMagicNumber(mg);
      trade.PositionClose(t);
   }
}

//+------------------------------------------------------------------+
//| ปิดตามเวลา: time-based closes, called every tick from OnTick.      |
//| Body moved verbatim from OnTick (06:30 Asia close, 16:00 handoff,  |
//| daily flat; with InpNSFlatMin > 0 the new modules use their own    |
//| fixed UTC flat time).                                              |
//+------------------------------------------------------------------+
void TimedCloses(int mn, int dow)
{
   if(mn >= 390 && !InpAsiaHold) ClosePositions(MOD_ASIA, false);
   if(mn >= gPmS && !gHandoff) { if(InpHandoffClose) { ClosePositions(MOD_LONDON, true); ClosePositions(MOD_NY, true); } gHandoff = true; }
   if(InpLegacyFlatMin > 0)
   {  // v2.80: legacy modules (all except ORB_A / DM_A / DM_L) close at InpLegacyFlatMin (UTC minutes, compared with mn like InpNSFlatMin)
      int lf = MathMin(InpLegacyFlatMin, 1439);
      if(dow == 5) lf = MathMin(lf, gFlat);                              // Friday: min(value, Friday flat)
      if(mn >= lf) for(int m = 0; m < MOD_ORBA; m++) ClosePositions(m, false);
      if(mn >= gFlat)                                                    // ORB_A / DM_A / DM_L: exactly the v2.70 rule
      {
         if(InpNSFlatMin <= 0 || mn >= InpNSFlatMin) { ClosePositions(MOD_ORBA, false); ClosePositions(MOD_DMA, false); ClosePositions(MOD_DML, false); }
      }
   }
   else if(mn >= gFlat)
   {
      if(InpNSFlatMin > 0)
      {  // v2.60: legacy modules close at the EA flat; ORB_A / DM_A / DM_L hold to their own fixed UTC flat
         for(int m = 0; m < MOD_ORBA; m++) ClosePositions(m, false);
         if(mn >= InpNSFlatMin) { ClosePositions(MOD_ORBA, false); ClosePositions(MOD_DMA, false); ClosePositions(MOD_DML, false); }
      }
      else ClosePositions(-1, false);
   }
}

//+------------------------------------------------------------------+
//| v2.80 BE-only rule. N x initial risk (R) for this position's setup: |
//| NY_PB (MOD_NY, comment NY_PULLBACK), ASIA_B (MOD_ASIAB), LON_A      |
//| (MOD_LONDON, comment LON_A). 0 = rule off / other setup.            |
//| Call with the position selected.                                    |
//+------------------------------------------------------------------+
double BEOnlyR(int mod, string cmt)
{
   if(mod == MOD_NY      && InpBEOnlyR_NY > 0    && StringFind(cmt, "NY_PULLBACK") == 0) return InpBEOnlyR_NY;
   if(mod == MOD_ASIAB   && InpBEOnlyR_AsiaB > 0)                                        return InpBEOnlyR_AsiaB;
   if(mod == MOD_LONDON  && InpBEOnlyR_LonA > 0  && StringFind(cmt, "LON_A") == 0)       return InpBEOnlyR_LonA;
   return 0.0;
}

//--- per tick (like the existing BE code). SL -> entry +/- spread once profit >= N x R. Only tightens, no partial close, no trailing.
void ManageBEOnly()
{
   if(InpBEOnlyR_NY <= 0 && InpBEOnlyR_AsiaB <= 0 && InpBEOnlyR_LonA <= 0) return;
   double stopLv = SymbolInfoInteger(_Symbol, SYMBOL_TRADE_STOPS_LEVEL) * _Point;
   ulong tk[]; int n = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong t = PositionGetTicket(i);
      if(t == 0 || PositionGetString(POSITION_SYMBOL) != _Symbol || !IsOurMagic(PositionGetInteger(POSITION_MAGIC))) continue;
      ArrayResize(tk, n + 1); tk[n++] = t;
   }
   for(int i = 0; i < n; i++)
   {
      ulong t = tk[i];
      if(!PositionSelectByTicket(t) || SelIsAddon(t)) continue;
      long mg = PositionGetInteger(POSITION_MAGIC);
      int  mod = (int)(mg - InpMagicBase - 1);
      double nR = BEOnlyR(mod, PositionGetString(POSITION_COMMENT));
      if(nR <= 0) continue;
      int pi = PosEnsure(t);
      if(pi < 0 || !PositionSelectByTicket(t)) continue;
      if(TimeCurrent() < gPos[pi].beNext) continue;
      int    dir = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY) ? 1 : -1;
      double op = PositionGetDouble(POSITION_PRICE_OPEN), sl = PositionGetDouble(POSITION_SL), tp = PositionGetDouble(POSITION_TP);
      double R = gPos[pi].slDist;
      if(sl <= 0 || R <= 0) continue;
      double cur = dir > 0 ? SymbolInfoDouble(_Symbol, SYMBOL_BID) : SymbolInfoDouble(_Symbol, SYMBOL_ASK);
      if((cur - op) * dir < nR * R) continue;
      double be = NormalizeDouble(op + dir * Spread(), _Digits);
      if((be - sl) * dir > 0 && (cur - be) * dir > stopLv)               // only tightens; respects the broker stop level
      {
         trade.SetExpertMagicNumber(mg);
         if(!trade.PositionModify(t, be, tp)) gPos[pi].beNext = TimeCurrent() + 60;
      }
   }
}

//+------------------------------------------------------------------+
//| v2.60 per tick: close add-ons whose parent is gone, pyramiding,    |
//| runner trail (parents only). No effect when no add-on exists and   |
//| both features are off.                                             |
//+------------------------------------------------------------------+
void ManageV260(datetime utc, int mn)
{
   bool pyrOn = (InpPyrMode == 1 && InpPyrMaxAdds > 0 && InpPyrTriggerR > 0 && InpPyrRiskPct > 0);
   if(gNetting) pyrOn = false;                                          // v2.60 netting: one position at a time, no add-ons
   bool trailOn = (InpTrailMode == 1 && InpTrailATR15 > 0);
   ulong tk[]; int n = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong t = PositionGetTicket(i);
      if(t == 0 || PositionGetString(POSITION_SYMBOL) != _Symbol || !IsOurMagic(PositionGetInteger(POSITION_MAGIC))) continue;
      ArrayResize(tk, n + 1); tk[n++] = t;
   }
   double stopLv = SymbolInfoInteger(_Symbol, SYMBOL_TRADE_STOPS_LEVEL) * _Point;
   for(int i = 0; i < n; i++)
   {
      ulong t = tk[i];
      if(!PositionSelectByTicket(t)) continue;
      long mg = PositionGetInteger(POSITION_MAGIC);
      if(SelIsAddon(t))
      {
         PyrRemember(t);
         if(!HasParent(mg)) { trade.SetExpertMagicNumber(mg); trade.PositionClose(t); }   // parent closed (SL / TP / time stop): close its add-ons
         continue;
      }
      if(!pyrOn && !trailOn) continue;
      int pi = PosEnsure(t);
      if(pi < 0 || !PositionSelectByTicket(t)) continue;
      int    mod = (int)(mg - InpMagicBase - 1);
      int    dir = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY) ? 1 : -1;
      double op  = PositionGetDouble(POSITION_PRICE_OPEN);
      double sl  = PositionGetDouble(POSITION_SL);
      double tp  = PositionGetDouble(POSITION_TP);
      string tag = PositionGetString(POSITION_COMMENT);
      double cur = dir > 0 ? SymbolInfoDouble(_Symbol, SYMBOL_BID) : SymbolInfoDouble(_Symbol, SYMBOL_ASK);
      double profit = (cur - op) * dir;
      double R = gPos[pi].slDist;                                        // initial risk distance (entry to initial SL)
      if(sl <= 0 || R <= 0) continue;
      if(tag == "") tag = ModName(mod);

      if(pyrOn)
      {
         if(gPos[pi].adds < InpPyrMaxAdds && profit >= (gPos[pi].adds + 1) * InpPyrTriggerR * R &&
            gPos[pi].addTries < 3 && TimeCurrent() >= gPos[pi].addNext &&
            !gDayStop && mn < gFlat && !IsHoliday(utc) && !NewsBlocked(utc) && !NewsBlocked(utc + InpNewsBefore * 60))
         {
            PyrOpenAdd(t, mod, dir, op, sl, tp, tag);
            pi = PosFind(t);
            if(pi < 0 || !PositionSelectByTicket(t)) continue;
         }
         if(InpPyrMoveSL && gPos[pi].adds > 0)                           // retried every tick until the SL is at entry + spread
         {
            double be = NormalizeDouble(op + dir * Spread(), _Digits);
            if((be - sl) * dir > 0 && (cur - be) * dir > stopLv)
            {
               trade.SetExpertMagicNumber(mg);
               if(trade.PositionModify(t, be, tp)) sl = be;
            }
         }
      }
      if(trailOn && profit >= InpTrailStartR * R)
      {
         double a15 = Val(hATR15, 0, 1);
         if(a15 != EMPTY_VALUE && a15 > 0)
         {
            double ns = NormalizeDouble(cur - dir * InpTrailATR15 * a15, _Digits);
            if((ns - sl) * dir > MathMax(10 * _Point, InpTrailStepATR * gATR) && (cur - ns) * dir > stopLv)   // only tightens
            {
               trade.SetExpertMagicNumber(mg);
               trade.PositionModify(t, ns, tp);
            }
         }
      }
   }
}

//+------------------------------------------------------------------+
//| จัดการไม้: partial + BE ที่ 1R, trailing, time-stop                 |
//+------------------------------------------------------------------+
void ManagePositions()
{
   if(gATR <= 0) return;
   double stopLv = SymbolInfoInteger(_Symbol, SYMBOL_TRADE_STOPS_LEVEL) * _Point;
   double minLot = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double step   = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong t = PositionGetTicket(i);
      if(t == 0) continue;
      long mg = PositionGetInteger(POSITION_MAGIC);
      if(PositionGetString(POSITION_SYMBOL) != _Symbol || !IsOurMagic(mg)) continue;
      if(SelIsAddon(t)) continue;                                        // v2.60: add-ons are managed with their parent (ManageV260)
      int    mod = (int)(mg - InpMagicBase - 1);
      int    dir = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY) ? 1 : -1;
      double op  = PositionGetDouble(POSITION_PRICE_OPEN);
      double sl  = PositionGetDouble(POSITION_SL);
      double tp  = PositionGetDouble(POSITION_TP);
      double vol = PositionGetDouble(POSITION_VOLUME);
      double cur = dir > 0 ? SymbolInfoDouble(_Symbol, SYMBOL_BID) : SymbolInfoDouble(_Symbol, SYMBOL_ASK);
      double profit = (cur - op) * dir;
      if(sl <= 0) continue;
      bool initial = dir > 0 ? (sl < op) : (sl > op);
      trade.SetExpertMagicNumber(mg);

      //--- v2.50: one partial close per position at InpPartialR x initial risk
      //    v2.60: an SL moved past entry by the pyramiding BE / runner trail must not start the legacy trailing
      bool noTrail = (InpBEAtR <= 0 && (InpTrailMode == 1 || (InpPyrMode == 1 && InpPyrMoveSL)));
      if(BEOnlyR(mod, PositionGetString(POSITION_COMMENT)) > 0) noTrail = true;       // v2.80: BE-only positions are never trailed
      if(InpPartialMode == 1 && InpPartialR > 0 && InpPartialPct > 0)
      {
         int pi = PosEnsure(t);
         if(pi >= 0 && !gPos[pi].partDone && gPos[pi].slDist > 0 && profit >= InpPartialR * gPos[pi].slDist)
         {
            double part = MathFloor(vol * InpPartialPct / 100.0 / step + 1e-7) * step;
            bool   done = false;
            if(part < minLot || vol - part < minLot - 1e-9) gPos[pi].partDone = true;      // cannot split: leave the position whole
            else
            {
               done = trade.PositionClosePartial(t, NormalizeDouble(part, 2)) &&
                      (trade.ResultRetcode() == TRADE_RETCODE_DONE || trade.ResultRetcode() == TRADE_RETCODE_PLACED);
               gPos[pi].partTries++;
               if(done || gPos[pi].partTries >= 3) gPos[pi].partDone = true;
            }
            if(done && InpPartialBE)
            {
               double be = NormalizeDouble(op + dir * Spread(), _Digits);
               if((be - sl) * dir > 0 && (cur - be) * dir > stopLv) trade.PositionModify(t, be, tp);
            }
         }
         if(!PositionSelectByTicket(t)) continue;                                          // re-select, refresh after the changes
         vol = PositionGetDouble(POSITION_VOLUME); sl = PositionGetDouble(POSITION_SL);
         if(sl <= 0) continue;
         initial = dir > 0 ? (sl < op) : (sl > op);
         noTrail = noTrail || (InpPartialBE && InpBEAtR <= 0 && pi >= 0 && gPos[pi].partDone);         // SL moved by the partial BE only: no legacy trailing
      }

      if(initial)
      {
         double R = (op - sl) * dir;
         if(InpBEAtR > 0 && profit >= InpBEAtR * R)
         {
            double part = MathFloor(vol * InpPartialPct / 100.0 / step) * step;
            if(part >= minLot && vol - part >= minLot) trade.PositionClosePartial(t, NormalizeDouble(part, 2));
            double be = NormalizeDouble(op + dir * Spread(), _Digits);
            if((cur - be) * dir > stopLv) trade.PositionModify(t, be, tp);
         }
         else
         {
            int limit = (mod == MOD_ASIA) ? InpTimeStopAsia : (mod == MOD_PM ? InpTimeStopPM : InpTimeStopMain);
            int bars  = (int)((TimeCurrent() - (datetime)PositionGetInteger(POSITION_TIME)) / 300);
            if(limit > 0 && bars >= limit && profit < 0.5 * R) trade.PositionClose(t);
         }
      }
      else if(!noTrail)
      {
         double ns = NormalizeDouble(cur - dir * InpTrailATR * gATR, _Digits);
         if((ns - sl) * dir > MathMax(10 * _Point, InpTrailStepATR * gATR) && (cur - ns) * dir > stopLv) trade.PositionModify(t, ns, tp);
      }
   }
}
