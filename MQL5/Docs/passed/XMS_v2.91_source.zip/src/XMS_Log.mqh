//+------------------------------------------------------------------+
//| XMS_Log.mqh - XAU MultiSession EA v2.90 USD
//| Trade CSV, equity CSV, regime CSV, Print helper, Telegram, dashboard feed.
//+------------------------------------------------------------------+

void LogLine(string s)
{
   if(!InpWriteLog) return;
   int f = FileOpen(InpLogFile, FILE_READ | FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_SHARE_READ);
   if(f == INVALID_HANDLE) return;
   if(FileSize(f) == 0)
      FileWriteString(f, "time,event,module,dir,lots,req_price,fill_price,spread,sl,tp,net_profit,tag,risk_pct,eq_mult,mtf_mult,vol_mult,regime,sl_dist\r\n");
   FileSeek(f, 0, SEEK_END);
   FileWriteString(f, s + "\r\n");
   FileClose(f);
}

//--- Print helper: every v2.60 event line carries the same prefix
void XLog(string msg) { Print("XAU_MultiSession: ", msg); }

//--- equity CSV: one row per closed M5 bar (body moved verbatim from OnTick; columns unchanged)
void LogEquity(datetime now)
{
   int fe = FileOpen("xms_equity.csv", FILE_READ | FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_SHARE_READ);
   if(fe != INVALID_HANDLE)
   {
      FileSeek(fe, 0, SEEK_END);
      FileWriteString(fe, StringFormat("%s,%.2f,%.2f\r\n", TimeToString(now, TIME_DATE | TIME_MINUTES),
                      AccountInfoDouble(ACCOUNT_BALANCE), AccountInfoDouble(ACCOUNT_EQUITY)));
      FileClose(fe);
   }
}

//--- regime CSV: one row per closed H1 bar. time = bar open time in UTC (research index), values as in s60.build_regime
void LogRegimeRow(datetime barUtc, double adx, double a14, double a24, double volPr, bool trend, bool hvol, bool brk)
{
   int f = FileOpen("xms_regime.csv", FILE_READ | FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_SHARE_READ);
   if(f == INVALID_HANDLE) return;
   if(FileSize(f) == 0) FileWriteString(f, "time,adx,atr14,atr24,atr24pct,trend,hvol,brk\r\n");
   FileSeek(f, 0, SEEK_END);
   FileWriteString(f, StringFormat("%s,%.2f,%.3f,%.3f,%.2f,%d,%d,%d\r\n", TimeToString(barUtc, TIME_DATE | TIME_MINUTES),
                   adx, a14, a24, volPr, (int)trend, (int)hvol, (int)brk));
   FileClose(f);
}

//--- Telegram
string UrlEncode(string s)
{
   uchar b[];
   int n = StringToCharArray(s, b, 0, WHOLE_ARRAY, CP_UTF8);
   string o = "";
   for(int i = 0; i < n; i++)
   {
      int c = (int)b[i];
      if(c == 0) break;
      if((c >= 48 && c <= 57) || (c >= 65 && c <= 90) || (c >= 97 && c <= 122) || c == 45 || c == 95 || c == 46 || c == 126)
         o += CharToString((uchar)c);
      else o += StringFormat("%%%02X", c);
   }
   return o;
}
void TgSend(string text)
{
   if(!gTgOn || TimeLocal() < gTgMuteUntil) return;
   string url  = "https://api.telegram.org/bot" + InpTgToken + "/sendMessage";
   string body = "chat_id=" + UrlEncode(InpTgChatId) + "&text=" + UrlEncode(text);
   uchar raw[]; char data[], res[]; string resHdr = "";
   int n = StringToCharArray(body, raw, 0, WHOLE_ARRAY, CP_UTF8) - 1;   // without the terminating 0
   if(n <= 0) return;
   ArrayResize(data, n);
   for(int i = 0; i < n; i++) data[i] = (char)raw[i];
   ResetLastError();
   int code = WebRequest("POST", url, "Content-Type: application/x-www-form-urlencoded\r\n", 3000, data, res, resHdr);
   if(code == 200) return;
   gTgMuteUntil = TimeLocal() + 60;                                     // failed: do not stall the next ticks
   if(!gTgWarned)
   {
      gTgWarned = true;
      Print("XAU_MultiSession: Telegram request failed (HTTP ", code, ", error ", GetLastError(),
            ") - add https://api.telegram.org in Tools > Options > Expert Advisors > Allow WebRequest, and check token / chat id");
   }
}
void TgDailySummary(datetime utc)
{
   double pl = 0; int trades = 0;
   datetime from = (datetime)(gDayKey * 86400 + gOffSec);
   if(HistorySelect(from, TimeCurrent() + 60))
      for(int i = 0; i < HistoryDealsTotal(); i++)
      {
         ulong d = HistoryDealGetTicket(i);
         if(d == 0 || HistoryDealGetString(d, DEAL_SYMBOL) != _Symbol || !IsOurMagic(HistoryDealGetInteger(d, DEAL_MAGIC))) continue;
         if(HistoryDealGetInteger(d, DEAL_ENTRY) == DEAL_ENTRY_IN) trades++;
         pl += HistoryDealGetDouble(d, DEAL_PROFIT) + HistoryDealGetDouble(d, DEAL_SWAP) + HistoryDealGetDouble(d, DEAL_COMMISSION);
      }
   double bal = AccountInfoDouble(ACCOUNT_BALANCE), eq = AccountInfoDouble(ACCOUNT_EQUITY), peak = GVGet("peak", eq);
   TgSend(StringFormat("XMS %s daily summary %s\nClosed P/L %+.2f | trades %d\nBalance %.2f | Equity %.2f\nDD %.1f%% (max %.1f%%)",
          _Symbol, TimeToString(utc, TIME_DATE), pl, trades, bal, eq, peak > 0 ? MathMax(0.0, (peak - eq) / peak * 100.0) : 0.0, gMaxDD));
}

//--- แดชบอร์ดใช้ฟอนต์ Consolas/Segoe UI ซึ่งไม่มีอักษรไทย จึงแปลสถานะเป็นอังกฤษ
string StatusEn(string s)
{
   string m[11][2] = {{"ข้าม: spread กว้างเกิน", "SKIP: spread too wide"}, {"ข้าม: spread > median", "SKIP: spread > median"},
                      {"ข้าม: RR ต่ำ", "SKIP: low RR"}, {"ข้าม: สวนเทรนด์ใหญ่", "SKIP: against D1 trend"},
                      {"ข้าม: ไม้เปิดเต็ม", "SKIP: max positions"}, {"ข้าม: risk รวมเต็ม", "SKIP: open risk full"},
                      {"ข้าม: lot ต่ำกว่าขั้นต่ำ", "SKIP: min lot too risky"}, {"order ล้มเหลว", "ORDER FAILED"},
                      {"เปิด ", "OPEN "}, {"วันหยุด", "holiday"}, {"ข่าว: งดเปิดไม้", "news: no new trades"}};
   for(int i = 0; i < 11; i++) StringReplace(s, m[i][0], m[i][1]);
   return s == "" ? "waiting for setup" : s;
}

//+------------------------------------------------------------------+
//| เติมข้อมูลแดชบอร์ด (เรียกไม่เกิน 1 ครั้ง/วินาที)                        |
//+------------------------------------------------------------------+
void FillDash(datetime utc, int mn)
{
   XMSDashData d;
   d.eaName = "XAU MULTISESSION"; d.version = "2.90 USD";
   d.modeText = "Mode: " + ModeString(); d.h1ATR24 = (InpStrategyMode == MODE_AUTO) ? gAutoATR : 0.0;
   d.balance = AccountInfoDouble(ACCOUNT_BALANCE); d.equity = AccountInfoDouble(ACCOUNT_EQUITY);
   d.todayPL = gDayStartEq > 0 ? d.equity - gDayStartEq : 0;
   double peak = GVGet("peak", d.equity);
   d.ddPct = peak > 0 ? MathMax(0.0, (peak - d.equity) / peak * 100.0) : 0; d.maxDDPct = gMaxDD; d.haltPct = InpDDHalt;
   d.lotMode = InpLotMode == LOT_FIXED ? "FIXED" : (InpLotMode == LOT_AUTO ? "AUTO" : "RISK %");
   d.curLot = gLastLot; d.curRiskPct = gLastRisk;
   //--- เซสชัน
   int st[4] = {0, 0, 0, 0}; string nm[4] = {"ASIA", "LONDON", "NEW YORK", "ASIA"};
   st[1] = gLonS; st[2] = gNyS; st[3] = 1440;
   d.session = gSessNow; d.sessionActive = gSessNow != "OFF";
   d.nextSession = "ASIA"; d.nextSessionSec = 0;
   int sec = (int)((long)utc % 86400);
   for(int i = 1; i < 4; i++) if(st[i] * 60 > sec) { d.nextSession = nm[i]; d.nextSessionSec = st[i] * 60 - sec; break; }
   d.d1Trend = D1Dir(SymbolInfoDouble(_Symbol, SYMBOL_BID));
   d.spread = Spread(); d.spreadMedian = MedianSpread(); d.spreadGuardMult = InpMedSpreadMult;
   d.spreadOK = InpMedSpreadMult <= 0 || d.spreadMedian <= 0 || d.spread <= InpMedSpreadMult * d.spreadMedian;
   d.newsBlock = InpNewsFilter && (NewsBlocked(utc) || NewsBlocked(utc + InpNewsBefore * 60));
   d.holiday = InpHolidayFilter && IsHoliday(utc);
   d.filterNote = d.newsBlock ? "USD news window" : (d.holiday ? "holiday - no trading" : (gDayStop ? "daily loss stop" : (mn >= gFlat ? "after daily flat" : "clear")));
   if(d.filterNote == "clear" && RegimeStretched())
      d.filterNote = "ER " + DoubleToString(gRegER, 2) + " > " + DoubleToString(InpRegimeERMax, 2) +
                     (InpRegimeMode == 1 ? ": stretched trend" : ": risk x" + DoubleToString(InpRegimeRiskMult, 2));
   if(d.filterNote == "clear" && InpVolShockMode > 0 && VolShock())
      d.filterNote = "vol shock: " + gVolWhy + (InpVolShockMode == 1 ? " - no new trades" : " - risk x" + DoubleToString(InpVolShockRiskMult, 2));
   //--- สถิติทั้งหมดของ EA (ไม้ที่ปิดแล้ว) + R วันนี้ต่อโมดูล
   double gp = 0, gl = 0, tot = 0, modNet[MODS]; int wins = 0, n = 0;
   ArrayInitialize(modNet, 0);
   datetime dayFrom = (datetime)(gDayKey * 86400 + gOffSec);
   if(HistorySelect(0, TimeCurrent() + 60))
      for(int i = 0; i < HistoryDealsTotal(); i++)
      {
         ulong t = HistoryDealGetTicket(i);
         if(t == 0 || HistoryDealGetString(t, DEAL_SYMBOL) != _Symbol) continue;
         long mg = HistoryDealGetInteger(t, DEAL_MAGIC);
         if(!IsOurMagic(mg) || HistoryDealGetInteger(t, DEAL_ENTRY) == DEAL_ENTRY_IN) continue;
         double v = HistoryDealGetDouble(t, DEAL_PROFIT) + HistoryDealGetDouble(t, DEAL_SWAP) + HistoryDealGetDouble(t, DEAL_COMMISSION);
         tot += v; n++; if(v > 0) { wins++; gp += v; } else gl -= v;
         if((datetime)HistoryDealGetInteger(t, DEAL_TIME) >= dayFrom) modNet[(int)(mg - InpMagicBase - 1)] += v;
      }
   d.totalPL = tot; d.trades = n; d.winRatePct = n > 0 ? 100.0 * wins / n : 0; d.profitFactor = gl > 0 ? gp / gl : (gp > 0 ? 99.99 : 0);
   d.halted = gHalted; d.status = gHalted ? "HALTED: max DD reached" : StatusEn(gStatus);
   //--- v2.60 regime panel + risk panel
   d.regOK = RegOK(); d.regTrend = RegTrend(); d.regADX = RegADX(); d.regHighVol = RegHighVol(); d.regATR24Pct = RegATR24Pct();
   d.regBreakout = RegBreakout(); d.regD1 = RegD1Dir();
   d.acctScale = gScale; d.sleeveOn = (InpSleeveMode == 1); d.sleeveLegacy = gSlvScale[0]; d.sleeveNew = gSlvScale[1];
   d.dayPLPct = gDayStartEq > 0 ? 100.0 * (d.equity - gDayStartEq) / gDayStartEq : 0.0; d.dayCapPct = InpDailyLossPct;
   d.openRiskPct = OpenRiskPct(); d.openRiskCap = InpMaxOpenRisk;
   d.haltNote = gHalted ? "HALT: max DD" : (gDayStop ? "STOP: daily loss" : (OrderErrBlocked() ? "STOP: order errors" : (gNetting ? "netting: 1 position" : "none")));
   if(InpModBreaker && d.haltNote == "none")
      for(int k = 0; k < 3; k++) if(gBrkScale[k] < 1.0) d.haltNote = ModName(MOD_ORBA + k) + (gBrkScale[k] <= 0 ? " breaker OFF" : " breaker x0.5");
   if(InpEqRiskMode == 1 || InpEqRiskMode == 2)
   {
      string eqNote = (InpEqRiskMode == 1) ? StringFormat("eq x%.2f (%+.1fR)", EqMult(), gEqStreakR)
                    : StringFormat("eq x%.2f (SMA%d %d/%d)", EqMult(), InpEqSMAN, ArraySize(gEqBal), InpEqSMAN);
      if(!gHalted) d.status += " | " + eqNote;
      if(d.filterNote == "clear") d.filterNote = "clear | " + eqNote;
   }
   if(InpNYPBDirFilter > 0)                                             // v2.70: direction filter state (nothing added when off)
      d.filterNote += StringFormat(" | dir%d ", InpNYPBDirFilter >= 3 ? 3 : (InpNYPBDirFilter == 2 ? 2 : 1)) +   // short form: the note field shows 20 characters
                      ((gDirDay != gDayKey || !gDirOK) ? "n/a" : (gDirVal > 0 ? "UP" : (gDirVal < 0 ? "DOWN" : "FLAT")));
   //--- โมดูลที่ใช้จริง
   int ids[13] = {MOD_ASIA, MOD_ASIAB, MOD_ASIAC, MOD_LONDON, MOD_LDNB, MOD_LONC, MOD_NY, MOD_OVLB, MOD_SCALP, MOD_PM, MOD_ORBA, MOD_DMA, MOD_DML};
   string names[13] = {"ASIA_A", "ASIA_B", "ASIA_C", "LON_A", "LDN_B", "LON_C", "NY_PB", "OVL_B", "SCALP", "NY_PM", "ORB_A", "DM_A", "DM_L"};
   bool en[13]; en[10] = InpUseORBA; en[11] = InpUseDMA; en[12] = InpUseDML; en[0] = InpUseAsia; en[1] = InpUseAsiaB; en[2] = InpUseAsiaC; en[3] = InpUseLondon; en[4] = InpUseLdnB;
   en[5] = InpUseLonC; en[6] = InpUseNY; en[7] = InpUseOvlB; en[8] = InpUseScalp; en[9] = InpUsePM;
   double rk[13]; rk[10] = InpRiskORBA; rk[11] = InpRiskDMA; rk[12] = InpRiskDML; rk[0] = InpRiskAsia; rk[1] = InpRiskAsiaB; rk[2] = InpRiskAsiaC; rk[3] = InpRiskLondon; rk[4] = InpRiskLdnB;
   rk[5] = InpRiskLonC; rk[6] = InpRiskMain; rk[7] = InpRiskOvlB; rk[8] = InpRiskScalp; rk[9] = InpRiskMinor;
   d.modCount = 13;
   for(int k = 0; k < 13; k++)
   {
      int m = ids[k], tr, cl; CountToday(m, tr, cl);
      d.mods[k].name = names[k]; d.mods[k].enabled = en[k]; d.mods[k].tradesToday = tr; d.mods[k].lastSignal = gLastSig[m];
      d.mods[k].hasPos = false; d.mods[k].posDir = 0;
      for(int i = PositionsTotal() - 1; i >= 0; i--)
      {
         ulong t = PositionGetTicket(i);
         if(t != 0 && PositionGetString(POSITION_SYMBOL) == _Symbol && PositionGetInteger(POSITION_MAGIC) == ModMagic(m))
         { d.mods[k].hasPos = true; d.mods[k].posDir = PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY ? 1 : -1; break; }
      }
      double r1 = gDayStartEq * rk[k] / 100.0;
      d.mods[k].rToday = r1 > 0 ? modNet[m] / r1 : 0;
   }
   DashUpdate(d);
}
