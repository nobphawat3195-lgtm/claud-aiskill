//+------------------------------------------------------------------+
//| XMS_Strategy_New.mqh - XAU MultiSession EA v2.90 USD              |
//| Research-validated strategies (cc60s/s60.py, r2_60.py):           |
//| ORB_A : Asia opening-range breakout (M15), hold to daily flat    |
//| DM_A  : day momentum at 01:00 UTC vs previous day open (H1),     |
//|         only when H1 ADX(14, Wilder) < InpDMAADXMax (RANGE)       |
//| DM_L  : day momentum at 07:00 UTC vs today's open (H1)           |
//| Replaces the prototype XMS_NewStrats.mqh. Entry timing, ORB      |
//| range, day flags, max trades are unchanged; the SL distance and  |
//| the DM_A gate now come from the regime engine (Wilder, closed H1 |
//| bars). InpNSATRMode = 1 restores the prototype sources           |
//| (iATR(H1,14) for the SL, iADXWilder(H1,14) for the gate).         |
//+------------------------------------------------------------------+

int TDow(datetime t) { MqlDateTime s; TimeToStruct(t, s); return s.day_of_week; }

//--- open of trading day k (0 = current, 1 = previous); Sunday D1 bars merge into the following Monday
double TradingDayOpen(int k)
{
   int found = -1; double op = 0;
   for(int sh = 0; sh < 15; sh++)
   {
      datetime t = iTime(_Symbol, PERIOD_D1, sh);
      if(t == 0) return 0;
      int dw = TDow(t);
      if(dw == 0) { if(found == k) op = iOpen(_Symbol, PERIOD_D1, sh); continue; }   // Sunday: belongs to the newer Monday
      if(found == k) return op;          // we passed trading day k (no Sunday before it)
      found++;
      op = iOpen(_Symbol, PERIOD_D1, sh);
      if(found == k && dw != 1) return op;
   }
   return (found == k) ? op : 0;
}

//+------------------------------------------------------------------+
//| v2.70 direction filter (InpNYPBDirFilter > 0 only).                |
//| Direction = sign(M5 close at 07:00 UTC - day open): the same two   |
//| prices DM_L uses. DM_L reads iClose(H1, 1) at 07:00 UTC = close of |
//| the 06:00 UTC H1 bar = close of the last M5 bar of that hour; here |
//| it is read from gR[] (today's CLOSED M5 bars, LoadDay) because the |
//| filter is evaluated hours later. Day open = TradingDayOpen(0).     |
//| Not available / close == open -> gDirVal = 0 -> no filtered trade. |
//+------------------------------------------------------------------+
void DirUpdate()
{
   if(gDirDay == gDayKey && gDirOK) return;                              // resolved for today
   gDirDay = gDayKey; gDirOK = false; gDirVal = 0; gDirC = 0; gDirO = 0;
   double c = 0;
   for(int i = gN - 1; i >= 0; i--)
   {
      int bm = (int)((((long)gR[i].time - gOffSec) % 86400) / 60);      // minute of the UTC day (as in LoadDay)
      if(bm >= 420) continue;                                            // bar opens at / after 07:00 UTC
      if(bm >= 360) c = gR[i].close;                                     // last M5 bar of the 06:00 UTC hour (closes by 07:00)
      break;
   }
   double o = TradingDayOpen(0);
   if(c <= 0 || o <= 0) return;                                          // not available: retried on the next bar
   gDirC = c; gDirO = o; gDirOK = true;
   gDirVal = c > o ? 1 : (c < o ? -1 : 0);
   XLog(StringFormat("v2.70 dir filter: 07:00 UTC close %s vs day open %s -> %s", DoubleToString(c, _Digits), DoubleToString(o, _Digits),
        gDirVal > 0 ? "UP" : (gDirVal < 0 ? "DOWN" : "FLAT (no filtered trades today)")));
}
bool DirAllows(int dir) { DirUpdate(); return gDirOK && gDirVal != 0 && gDirVal == dir; }
//--- v2.80: NY_PB gate (callers test InpNYPBDirFilter > 0 first). Modes 1/2 = DirAllows exactly as v2.70.
//    Mode 3 (soft): allowed if the trade agrees with (a) the 07:00 UTC direction OR (b) sign(barClose - day open),
//    barClose = close of the last CLOSED M5 bar. Blocked only when it disagrees with both (unknown counts as not agreeing).
bool NYPBDirOK(int dir, double barClose)
{
   if(InpNYPBDirFilter != 3) return DirAllows(dir);
   if(DirAllows(dir)) return true;
   double o = TradingDayOpen(0);
   if(o > 0 && barClose > 0 && barClose != o && (barClose > o ? 1 : -1) == dir) return true;
   return false;
}
//--- text for the dashboard / chart comment (reads the cached state only)
string DirString()
{
   if(InpNYPBDirFilter <= 0) return "off";
   string m = (InpNYPBDirFilter == 2) ? "NY_PB+PM_CONT" : (InpNYPBDirFilter == 3 ? "NY_PB soft" : "NY_PB");
   if(gDirDay != gDayKey || !gDirOK) return m + " dir n/a";
   return m + (gDirVal > 0 ? " dir UP" : (gDirVal < 0 ? " dir DOWN" : " dir FLAT"));
}

void NSNewDay(int dayKey)
{
   if(dayKey == gNSDay) return;
   gNSDay = dayKey; gOrbAUp = false; gOrbADn = false; gDMADone = false; gDMLDone = false;
}

//--- ATR(H1,14) of the last closed H1 bar used for the SL distance; <= 0 = not available (no trade)
double NSATR()
{
   if(InpNSATRMode == 1)
   {
      double a = Val(hATRH1, 0, 1);
      return (a == EMPTY_VALUE) ? 0.0 : a;
   }
   RegimeUpdate();                       // no-op unless a new H1 bar appeared since the last update
   return RegATR14();
}
//--- ADX(H1,14, Wilder) of the last closed H1 bar for the DM_A gate; EMPTY_VALUE = not available (no trade)
double NSADX()
{
   if(InpNSATRMode == 1) return (hADXH1W != INVALID_HANDLE) ? Val(hADXH1W, 0, 1) : EMPTY_VALUE;
   RegimeUpdate();
   return RegOK() ? RegADX() : EMPTY_VALUE;
}

//--- ORB_A: range = M15 bars 00:00-00:45 UTC; first M15 close beyond it (bar open >= 01:00, entry < 06:00)
void ModuleORBA(datetime utc, int mn)
{
   if(!M15JustClosed() || mn < 75 || mn >= 360) return;
   datetime day0 = utc - (utc % 86400);
   int s0 = iBarShift(_Symbol, PERIOD_M15, day0, true);
   if(s0 < 0) return;
   double hi = -DBL_MAX, lo = DBL_MAX; int n = 0;
   for(int sh = s0; sh >= 1; sh--)
   {
      datetime t = iTime(_Symbol, PERIOD_M15, sh);
      if(t < day0) continue;
      if(t >= day0 + 3600) break;
      hi = MathMax(hi, iHigh(_Symbol, PERIOD_M15, sh)); lo = MathMin(lo, iLow(_Symbol, PERIOD_M15, sh)); n++;
   }
   if(n == 0) return;
   double c = iClose(_Symbol, PERIOD_M15, 1);
   int d = 0;
   if(!gOrbAUp && c > hi) { gOrbAUp = true; d = 1; }
   else if(!gOrbADn && c < lo) { gOrbADn = true; d = -1; }
   if(d == 0) return;
   gLastSig[MOD_ORBA] = (d > 0 ? "BUY " : "SELL ") + TimeToString(utc, TIME_MINUTES);
   if(HasOpen(MOD_ORBA)) return;
   int tr, cl; CountGate(MOD_ORBA, tr, cl);
   if(tr >= InpORBAMaxTrades) return;
   double a = NSATR(); if(a <= 0) return;
   OpenTrade(MOD_ORBA, d, c - d * InpORBASLATR * a, 0, 0, "ORB_A");
}

//--- day momentum: sign(H1 close - reference open), SL = k x ATR(H1), hold to the daily flat
void DayMom(int mod, double ref, double slk, string tag)
{
   double c = iClose(_Symbol, PERIOD_H1, 1);
   if(ref <= 0 || c == ref) return;
   int d = c > ref ? 1 : -1;
   gLastSig[mod] = (d > 0 ? "BUY " : "SELL ") + DoubleToString(c - ref, 2);
   if(HasOpen(mod)) return;
   double a = NSATR(); if(a <= 0) return;
   OpenTrade(mod, d, c - d * slk * a, 0, 0, tag);
}

void ModuleDMA(int mn)
{
   if(gDMADone || mn < 60 || mn >= 70) return;
   gDMADone = true;
   double adx = NSADX();
   if(adx == EMPTY_VALUE || adx >= InpDMAADXMax) { gLastSig[MOD_DMA] = "skip: trend"; return; }
   DayMom(MOD_DMA, TradingDayOpen(1), InpDMASLATR, "DM_A");
}

void ModuleDML(int mn)
{
   if(gDMLDone || mn < 420 || mn >= 430) return;
   gDMLDone = true;
   DayMom(MOD_DML, TradingDayOpen(0), InpDMLSLATR, "DM_L");
}

void NewStrategies(datetime utc, int mn)
{
   NSNewDay((int)(utc / 86400));
   if(InpUseORBA) ModuleORBA(utc, mn);
   if(InpUseDMA)  ModuleDMA(mn);
   if(InpUseDML)  ModuleDML(mn);
}
