//+------------------------------------------------------------------+
//|                                                XMS_Dashboard.mqh |
//|  On-chart dashboard for the "XAU MultiSession" EA (XAUUSD).       |
//|  Chart objects only (OBJ_RECTANGLE_LABEL / OBJ_LABEL), all names  |
//|  prefixed "XMSD_". Objects are created once in DashInit() and     |
//|  only their text / colours / bar width are changed afterwards.    |
//|                                                                  |
//|  Usage:                                                          |
//|     #include "XMS_Dashboard.mqh"                                 |
//|     OnInit   : DashInit(0, CORNER_LEFT_UPPER, 1.0);              |
//|     OnTimer  : XMSDashData d; ...fill...; DashUpdate(d);         |
//|     OnDeinit : DashDeinit();                                     |
//+------------------------------------------------------------------+
#ifndef XMS_DASHBOARD_MQH
#define XMS_DASHBOARD_MQH

//--- public data model ---------------------------------------------
struct XMSDashModule
  {
   string            name;
   bool              enabled;
   bool              hasPos;
   int               posDir;
   int               tradesToday;
   string            lastSignal;
   double            rToday;
  };

struct XMSDashData
  {
   string            eaName;
   string            version;
   double            balance, equity, todayPL, totalPL, ddPct, maxDDPct, haltPct;
   string            lotMode;
   double            curLot;
   double            curRiskPct;
   string            session;
   bool              sessionActive;
   string            nextSession;
   int               nextSessionSec;
   int               d1Trend;             // +1 up, -1 down, 0 n/a
   double            spread, spreadMedian, spreadGuardMult;
   bool              spreadOK;
   bool              newsBlock;
   bool              holiday;
   string            filterNote;
   int               trades;
   double            winRatePct;
   double            profitFactor;
   bool              halted;
   string            status;
   XMSDashModule     mods[13];
   int               modCount;
   //--- v2.60 regime panel (closed H1 bars, XMS_Regime.mqh)
   bool              regOK;
   bool              regTrend;            // true = TREND (ADX14 >= 25), false = RANGE
   double            regADX;
   bool              regHighVol;
   double            regATR24Pct;         // 0..100
   string            modeText;            // v2.90: "Mode: CLASSIC" / RECENT / AUTO(HI|LO)
   double            h1ATR24;             // v2.90: AUTO only (0 otherwise)
   bool              regBreakout;
   int               regD1;               // +1 up, -1 down, 0 flat / n/a (completed D1 bars)
   //--- v2.60 risk panel
   double            acctScale;           // account DD throttle (1 / 0.5 / 0.25)
   bool              sleeveOn;            // InpSleeveMode = 1
   double            sleeveLegacy, sleeveNew;
   double            dayPLPct;            // today's P/L in % of the start-of-day equity
   double            dayCapPct;           // daily loss cap (%)
   double            openRiskPct, openRiskCap;
   string            haltNote;            // "none" or the reason new entries are stopped
  };

//--- theme ---------------------------------------------------------
#define XMSD_PREFIX     "XMSD_"
#define XMSD_C_BG       C'9,11,15'
#define XMSD_C_BORDER   C'44,52,64'
#define XMSD_C_TITLEBG  C'17,22,30'
#define XMSD_C_SEP      C'36,42,52'
#define XMSD_C_TRACK    C'26,32,40'
#define XMSD_C_TEXT     C'255,255,255'
#define XMSD_C_DIM      C'128,140,154'
#define XMSD_C_CYAN     C'0,229,255'
#define XMSD_C_GREEN    C'0,230,118'
#define XMSD_C_RED      C'255,61,87'
#define XMSD_C_AMBER    C'255,179,0'
#define XMSD_C_OFF      C'70,78,90'
#define XMSD_C_CYANDIM  C'72,150,168'
#define XMSD_C_HEADLN   C'18,62,74'

#define XMSD_F_LABEL    "Segoe UI"
#define XMSD_F_BOLD     "Segoe UI Semibold"
#define XMSD_F_NUM      "Consolas"
#define XMSD_F_SYM      "Segoe UI Symbol"

//--- geometry at scale 1.0 (logical px, origin = panel top-left) ----
#define XMSD_W          320.0
#define XMSD_PAD        10.0
#define XMSD_RIGHT      310.0
#define XMSD_TITLE_H    28.0
#define XMSD_HEAD_H     17.0
#define XMSD_ROW_H      16.0
#define XMSD_MODROW_H   15.0
#define XMSD_BAR_H      6.0
#define XMSD_LIGHT      8.0
#define XMSD_MAXMODS    13
#define XMSD_MODCOLS    7

//--- object ids (creation order == z-order, background first) -------
enum ENUM_XMSD_OBJ
  {
   XD_BG=0, XD_TITLEBG, XD_ACCENT, XD_EDGE,
   XD_SEP_ACC, XD_SEP_RISK, XD_SEP_MKT, XD_SEP_REG, XD_SEP_FLT, XD_SEP_MOD, XD_SEP_STAT, XD_SEP_FOOT,
   XD_T_TITLE, XD_T_STATE, XD_L_STATE,
   XD_H_ACC, XD_H_RISK, XD_H_MKT, XD_H_REG, XD_H_FLT, XD_H_MOD, XD_H_STAT,
   XD_K_BAL, XD_V_BAL, XD_K_EQ, XD_V_EQ, XD_K_TOD, XD_V_TOD, XD_K_TOT, XD_V_TOT,
   XD_V_DD, XD_V_MAXDD, XD_BAR_TRK, XD_BAR_FILL, XD_BAR_TK1, XD_BAR_TK2,
   XD_K_MODE, XD_V_MODE, XD_K_LOT, XD_V_LOT, XD_K_RISK, XD_V_RISK,
   XD_L_SES, XD_V_SES, XD_K_D1, XD_V_ARW, XD_V_D1,
   XD_K_NEXT, XD_V_NEXT, XD_K_SPR, XD_V_SPR, XD_L_SPR,
   XD_K_NEWS, XD_K_HOL, XD_V_NOTE,
   XD_C_NAME, XD_C_ST, XD_C_POS, XD_C_TR, XD_C_R, XD_C_SIG,
   XD_K_TR, XD_V_TR, XD_K_WIN, XD_V_WIN, XD_K_PF, XD_V_PF,
   XD_V_STATUS,
   XD_V_RK1L, XD_V_RK1R, XD_V_RK2L, XD_V_RK2R,         // v2.60 risk panel rows
   XD_V_RG1L, XD_V_RG1R, XD_V_RG2L, XD_V_RG2R,         // v2.60 regime panel rows
   XD_M_BASE            // module rows: XD_M_BASE + row*XMSD_MODCOLS + col
  };
// module row columns: 0 light, 1 name, 2 on/off, 3 position, 4 trades, 5 R, 6 signal

//--- internal state --------------------------------------------------
long   g_xmsd_chart   = 0;
bool   g_xmsd_ready   = false;
int    g_xmsd_corner  = 0;
bool   g_xmsd_right   = false;
bool   g_xmsd_lower   = false;
double g_xmsd_scale   = 1.0;     // user scale (fonts)
double g_xmsd_k       = 1.0;     // pixel factor = scale * dpi / 96
int    g_xmsd_mx      = 8;
int    g_xmsd_my      = 8;
int    g_xmsd_wpx     = 320;
int    g_xmsd_hpx     = 460;
int    g_xmsd_rows    = -1;
int    g_xmsd_barw    = -1;
bool   g_xmsd_apply   = false;
int    g_xmsd_total   = 0;
string g_xmsd_txt[];             // last text per object
long   g_xmsd_col[];             // last colour per object
int    g_xmsd_vis[];             // last visibility per object (-1 unknown)

//+------------------------------------------------------------------+
//| small helpers                                                    |
//+------------------------------------------------------------------+
string XmsD_Name(const int id)
  {
   return(XMSD_PREFIX + StringFormat("%03d", id));
  }

int XmsD_Px(const double v)
  {
   return((int)MathRound(v * g_xmsd_k));
  }

int XmsD_Font(const double pt)
  {
   int s = (int)MathRound(pt * g_xmsd_scale);
   return(s < 6 ? 6 : s);
  }

double XmsD_Num(const double v)
  {
   return(MathIsValidNumber(v) ? v : 0.0);
  }

string XmsD_Cut(const string s, const int maxLen)
  {
   if(StringLen(s) <= maxLen)
      return(s);
   return(StringSubstr(s, 0, maxLen - 2) + "..");
  }

//--- money with thousands separators, optional explicit sign ---------
string XmsD_Money(const double value, const bool withSign)
  {
   double v = XmsD_Num(value);
   double a = MathAbs(v);
   int digits = (a >= 10000000.0) ? 0 : 2;
   string raw = DoubleToString(a, digits);
   string ip = raw;
   string fp = "";
   int dot = StringFind(raw, ".");
   if(dot >= 0)
     {
      ip = StringSubstr(raw, 0, dot);
      fp = StringSubstr(raw, dot);
     }
   string out = "";
   int n = StringLen(ip);
   for(int i = 0; i < n; i++)
     {
      if(i > 0 && ((n - i) % 3) == 0)
         out += ",";
      out += StringSubstr(ip, i, 1);
     }
   string sg = "";
   if(v < -0.004999)
      sg = "-";
   else
      if(withSign && v > 0.004999)
         sg = "+";
   return(sg + out + fp);
  }

color XmsD_PLColor(const double v)
  {
   if(v > 0.004999)
      return(XMSD_C_GREEN);
   if(v < -0.004999)
      return(XMSD_C_RED);
   return(XMSD_C_TEXT);
  }

//--- linear blend of two colours (t = 0..1) --------------------------
color XmsD_Blend(const color c1, const color c2, const double t)
  {
   double u = t;
   if(u < 0.0)
      u = 0.0;
   if(u > 1.0)
      u = 1.0;
   int a = (int)c1;
   int b = (int)c2;
   int r1 = a & 0xFF, g1 = (a >> 8) & 0xFF, b1 = (a >> 16) & 0xFF;
   int r2 = b & 0xFF, g2 = (b >> 8) & 0xFF, b2 = (b >> 16) & 0xFF;
   int r = r1 + (int)MathRound((r2 - r1) * u);
   int g = g1 + (int)MathRound((g2 - g1) * u);
   int bl = b1 + (int)MathRound((b2 - b1) * u);
   return((color)((bl << 16) | (g << 8) | r));
  }

//--- cyan -> amber -> red for the drawdown bar -----------------------
color XmsD_DDColor(const double ratio)
  {
   if(ratio <= 0.40)
      return(XMSD_C_CYAN);
   if(ratio <= 0.70)
      return(XmsD_Blend(XMSD_C_CYAN, XMSD_C_AMBER, (ratio - 0.40) / 0.30));
   return(XmsD_Blend(XMSD_C_AMBER, XMSD_C_RED, (ratio - 0.70) / 0.30));
  }

string XmsD_Countdown(const int sec)
  {
   if(sec < 0)
      return("--:--:--");
   int h = sec / 3600;
   int m = (sec % 3600) / 60;
   int s = sec % 60;
   return(StringFormat("%02d:%02d:%02d", h, m, s));
  }

//+------------------------------------------------------------------+
//| object creation                                                  |
//+------------------------------------------------------------------+
void XmsD_Common(const string name)
  {
   ObjectSetInteger(g_xmsd_chart, name, OBJPROP_CORNER, g_xmsd_corner);
   ObjectSetInteger(g_xmsd_chart, name, OBJPROP_BACK, false);
   ObjectSetInteger(g_xmsd_chart, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(g_xmsd_chart, name, OBJPROP_SELECTED, false);
   ObjectSetInteger(g_xmsd_chart, name, OBJPROP_HIDDEN, true);
   ObjectSetInteger(g_xmsd_chart, name, OBJPROP_ZORDER, 0);
   ObjectSetString(g_xmsd_chart, name, OBJPROP_TOOLTIP, "\n");
  }

bool XmsD_MkRect(const int id, const color bg, const color border)
  {
   string name = XmsD_Name(id);
   if(!ObjectCreate(g_xmsd_chart, name, OBJ_RECTANGLE_LABEL, 0, 0, 0))
      return(false);
   XmsD_Common(name);
   ObjectSetInteger(g_xmsd_chart, name, OBJPROP_BORDER_TYPE, BORDER_FLAT);
   ObjectSetInteger(g_xmsd_chart, name, OBJPROP_WIDTH, 1);
   ObjectSetInteger(g_xmsd_chart, name, OBJPROP_STYLE, STYLE_SOLID);
   ObjectSetInteger(g_xmsd_chart, name, OBJPROP_BGCOLOR, bg);
   ObjectSetInteger(g_xmsd_chart, name, OBJPROP_COLOR, border);
   g_xmsd_col[id] = (long)bg;
   return(true);
  }

bool XmsD_MkLabel(const int id, const string font, const double pt, const color clr,
                  const ENUM_ANCHOR_POINT anchor, const string text)
  {
   string name = XmsD_Name(id);
   if(!ObjectCreate(g_xmsd_chart, name, OBJ_LABEL, 0, 0, 0))
      return(false);
   XmsD_Common(name);
   ObjectSetInteger(g_xmsd_chart, name, OBJPROP_ANCHOR, anchor);
   ObjectSetString(g_xmsd_chart, name, OBJPROP_FONT, font);
   ObjectSetInteger(g_xmsd_chart, name, OBJPROP_FONTSIZE, XmsD_Font(pt));
   ObjectSetInteger(g_xmsd_chart, name, OBJPROP_COLOR, clr);
   ObjectSetString(g_xmsd_chart, name, OBJPROP_TEXT, text);
   g_xmsd_col[id] = (long)clr;
   g_xmsd_txt[id] = text;
   return(true);
  }

//--- shortcuts for the three label flavours --------------------------
bool XmsD_Key(const int id, const string text)
  {
   return(XmsD_MkLabel(id, XMSD_F_LABEL, 8, XMSD_C_DIM, ANCHOR_LEFT_UPPER, text));
  }

bool XmsD_Val(const int id, const bool rightAligned)
  {
   return(XmsD_MkLabel(id, XMSD_F_NUM, 9, XMSD_C_TEXT,
                       rightAligned ? ANCHOR_RIGHT_UPPER : ANCHOR_LEFT_UPPER, " "));
  }

bool XmsD_Head(const int id, const string text)
  {
   return(XmsD_MkLabel(id, XMSD_F_BOLD, 7, XMSD_C_CYAN, ANCHOR_LEFT_UPPER, text));
  }

bool XmsD_Light(const int id)
  {
   return(XmsD_MkRect(id, XMSD_C_OFF, XMSD_C_OFF));
  }

bool XmsD_CreateAll()
  {
   bool ok = true;
//--- panel
   ok = XmsD_MkRect(XD_BG, XMSD_C_BG, XMSD_C_BORDER) && ok;
   ok = XmsD_MkRect(XD_TITLEBG, XMSD_C_TITLEBG, XMSD_C_BORDER) && ok;
   ok = XmsD_MkRect(XD_ACCENT, XMSD_C_CYAN, XMSD_C_CYAN) && ok;
   ok = XmsD_MkRect(XD_EDGE, XMSD_C_CYAN, XMSD_C_CYAN) && ok;
   for(int s = XD_SEP_ACC; s <= XD_SEP_STAT; s++)
      ok = XmsD_MkRect(s, XMSD_C_HEADLN, XMSD_C_HEADLN) && ok;
   ok = XmsD_MkRect(XD_SEP_FOOT, XMSD_C_SEP, XMSD_C_SEP) && ok;
//--- title
   ok = XmsD_MkLabel(XD_T_TITLE, XMSD_F_BOLD, 10, XMSD_C_CYAN, ANCHOR_LEFT_UPPER, "XAU MULTISESSION") && ok;
   ok = XmsD_MkLabel(XD_T_STATE, XMSD_F_BOLD, 8, XMSD_C_DIM, ANCHOR_RIGHT_UPPER, " ") && ok;
   ok = XmsD_Light(XD_L_STATE) && ok;
//--- section headers
   ok = XmsD_Head(XD_H_ACC, "ACCOUNT") && ok;
   ok = XmsD_Head(XD_H_RISK, "RISK") && ok;
   ok = XmsD_Head(XD_H_MKT, "MARKET") && ok;
   ok = XmsD_Head(XD_H_REG, "REGIME (H1)") && ok;
   ok = XmsD_Head(XD_H_FLT, "FILTERS") && ok;
   ok = XmsD_Head(XD_H_MOD, "MODULES") && ok;
   ok = XmsD_Head(XD_H_STAT, "STATS") && ok;
//--- account
   ok = XmsD_Key(XD_K_BAL, "Balance") && ok;
   ok = XmsD_Val(XD_V_BAL, true) && ok;
   ok = XmsD_Key(XD_K_EQ, "Equity") && ok;
   ok = XmsD_Val(XD_V_EQ, true) && ok;
   ok = XmsD_Key(XD_K_TOD, "Today P/L") && ok;
   ok = XmsD_Val(XD_V_TOD, true) && ok;
   ok = XmsD_Key(XD_K_TOT, "Total P/L") && ok;
   ok = XmsD_Val(XD_V_TOT, true) && ok;
//--- risk
   ok = XmsD_Val(XD_V_DD, false) && ok;
   ok = XmsD_MkLabel(XD_V_MAXDD, XMSD_F_NUM, 8, XMSD_C_DIM, ANCHOR_RIGHT_UPPER, " ") && ok;
   ok = XmsD_MkRect(XD_BAR_TRK, XMSD_C_TRACK, XMSD_C_SEP) && ok;
   ok = XmsD_MkRect(XD_BAR_FILL, XMSD_C_CYAN, XMSD_C_CYAN) && ok;
   ok = XmsD_MkRect(XD_BAR_TK1, XMSD_C_AMBER, XMSD_C_AMBER) && ok;
   ok = XmsD_MkRect(XD_BAR_TK2, XMSD_C_AMBER, XMSD_C_AMBER) && ok;
   ok = XmsD_Key(XD_K_MODE, "Mode") && ok;
   ok = XmsD_Val(XD_V_MODE, false) && ok;
   ok = XmsD_Key(XD_K_LOT, "Lot") && ok;
   ok = XmsD_Val(XD_V_LOT, false) && ok;
   ok = XmsD_Key(XD_K_RISK, "Risk") && ok;
   ok = XmsD_Val(XD_V_RISK, true) && ok;
//--- market
   ok = XmsD_Light(XD_L_SES) && ok;
   ok = XmsD_MkLabel(XD_V_SES, XMSD_F_BOLD, 9, XMSD_C_TEXT, ANCHOR_LEFT_UPPER, " ") && ok;
   ok = XmsD_Key(XD_K_D1, "D1") && ok;
   ok = XmsD_MkLabel(XD_V_ARW, XMSD_F_SYM, 8, XMSD_C_DIM, ANCHOR_LEFT_UPPER, "-") && ok;
   ok = XmsD_Val(XD_V_D1, false) && ok;
   ok = XmsD_Key(XD_K_NEXT, "Next") && ok;
   ok = XmsD_Val(XD_V_NEXT, true) && ok;
   ok = XmsD_Key(XD_K_SPR, "Spread") && ok;
   ok = XmsD_Val(XD_V_SPR, true) && ok;
   ok = XmsD_Light(XD_L_SPR) && ok;
//--- filters
   ok = XmsD_MkLabel(XD_K_NEWS, XMSD_F_NUM, 9, XMSD_C_GREEN, ANCHOR_LEFT_UPPER, "NEWS  OK") && ok;
   ok = XmsD_MkLabel(XD_K_HOL, XMSD_F_NUM, 9, XMSD_C_GREEN, ANCHOR_LEFT_UPPER, "HOLIDAY  NO") && ok;
   ok = XmsD_MkLabel(XD_V_NOTE, XMSD_F_LABEL, 8, XMSD_C_DIM, ANCHOR_RIGHT_UPPER, " ") && ok;
//--- modules: column captions
   ok = XmsD_MkLabel(XD_C_NAME, XMSD_F_LABEL, 7, XMSD_C_DIM, ANCHOR_LEFT_UPPER, "MODULE") && ok;
   ok = XmsD_MkLabel(XD_C_ST, XMSD_F_LABEL, 7, XMSD_C_DIM, ANCHOR_LEFT_UPPER, "ST") && ok;
   ok = XmsD_MkLabel(XD_C_POS, XMSD_F_LABEL, 7, XMSD_C_DIM, ANCHOR_LEFT_UPPER, "POS") && ok;
   ok = XmsD_MkLabel(XD_C_TR, XMSD_F_LABEL, 7, XMSD_C_DIM, ANCHOR_RIGHT_UPPER, "TR") && ok;
   ok = XmsD_MkLabel(XD_C_R, XMSD_F_LABEL, 7, XMSD_C_DIM, ANCHOR_RIGHT_UPPER, "R") && ok;
   ok = XmsD_MkLabel(XD_C_SIG, XMSD_F_LABEL, 7, XMSD_C_DIM, ANCHOR_LEFT_UPPER, "SIGNAL") && ok;
//--- stats
   ok = XmsD_Key(XD_K_TR, "Trades") && ok;
   ok = XmsD_Val(XD_V_TR, false) && ok;
   ok = XmsD_Key(XD_K_WIN, "Win") && ok;
   ok = XmsD_Val(XD_V_WIN, false) && ok;
   ok = XmsD_Key(XD_K_PF, "PF") && ok;
   ok = XmsD_Val(XD_V_PF, true) && ok;
//--- footer status
   ok = XmsD_MkLabel(XD_V_STATUS, XMSD_F_LABEL, 8, XMSD_C_DIM, ANCHOR_LEFT_UPPER, " ") && ok;
//--- v2.60 risk panel rows (scales / open risk, daily P/L / halt state)
   ok = XmsD_MkLabel(XD_V_RK1L, XMSD_F_NUM, 8, XMSD_C_TEXT, ANCHOR_LEFT_UPPER, " ") && ok;
   ok = XmsD_MkLabel(XD_V_RK1R, XMSD_F_NUM, 8, XMSD_C_TEXT, ANCHOR_RIGHT_UPPER, " ") && ok;
   ok = XmsD_MkLabel(XD_V_RK2L, XMSD_F_NUM, 8, XMSD_C_TEXT, ANCHOR_LEFT_UPPER, " ") && ok;
   ok = XmsD_MkLabel(XD_V_RK2R, XMSD_F_NUM, 8, XMSD_C_DIM, ANCHOR_RIGHT_UPPER, " ") && ok;
//--- v2.60 regime panel rows
   ok = XmsD_MkLabel(XD_V_RG1L, XMSD_F_NUM, 9, XMSD_C_TEXT, ANCHOR_LEFT_UPPER, " ") && ok;
   ok = XmsD_MkLabel(XD_V_RG1R, XMSD_F_NUM, 9, XMSD_C_DIM, ANCHOR_RIGHT_UPPER, " ") && ok;
   ok = XmsD_MkLabel(XD_V_RG2L, XMSD_F_NUM, 9, XMSD_C_TEXT, ANCHOR_LEFT_UPPER, " ") && ok;
   ok = XmsD_MkLabel(XD_V_RG2R, XMSD_F_NUM, 9, XMSD_C_DIM, ANCHOR_RIGHT_UPPER, " ") && ok;
//--- module rows
   for(int r = 0; r < XMSD_MAXMODS; r++)
     {
      int b = XD_M_BASE + r * XMSD_MODCOLS;
      ok = XmsD_Light(b + 0) && ok;
      ok = XmsD_MkLabel(b + 1, XMSD_F_LABEL, 8, XMSD_C_TEXT, ANCHOR_LEFT_UPPER, " ") && ok;
      ok = XmsD_MkLabel(b + 2, XMSD_F_NUM, 8, XMSD_C_DIM, ANCHOR_LEFT_UPPER, " ") && ok;
      ok = XmsD_MkLabel(b + 3, XMSD_F_NUM, 8, XMSD_C_DIM, ANCHOR_LEFT_UPPER, " ") && ok;
      ok = XmsD_MkLabel(b + 4, XMSD_F_NUM, 8, XMSD_C_TEXT, ANCHOR_RIGHT_UPPER, " ") && ok;
      ok = XmsD_MkLabel(b + 5, XMSD_F_NUM, 8, XMSD_C_DIM, ANCHOR_RIGHT_UPPER, " ") && ok;
      ok = XmsD_MkLabel(b + 6, XMSD_F_NUM, 8, XMSD_C_DIM, ANCHOR_LEFT_UPPER, " ") && ok;
     }
   return(ok);
  }

//+------------------------------------------------------------------+
//| layout (positions only; no create / delete)                      |
//+------------------------------------------------------------------+
//--- place object: logical panel coords -> corner-relative distances.
//    The anchor point of every object stays on its own left/upper (or
//    right/upper) side, so for right / lower corners the distance is
//    mirrored against the panel size and the panel grows inward.
void XmsD_P(const int id, const double lx, const double ly)
  {
   if(!g_xmsd_apply)
      return;
   int px = XmsD_Px(lx);
   int py = XmsD_Px(ly);
   int xd = g_xmsd_right ? (g_xmsd_mx + g_xmsd_wpx - px) : (g_xmsd_mx + px);
   int yd = g_xmsd_lower ? (g_xmsd_my + g_xmsd_hpx - py) : (g_xmsd_my + py);
   string name = XmsD_Name(id);
   ObjectSetInteger(g_xmsd_chart, name, OBJPROP_XDISTANCE, xd);
   ObjectSetInteger(g_xmsd_chart, name, OBJPROP_YDISTANCE, yd);
  }

void XmsD_SizePx(const int id, const int w, const int h)
  {
   if(!g_xmsd_apply)
      return;
   string name = XmsD_Name(id);
   ObjectSetInteger(g_xmsd_chart, name, OBJPROP_XSIZE, (w < 1 ? 1 : w));
   ObjectSetInteger(g_xmsd_chart, name, OBJPROP_YSIZE, (h < 1 ? 1 : h));
  }

void XmsD_Z(const int id, const double w, const double h)
  {
   XmsD_SizePx(id, XmsD_Px(w), XmsD_Px(h));
  }

void XmsD_PlaceLight(const int id, const double lx, const double rowY)
  {
   XmsD_P(id, lx, rowY + 5.0);
   XmsD_Z(id, XMSD_LIGHT, XMSD_LIGHT);
  }

void XmsD_Show(const int id, const bool show)
  {
   int v = show ? 1 : 0;
   if(g_xmsd_vis[id] == v)
      return;
   g_xmsd_vis[id] = v;
   ObjectSetInteger(g_xmsd_chart, XmsD_Name(id), OBJPROP_TIMEFRAMES,
                    show ? OBJ_ALL_PERIODS : OBJ_NO_PERIODS);
  }

//--- section header: cyan caption + faint line running from the end
//    of the caption to the right edge; returns next y ----------------
double XmsD_Section(const int sepId, const int headId, const double y, const int chars)
  {
   double x0 = XMSD_PAD + 6.5 * chars + 8.0;     // approx caption width at 7 pt
   XmsD_P(headId, XMSD_PAD, y + 3.0);
   XmsD_P(sepId, x0, y + 9.0);
   XmsD_SizePx(sepId, XmsD_Px(XMSD_RIGHT - x0), 1);
   return(y + XMSD_HEAD_H);
  }

//--- runs the layout; with apply=false it only measures the height ---
double XmsD_Layout(const int rows, const bool apply)
  {
   g_xmsd_apply = apply;
   double y = 0.0;
//--- frame + title bar
   XmsD_P(XD_BG, 0, 0);
   XmsD_SizePx(XD_BG, g_xmsd_wpx, g_xmsd_hpx);
   XmsD_P(XD_TITLEBG, 0, 0);
   XmsD_SizePx(XD_TITLEBG, g_xmsd_wpx, XmsD_Px(XMSD_TITLE_H));
//--- neon accent: thin line under the title bar + left edge strip
   XmsD_P(XD_ACCENT, 0, XMSD_TITLE_H - 1.0);
   XmsD_SizePx(XD_ACCENT, g_xmsd_wpx, XmsD_Px(1.0));
   XmsD_P(XD_EDGE, 0, 0);
   XmsD_SizePx(XD_EDGE, (XmsD_Px(2.0) < 2 ? 2 : XmsD_Px(2.0)), g_xmsd_hpx);
   XmsD_P(XD_T_TITLE, XMSD_PAD, 5.0);
   XmsD_P(XD_T_STATE, 296.0, 7.0);
   XmsD_PlaceLight(XD_L_STATE, 302.0, 5.0);
   y = XMSD_TITLE_H;
//--- ACCOUNT
   y = XmsD_Section(XD_SEP_ACC, XD_H_ACC, y, 7);
   XmsD_P(XD_K_BAL, 10.0, y + 2.0);
   XmsD_P(XD_V_BAL, 154.0, y + 1.0);
   XmsD_P(XD_K_EQ, 170.0, y + 2.0);
   XmsD_P(XD_V_EQ, XMSD_RIGHT, y + 1.0);
   y += XMSD_ROW_H;
   XmsD_P(XD_K_TOD, 10.0, y + 2.0);
   XmsD_P(XD_V_TOD, 154.0, y + 1.0);
   XmsD_P(XD_K_TOT, 170.0, y + 2.0);
   XmsD_P(XD_V_TOT, XMSD_RIGHT, y + 1.0);
   y += XMSD_ROW_H;
//--- RISK
   y = XmsD_Section(XD_SEP_RISK, XD_H_RISK, y, 4);
   XmsD_P(XD_V_DD, 10.0, y + 1.0);
   XmsD_P(XD_V_MAXDD, XMSD_RIGHT, y + 2.0);
   y += XMSD_ROW_H;
   XmsD_P(XD_BAR_TRK, XMSD_PAD, y + 4.0);
   XmsD_Z(XD_BAR_TRK, XMSD_W - 2.0 * XMSD_PAD, XMSD_BAR_H);
   XmsD_P(XD_BAR_FILL, XMSD_PAD, y + 4.0);
   if(apply)
     {
      XmsD_SizePx(XD_BAR_FILL, (g_xmsd_barw > 0 ? g_xmsd_barw : 1), XmsD_Px(XMSD_BAR_H));
     }
//--- throttle ticks at 50% of the limit, just above and below the bar
   double tickX = XMSD_PAD + 0.5 * (XMSD_W - 2.0 * XMSD_PAD) - 1.0;
   XmsD_P(XD_BAR_TK1, tickX, y + 1.0);
   XmsD_Z(XD_BAR_TK1, 2.0, 3.0);
   XmsD_P(XD_BAR_TK2, tickX, y + 4.0 + XMSD_BAR_H);
   XmsD_Z(XD_BAR_TK2, 2.0, 3.0);
   y += 14.0;
   XmsD_P(XD_K_MODE, 10.0, y + 2.0);
   XmsD_P(XD_V_MODE, 42.0, y + 1.0);
   XmsD_P(XD_K_LOT, 124.0, y + 2.0);
   XmsD_P(XD_V_LOT, 146.0, y + 1.0);
   XmsD_P(XD_K_RISK, 214.0, y + 2.0);
   XmsD_P(XD_V_RISK, XMSD_RIGHT, y + 1.0);
   y += XMSD_ROW_H;
   XmsD_P(XD_V_RK1L, 10.0, y + 1.0);
   XmsD_P(XD_V_RK1R, XMSD_RIGHT, y + 1.0);
   y += XMSD_ROW_H;
   XmsD_P(XD_V_RK2L, 10.0, y + 1.0);
   XmsD_P(XD_V_RK2R, XMSD_RIGHT, y + 1.0);
   y += XMSD_ROW_H;
//--- MARKET
   y = XmsD_Section(XD_SEP_MKT, XD_H_MKT, y, 6);
   XmsD_PlaceLight(XD_L_SES, 10.0, y);
   XmsD_P(XD_V_SES, 24.0, y + 1.0);
   XmsD_P(XD_K_D1, 232.0, y + 2.0);
   XmsD_P(XD_V_ARW, 251.0, y + 1.0);
   XmsD_P(XD_V_D1, 266.0, y + 1.0);
   y += XMSD_ROW_H;
   XmsD_P(XD_K_NEXT, 10.0, y + 2.0);
   XmsD_P(XD_V_NEXT, XMSD_RIGHT, y + 1.0);
   y += XMSD_ROW_H;
   XmsD_P(XD_K_SPR, 10.0, y + 2.0);
   XmsD_P(XD_V_SPR, 296.0, y + 1.0);
   XmsD_PlaceLight(XD_L_SPR, 302.0, y);
   y += XMSD_ROW_H;
//--- REGIME
   y = XmsD_Section(XD_SEP_REG, XD_H_REG, y, 11);
   XmsD_P(XD_V_RG1L, 10.0, y + 1.0);
   XmsD_P(XD_V_RG1R, XMSD_RIGHT, y + 1.0);
   y += XMSD_ROW_H;
   XmsD_P(XD_V_RG2L, 10.0, y + 1.0);
   XmsD_P(XD_V_RG2R, XMSD_RIGHT, y + 1.0);
   y += XMSD_ROW_H;
//--- FILTERS
   y = XmsD_Section(XD_SEP_FLT, XD_H_FLT, y, 7);
   XmsD_P(XD_K_NEWS, 10.0, y + 1.0);
   XmsD_P(XD_K_HOL, 98.0, y + 1.0);
   XmsD_P(XD_V_NOTE, XMSD_RIGHT, y + 2.0);
   y += XMSD_ROW_H;
//--- MODULES
   y = XmsD_Section(XD_SEP_MOD, XD_H_MOD, y, 7);
   XmsD_P(XD_C_NAME, 24.0, y + 1.0);
   XmsD_P(XD_C_ST, 104.0, y + 1.0);
   XmsD_P(XD_C_POS, 134.0, y + 1.0);
   XmsD_P(XD_C_TR, 186.0, y + 1.0);
   XmsD_P(XD_C_R, 226.0, y + 1.0);
   XmsD_P(XD_C_SIG, 236.0, y + 1.0);
   y += 13.0;
   for(int r = 0; r < XMSD_MAXMODS; r++)
     {
      int b = XD_M_BASE + r * XMSD_MODCOLS;
      bool show = (r < rows);
      if(apply)
        {
         for(int c = 0; c < XMSD_MODCOLS; c++)
            XmsD_Show(b + c, show);
        }
      if(!show)
         continue;
      XmsD_PlaceLight(b + 0, 10.0, y - 1.0);
      XmsD_P(b + 1, 24.0, y + 1.0);
      XmsD_P(b + 2, 104.0, y + 1.0);
      XmsD_P(b + 3, 134.0, y + 1.0);
      XmsD_P(b + 4, 186.0, y + 1.0);
      XmsD_P(b + 5, 226.0, y + 1.0);
      XmsD_P(b + 6, 236.0, y + 1.0);
      y += XMSD_MODROW_H;
     }
//--- STATS
   y = XmsD_Section(XD_SEP_STAT, XD_H_STAT, y, 5);
   XmsD_P(XD_K_TR, 10.0, y + 2.0);
   XmsD_P(XD_V_TR, 50.0, y + 1.0);
   XmsD_P(XD_K_WIN, 130.0, y + 2.0);
   XmsD_P(XD_V_WIN, 156.0, y + 1.0);
   XmsD_P(XD_K_PF, 236.0, y + 2.0);
   XmsD_P(XD_V_PF, XMSD_RIGHT, y + 1.0);
   y += XMSD_ROW_H;
//--- footer status line
   XmsD_P(XD_SEP_FOOT, XMSD_PAD, y + 2.0);
   XmsD_SizePx(XD_SEP_FOOT, XmsD_Px(XMSD_W - 2.0 * XMSD_PAD), 1);
   XmsD_P(XD_V_STATUS, 10.0, y + 4.0);
   y += 4.0 + XMSD_ROW_H + 2.0;
   g_xmsd_apply = false;
   return(y);
  }

void XmsD_Relayout(const int rows)
  {
   g_xmsd_rows = rows;
   g_xmsd_wpx = XmsD_Px(XMSD_W);
   g_xmsd_hpx = XmsD_Px(XmsD_Layout(rows, false));
   XmsD_Layout(rows, true);
  }

//--- (re)creates every object; used by DashInit and for self-healing -
bool XmsD_Build()
  {
   ObjectsDeleteAll(g_xmsd_chart, XMSD_PREFIX);
   g_xmsd_total = XD_M_BASE + XMSD_MAXMODS * XMSD_MODCOLS;
   ArrayResize(g_xmsd_txt, g_xmsd_total);
   ArrayResize(g_xmsd_col, g_xmsd_total);
   ArrayResize(g_xmsd_vis, g_xmsd_total);
   for(int i = 0; i < g_xmsd_total; i++)
     {
      g_xmsd_txt[i] = "";
      g_xmsd_col[i] = -1;
      g_xmsd_vis[i] = -1;
     }
   g_xmsd_barw = -1;
   if(!XmsD_CreateAll())
     {
      ObjectsDeleteAll(g_xmsd_chart, XMSD_PREFIX);
      return(false);
     }
   XmsD_Relayout(g_xmsd_rows < 0 ? XMSD_MAXMODS : g_xmsd_rows);
   return(true);
  }

//+------------------------------------------------------------------+
//| cached setters (touch the chart only when a value changed)       |
//+------------------------------------------------------------------+
void XmsD_SetText(const int id, const string text, const color clr)
  {
   string t = (text == "") ? " " : text;
   if(g_xmsd_txt[id] != t)
     {
      g_xmsd_txt[id] = t;
      ObjectSetString(g_xmsd_chart, XmsD_Name(id), OBJPROP_TEXT, t);
     }
   if(g_xmsd_col[id] != (long)clr)
     {
      g_xmsd_col[id] = (long)clr;
      ObjectSetInteger(g_xmsd_chart, XmsD_Name(id), OBJPROP_COLOR, clr);
     }
  }

void XmsD_SetFill(const int id, const color clr)
  {
   if(g_xmsd_col[id] == (long)clr)
      return;
   g_xmsd_col[id] = (long)clr;
   string name = XmsD_Name(id);
   ObjectSetInteger(g_xmsd_chart, name, OBJPROP_BGCOLOR, clr);
   ObjectSetInteger(g_xmsd_chart, name, OBJPROP_COLOR, clr);
  }

//+------------------------------------------------------------------+
//| public API                                                       |
//+------------------------------------------------------------------+
bool DashInit(const long chartId, const int corner, const double scale)
  {
   g_xmsd_ready = false;
   g_xmsd_chart = (chartId > 0) ? chartId : ChartID();

   int c = corner;
   if(c != CORNER_LEFT_UPPER && c != CORNER_LEFT_LOWER &&
      c != CORNER_RIGHT_LOWER && c != CORNER_RIGHT_UPPER)
      c = CORNER_LEFT_UPPER;
   g_xmsd_corner = c;
   g_xmsd_right = (c == CORNER_RIGHT_UPPER || c == CORNER_RIGHT_LOWER);
   g_xmsd_lower = (c == CORNER_LEFT_LOWER || c == CORNER_RIGHT_LOWER);

   double sc = MathIsValidNumber(scale) ? scale : 1.0;
   if(sc < 0.8)
      sc = 0.8;
   if(sc > 1.5)
      sc = 1.5;
   g_xmsd_scale = sc;

   int dpi = (int)TerminalInfoInteger(TERMINAL_SCREEN_DPI);
   if(dpi < 48)
      dpi = 96;
   g_xmsd_k = sc * (double)dpi / 96.0;      // fonts are in points, pixels need the DPI factor

   g_xmsd_mx = XmsD_Px(8.0);
   g_xmsd_my = g_xmsd_lower ? XmsD_Px(8.0) : XmsD_Px(20.0);   // keep clear of the chart's top info line
   g_xmsd_rows = -1;

   if(!XmsD_Build())
      return(false);

   g_xmsd_ready = true;
   ChartRedraw(g_xmsd_chart);
   return(true);
  }

void DashUpdate(const XMSDashData &d)
  {
   if(!g_xmsd_ready)
      return;

//--- self-heal if the objects were wiped (template change, "delete all")
   if(ObjectFind(g_xmsd_chart, XmsD_Name(XD_BG)) < 0)
     {
      if(!XmsD_Build())
         return;
     }

//--- module count changed -> move / resize only
   int rows = d.modCount;
   if(rows < 0)
      rows = 0;
   if(rows > XMSD_MAXMODS)
      rows = XMSD_MAXMODS;
   if(rows != g_xmsd_rows)
      XmsD_Relayout(rows);

//--- title -----------------------------------------------------------
   string title = (d.eaName == "") ? "XAU MULTISESSION" : XmsD_Cut(d.eaName, 20);
   StringToUpper(title);
   if(d.version != "")
     {
      string v1 = StringSubstr(d.version, 0, 1);
      title += ((v1 == "v" || v1 == "V") ? "  " : "  v") + XmsD_Cut(d.version, 8);
     }
   XmsD_SetText(XD_T_TITLE, title, XMSD_C_CYAN);
   XmsD_SetText(XD_T_STATE, d.halted ? "HALTED" : "RUNNING", d.halted ? XMSD_C_RED : XMSD_C_GREEN);
   XmsD_SetFill(XD_L_STATE, d.halted ? XMSD_C_RED : XMSD_C_GREEN);

//--- account ---------------------------------------------------------
   XmsD_SetText(XD_V_BAL, XmsD_Money(d.balance, false), XMSD_C_TEXT);
   XmsD_SetText(XD_V_EQ, XmsD_Money(d.equity, false), XMSD_C_TEXT);
   XmsD_SetText(XD_V_TOD, XmsD_Money(d.todayPL, true), XmsD_PLColor(XmsD_Num(d.todayPL)));
   XmsD_SetText(XD_V_TOT, XmsD_Money(d.totalPL, true), XmsD_PLColor(XmsD_Num(d.totalPL)));

//--- risk ------------------------------------------------------------
   double dd = MathMax(0.0, XmsD_Num(d.ddPct));
   double halt = XmsD_Num(d.haltPct);
   double ratio = 0.0;
   string ddText = "";
   if(halt > 0.0)
     {
      ratio = dd / halt;
      bool whole = (MathAbs(halt - MathRound(halt)) < 0.05);
      ddText = StringFormat("DD %.1f%% / limit ", dd) + DoubleToString(halt, whole ? 0 : 1) + "%";
     }
   else
     {
      ratio = dd / 100.0;
      ddText = StringFormat("DD %.1f%% / no limit", dd);
     }
   if(ratio > 1.0)
      ratio = 1.0;
   color ddClr = XmsD_DDColor(ratio);
   XmsD_SetText(XD_V_DD, ddText, (ratio >= 0.70) ? ddClr : XMSD_C_TEXT);
   XmsD_SetText(XD_V_MAXDD, StringFormat("max %.1f%%", MathMax(0.0, XmsD_Num(d.maxDDPct))), XMSD_C_DIM);

   int trackPx = XmsD_Px(XMSD_W - 2.0 * XMSD_PAD);
   int fillPx = (int)MathRound(trackPx * ratio);
   if(ratio > 0.0 && fillPx < 2)
      fillPx = 2;
   if(fillPx != g_xmsd_barw)
     {
      g_xmsd_barw = fillPx;
      XmsD_Show(XD_BAR_FILL, fillPx > 0);
      if(fillPx > 0)
         ObjectSetInteger(g_xmsd_chart, XmsD_Name(XD_BAR_FILL), OBJPROP_XSIZE, fillPx);
     }
   XmsD_SetFill(XD_BAR_FILL, ddClr);
   XmsD_Show(XD_BAR_TK1, halt > 0.0);       // ticks only mean something with a limit
   XmsD_Show(XD_BAR_TK2, halt > 0.0);

   XmsD_SetText(XD_V_MODE, (d.lotMode == "") ? "-" : XmsD_Cut(d.lotMode, 10), XMSD_C_CYAN);
   XmsD_SetText(XD_V_LOT, DoubleToString(XmsD_Num(d.curLot), 2), XMSD_C_TEXT);
   XmsD_SetText(XD_V_RISK, StringFormat("%.2f%%", XmsD_Num(d.curRiskPct)), XMSD_C_TEXT);

//--- v2.60 risk panel: account scale, sleeve scales, open risk vs cap, daily P/L vs cap, halt state
   double asc = XmsD_Num(d.acctScale);
   string scText = StringFormat("Scale x%.2f", asc);
   bool   scCut = (asc < 0.999);
   if(d.sleeveOn)
     {
      scText += StringFormat("  L x%.2f N x%.2f", XmsD_Num(d.sleeveLegacy), XmsD_Num(d.sleeveNew));
      scCut = scCut || d.sleeveLegacy < 0.999 || d.sleeveNew < 0.999;
     }
   XmsD_SetText(XD_V_RK1L, scText, scCut ? XMSD_C_AMBER : XMSD_C_TEXT);
   double orp = XmsD_Num(d.openRiskPct), orc = XmsD_Num(d.openRiskCap);
   XmsD_SetText(XD_V_RK1R, StringFormat("Open %.1f/%.1f%%", orp, orc), (orc > 0.0 && orp >= 0.9 * orc) ? XMSD_C_AMBER : XMSD_C_TEXT);
   double dpl = XmsD_Num(d.dayPLPct), dcap = XmsD_Num(d.dayCapPct);
   color  dClr = XMSD_C_TEXT;
   if(dcap > 0.0 && dpl <= -dcap)
      dClr = XMSD_C_RED;
   else
      if(dcap > 0.0 && dpl <= -0.5 * dcap)
         dClr = XMSD_C_AMBER;
   XmsD_SetText(XD_V_RK2L, StringFormat("Day %+.2f%% / cap -%.1f%%", dpl, dcap), dClr);
   bool noHalt = (d.haltNote == "" || d.haltNote == "none");
   XmsD_SetText(XD_V_RK2R, noHalt ? "halt: none" : XmsD_Cut(d.haltNote, 20), noHalt ? XMSD_C_DIM : XMSD_C_RED);

//--- v2.60 regime panel ---------------------------------------------------
   if(d.regOK)
     {
      XmsD_SetText(XD_V_RG1L, StringFormat("%s  ADX %.1f", d.regTrend ? "TREND" : "RANGE", XmsD_Num(d.regADX)),
                   d.regTrend ? XMSD_C_CYAN : XMSD_C_TEXT);
      XmsD_SetText(XD_V_RG1R, d.regD1 > 0 ? "D1 UP" : (d.regD1 < 0 ? "D1 DOWN" : "D1 FLAT"),
                   d.regD1 > 0 ? XMSD_C_GREEN : (d.regD1 < 0 ? XMSD_C_RED : XMSD_C_DIM));
      XmsD_SetText(XD_V_RG2L, StringFormat("%s  ATR24 p%.0f", d.regHighVol ? "HIGH VOL" : "LOW VOL", XmsD_Num(d.regATR24Pct)),
                   d.regHighVol ? XMSD_C_AMBER : XMSD_C_TEXT);
      // v2.90: right cell of the 2nd regime row shows the strategy mode (+ H1 ATR24 in AUTO); breakout flag stays in the regime CSV
      XmsD_SetText(XD_V_RG2R, d.h1ATR24 > 0 ? StringFormat("%s %.1f", XmsD_Cut(d.modeText, 14), XmsD_Num(d.h1ATR24)) : XmsD_Cut(d.modeText, 20), XMSD_C_AMBER);
     }
   else
     {
      XmsD_SetText(XD_V_RG1L, "n/a (H1 history loading)", XMSD_C_DIM);
      XmsD_SetText(XD_V_RG1R, " ", XMSD_C_DIM);
      XmsD_SetText(XD_V_RG2L, " ", XMSD_C_DIM);
      XmsD_SetText(XD_V_RG2R, XmsD_Cut(d.modeText, 20), XMSD_C_AMBER);
     }

//--- market ----------------------------------------------------------
   string sesUp = d.session;
   StringToUpper(sesUp);
   bool sesOff = (sesUp == "OFF" || sesUp == "");
   bool sesLive = (d.sessionActive && !sesOff);
   XmsD_SetFill(XD_L_SES, sesLive ? XMSD_C_GREEN : XMSD_C_OFF);
   XmsD_SetText(XD_V_SES, sesOff ? "OFF (between sessions)" : XmsD_Cut(d.session, 22),
                sesLive ? XMSD_C_TEXT : XMSD_C_DIM);

   if(d.d1Trend > 0)
     {
      XmsD_SetText(XD_V_ARW, ShortToString((ushort)0x25B2), XMSD_C_GREEN);
      XmsD_SetText(XD_V_D1, "UP", XMSD_C_GREEN);
     }
   else
      if(d.d1Trend < 0)
        {
         XmsD_SetText(XD_V_ARW, ShortToString((ushort)0x25BC), XMSD_C_RED);
         XmsD_SetText(XD_V_D1, "DOWN", XMSD_C_RED);
        }
      else
        {
         XmsD_SetText(XD_V_ARW, "-", XMSD_C_DIM);
         XmsD_SetText(XD_V_D1, "N/A", XMSD_C_DIM);
        }

   string nextText = (d.nextSession == "") ? "-" : (XmsD_Cut(d.nextSession, 18) + "  " + XmsD_Countdown(d.nextSessionSec));
   XmsD_SetText(XD_V_NEXT, nextText, XMSD_C_TEXT);

   string sprText = StringFormat("%.1f | %.1f x%.1f", XmsD_Num(d.spread), XmsD_Num(d.spreadMedian), XmsD_Num(d.spreadGuardMult));
   XmsD_SetText(XD_V_SPR, sprText, d.spreadOK ? XMSD_C_TEXT : XMSD_C_RED);
   XmsD_SetFill(XD_L_SPR, d.spreadOK ? XMSD_C_GREEN : XMSD_C_RED);

//--- filters ---------------------------------------------------------
   XmsD_SetText(XD_K_NEWS, d.newsBlock ? "NEWS  BLOCK" : "NEWS  OK",
                d.newsBlock ? XMSD_C_RED : XMSD_C_GREEN);
   XmsD_SetText(XD_K_HOL, d.holiday ? "HOLIDAY  YES" : "HOLIDAY  NO",
                d.holiday ? XMSD_C_AMBER : XMSD_C_GREEN);
   bool blocked = (d.newsBlock || d.holiday);
   string note = d.filterNote;
   if(note == "")
      note = blocked ? "blocked" : "clear";
   XmsD_SetText(XD_V_NOTE, XmsD_Cut(note, 20), XMSD_C_DIM);

//--- modules ---------------------------------------------------------
   for(int r = 0; r < rows; r++)
     {
      int b = XD_M_BASE + r * XMSD_MODCOLS;
      bool en = d.mods[r].enabled;
      bool pos = d.mods[r].hasPos;

      color light = XMSD_C_OFF;
      if(pos)
         light = XMSD_C_CYAN;
      else
         if(en)
            light = XMSD_C_GREEN;
      XmsD_SetFill(b + 0, light);

      XmsD_SetText(b + 1, (d.mods[r].name == "") ? "-" : XmsD_Cut(d.mods[r].name, 13),
                   (en || pos) ? XMSD_C_TEXT : XMSD_C_DIM);
      XmsD_SetText(b + 2, en ? "ON" : "OFF", en ? XMSD_C_GREEN : XMSD_C_DIM);

      if(pos && d.mods[r].posDir > 0)
         XmsD_SetText(b + 3, "BUY", XMSD_C_GREEN);
      else
         if(pos && d.mods[r].posDir < 0)
            XmsD_SetText(b + 3, "SELL", XMSD_C_RED);
         else
            if(pos)
               XmsD_SetText(b + 3, "POS", XMSD_C_CYAN);
            else
               XmsD_SetText(b + 3, "-", XMSD_C_DIM);

      XmsD_SetText(b + 4, IntegerToString(d.mods[r].tradesToday),
                   (d.mods[r].tradesToday > 0) ? XMSD_C_TEXT : XMSD_C_DIM);

      double rr = XmsD_Num(d.mods[r].rToday);
      color rClr = XMSD_C_DIM;
      if(rr > 0.04999)
         rClr = XMSD_C_GREEN;
      else
         if(rr < -0.04999)
            rClr = XMSD_C_RED;
      XmsD_SetText(b + 5, StringFormat("%+.1f", rr), rClr);

      bool hasSig = (d.mods[r].lastSignal != "");
      XmsD_SetText(b + 6, hasSig ? XmsD_Cut(d.mods[r].lastSignal, 12) : "-",
                   hasSig ? XMSD_C_CYANDIM : XMSD_C_DIM);
     }

//--- stats -----------------------------------------------------------
   XmsD_SetText(XD_V_TR, IntegerToString(d.trades), XMSD_C_TEXT);
   if(d.trades > 0)
     {
      XmsD_SetText(XD_V_WIN, StringFormat("%.1f%%", XmsD_Num(d.winRatePct)), XMSD_C_TEXT);
      double pf = d.profitFactor;
      if(!MathIsValidNumber(pf) || pf >= 999.0)
         XmsD_SetText(XD_V_PF, ">999", XMSD_C_GREEN);
      else
         XmsD_SetText(XD_V_PF, DoubleToString(MathMax(0.0, pf), 2), (pf >= 1.0) ? XMSD_C_GREEN : XMSD_C_RED);
     }
   else
     {
      XmsD_SetText(XD_V_WIN, "-", XMSD_C_DIM);
      XmsD_SetText(XD_V_PF, "-", XMSD_C_DIM);
     }

//--- footer status ---------------------------------------------------
   string st = d.status;
   if(st == "")
      st = d.halted ? "Trading halted" : "Running";
   XmsD_SetText(XD_V_STATUS, XmsD_Cut(st, 50), d.halted ? XMSD_C_RED : XMSD_C_DIM);

   ChartRedraw(g_xmsd_chart);
  }

void DashDeinit()
  {
   if(g_xmsd_chart == 0)
      g_xmsd_chart = ChartID();
   ObjectsDeleteAll(g_xmsd_chart, XMSD_PREFIX);
   g_xmsd_ready = false;
   g_xmsd_rows = -1;
   g_xmsd_barw = -1;
   ChartRedraw(g_xmsd_chart);
  }

#endif // XMS_DASHBOARD_MQH
//+------------------------------------------------------------------+
